<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/dash_layout.php';
$c = require_customer();
$full = q('SELECT full_name, email, phone, address, password_hash FROM customers WHERE id = ?', [$c['id']])->fetch();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    if (($_POST['do'] ?? '') === 'profile') {
        $n = trim((string)($_POST['full_name'] ?? '')); $p = trim((string)($_POST['phone'] ?? '')); $a = trim((string)($_POST['address'] ?? ''));
        if ($n === '' || mb_strlen($n) > 120) $errors[] = 'Enter your name.';
        if (!preg_match('/^\+?[0-9 ]{9,15}$/', $p)) $errors[] = 'Enter a valid phone number.';
        if (mb_strlen($a) > 255) $errors[] = 'Address is too long.';
        if (!$errors) { q('UPDATE customers SET full_name = ?, phone = ?, address = ? WHERE id = ?', [$n, $p, $a ?: null, $c['id']]); flash('Profile saved.'); redirect('/account.php'); }
    } elseif (($_POST['do'] ?? '') === 'password') {
        $new = (string)($_POST['new'] ?? '');
        if (rate_limited('chpw:' . $c['id'], 5, 900)) $errors[] = 'Too many attempts. Wait 15 minutes.';
        elseif (!password_verify((string)($_POST['current'] ?? ''), $full['password_hash'])) $errors[] = 'Your current password is wrong.';
        elseif (strlen($new) < 8) $errors[] = 'Use a new password of at least 8 characters.';
        else { q('UPDATE customers SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $c['id']]); audit('customer', (int)$c['id'], 'password_changed', 'customer', (int)$c['id']); queue_mail((string)$full['email'], 'Your password was changed', "Hello {$full['full_name']},\n\nYour password was just changed. If this was not you, reset it now." . mail_button('Reset my password', app_url('/forgot.php')) . 'You can also contact us if you need help.'); session_regenerate_id(true); flash('Password changed.'); redirect('/account.php'); }
    }
}
dash_header('My profile', 'account');
dash_head('My profile', 'Your contact details and password.'); ?>
<?php foreach ($errors as $er) echo '<div class="flash err">' . e($er) . '</div>'; ?>
<div class="row">
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="do" value="profile"><h3>Profile</h3>
<div class="field"><label>Full name</label><input name="full_name" required value="<?= e($_POST['full_name'] ?? $full['full_name']) ?>"></div>
<div class="field"><label>Email (contact us to change)</label><input value="<?= e($full['email']) ?>" disabled></div>
<div class="field"><label>Phone</label><input name="phone" required value="<?= e($_POST['phone'] ?? $full['phone']) ?>"></div>
<div class="field"><label>Address</label><input name="address" value="<?= e($_POST['address'] ?? (string)$full['address']) ?>"></div><button class="btn">Save profile</button></form>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="do" value="password"><h3>Change password</h3>
<div class="field"><label>Current password</label><input type="password" name="current" required autocomplete="current-password"></div>
<div class="field"><label>New password (8+ characters)</label><input type="password" name="new" required minlength="8" autocomplete="new-password"></div><button class="btn">Change password</button></form>
</div><?php dash_footer();
