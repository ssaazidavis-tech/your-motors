<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$token = (string)($_GET['token'] ?? '');
// 1. Clicking the link in the email.
if ($token !== '') {
    $row = preg_match('/^[a-f0-9]{64}$/', $token)
        ? q('SELECT id, customer_id FROM email_verifications WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW()', [hash('sha256', $token)])->fetch() : false;
    if ($row && q('UPDATE email_verifications SET used_at = NOW() WHERE id = ? AND used_at IS NULL', [$row['id']])->rowCount()) {
        q('UPDATE customers SET email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?', [$row['customer_id']]);
        audit('customer', (int)$row['customer_id'], 'email_verified', 'customer', (int)$row['customer_id']);
        flash('Your email is verified. Thank you!');
        $vEmail = (string)q('SELECT email FROM customers WHERE id = ?', [$row['customer_id']])->fetchColumn();
        if ($w = welcome_grant($vEmail, 'verified')) flash('Welcome gift: use code ' . $w['code'] . ' for ' . $w['percent'] . '% off your first car (we also emailed it to you).');
        redirect(current_customer() ? '/dashboard.php' : '/login.php');
    }
    flash('That verification link is invalid or has expired. Log in and request a new one.', 'warn');
    redirect(current_customer() ? '/verify.php' : '/login.php');
}
// 2. Resend page (must be logged in).
$c = require_customer();
if (!empty($c['email_verified_at'])) { flash('Your email is already verified.'); redirect('/dashboard.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    if (rate_limited('verify:' . $c['id'], 3, 3600)) flash('Too many requests. Try again in an hour.', 'warn');
    else { send_verification((int)$c['id'], (string)$c['full_name'], (string)$c['email']); flash('Verification email sent. Check your inbox and spam folder.'); }
    redirect('/verify.php');
}
back_to('/', 'Back to home'); page_header('Verify your email');
?>
<div class="narrow panel"><h1 class="h1s">Verify your email</h1>
<p>We sent a link to <strong><?= e($c['email']) ?></strong>. Click it to confirm this is your address. You need a verified email to place an order. The link works for 24 hours.</p>
<form method="post"><?= csrf_field() ?><button class="btn block">Send me a new link</button></form>
<p class="mute"><a href="/vehicles.php">Keep browsing</a> · <a href="/contact.php">Need help?</a></p></div>
<?php page_footer();
