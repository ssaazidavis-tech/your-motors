<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$cust = current_customer();
$errors = []; $v = ['name' => $cust['full_name'] ?? '', 'phone' => $cust['phone'] ?? '', 'email' => $cust['email'] ?? '', 'message' => ''];
if ($cust && $_SERVER['REQUEST_METHOD'] === 'GET' && preg_match('/^ORD-\d{4}-[A-F0-9]{6}$/', (string)($_GET['ref'] ?? ''))) $v['message'] = 'About order ' . $_GET['ref'] . ': ';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($v as $k => $_) $v[$k] = trim((string)($_POST[$k] ?? ''));
    if (rate_limited('contact:' . client_ip(), 5, 600)) $errors[] = 'Too many messages. Please wait a few minutes.';
    if ($v['name'] === '' || mb_strlen($v['name']) > 120) $errors[] = 'Enter your name.';
    if (!preg_match('/^\+?[0-9 ]{9,15}$/', $v['phone'])) $errors[] = 'Enter a valid phone number.';
    if ($v['email'] !== '' && !filter_var($v['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if ($v['message'] === '' || mb_strlen($v['message']) > 2000) $errors[] = 'Write your question (up to 2000 characters).';
    if (!$errors) {
        q("INSERT INTO inquiries (vehicle_id, customer_id, type, name, phone, email, message) VALUES (NULL,?,'Inquiry',?,?,?,?)",
          [$cust['id'] ?? null, $v['name'], $v['phone'], $v['email'] ?: null, '[General support] ' . $v['message']]);
        notify_staff('New support message', "From: {$v['name']}\nPhone: {$v['phone']}\nEmail: " . ($v['email'] ?: '-') . "\n\n{$v['message']}");
        flash('Thanks. Our team will reply within one working day.');
        redirect('/contact.php');
    }
}
$mine = $cust ? q('SELECT message, status, reply, replied_at, created_at FROM inquiries WHERE customer_id = ? ORDER BY id DESC LIMIT 10', [$cust['id']])->fetchAll() : [];
back_to('/', 'Back to home', true); page_header('Help and contact', 'Ask a question or get help with an order.');
?>
<h1 class="h1s">Help and contact</h1>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<div class="detail">
<section><div class="panel"><h3>Ask us a question</h3>
  <form method="post"><?= csrf_field() ?>
    <div class="field"><label for="n">Your name</label><input id="n" name="name" required maxlength="120" value="<?= e($v['name']) ?>"></div>
    <div class="field"><label for="p">Phone</label><input id="p" name="phone" required value="<?= e($v['phone']) ?>"></div>
    <div class="field"><label for="e">Email (optional)</label><input id="e" name="email" type="email" value="<?= e($v['email']) ?>"></div>
    <div class="field"><label for="m">How can we help?</label><textarea id="m" name="message" rows="5" required maxlength="2000"><?= e($v['message']) ?></textarea></div>
    <button class="btn">Send message</button>
  </form></div>
  <?php if ($mine): ?><div class="panel"><h3>Your recent requests</h3>
    <?php foreach ($mine as $m): ?>
      <p><span class="pill <?= $m['status'] === 'New' ? 'warn' : 'ok' ?>"><?= $m['status'] === 'New' ? 'Waiting for reply' : e($m['status']) ?></span>
      <span class="mute"><?= e(date('j M Y, H:i', strtotime($m['created_at']))) ?></span><br><?= nl2br(e(mb_strimwidth(preg_replace('/^\[General support\] /', '', (string)$m['message']), 0, 300, '...'))) ?>
      <?php if ($m['reply']): ?><br><strong>Our reply:</strong> <?= nl2br(e($m['reply'])) ?><?php endif; ?></p>
    <?php endforeach; ?></div>
  <?php elseif (!$cust): ?><p class="mute"><a href="/login.php?next=%2Fcontact.php">Log in</a> to see our replies here.</p><?php endif; ?></section>
<aside><div class="panel"><h3>Other ways to reach us</h3>
  <p>Phone: <a href="tel:<?= e(preg_replace('/\s+/', '', setting('phone'))) ?>"><?= e(setting('phone')) ?></a></p>
  <p>Email: <a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></p>
  <p><a class="btn" href="https://wa.me/<?= e(setting('whatsapp')) ?>">Chat on WhatsApp</a></p>
  <p class="mute">Replies within one working day. For an order, quote your reference (ORD-...).</p>
  <p><a href="/info.php?p=faq">Read the FAQ</a> · <a href="/info.php?p=delivery">Delivery</a> · <a href="/info.php?p=refunds">Returns &amp; refunds</a></p></div></aside>
</div>
<?php page_footer();
