/* =====================================================================
   qr.js - a small, self-contained QR code generator (no internet, no libraries).
   Usage:  MdbQR.svg('https://example.com/x', { quiet: 3 })  ->  "<svg ...>...</svg>"
   Byte mode, error-correction level M, versions 1-15 (up to ~ 330 characters), automatic mask choice.
   Used by pages/receipt.php to print the order QR code.
   ===================================================================== */
(function (root) {
  'use strict';

  // Index = version (1..15). Level M.
  var ECC_PER_BLOCK = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24];
  var NUM_BLOCKS    = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10];
  var MAX_VERSION = 15;

  function bit(x, i) { return ((x >>> i) & 1) !== 0; }

  function rawModules(ver) {
    var r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) {
      var n = Math.floor(ver / 7) + 2;
      r -= (25 * n - 10) * n - 55;
      if (ver >= 7) { r -= 36; }
    }
    return r;
  }
  function dataCodewords(ver) { return Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver]; }

  function utf8Bytes(str) {
    var out = [], s = unescape(encodeURIComponent(str));
    for (var i = 0; i < s.length; i++) { out.push(s.charCodeAt(i)); }
    return out;
  }

  /* ---- Reed-Solomon over GF(256) ---- */
  function gfMul(x, y) {
    var z = 0;
    for (var i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; }
    return z;
  }
  function rsDivisor(degree) {
    var result = [], i, j;
    for (i = 0; i < degree - 1; i++) { result.push(0); }
    result.push(1);
    var root = 1;
    for (i = 0; i < degree; i++) {
      for (j = 0; j < result.length; j++) {
        result[j] = gfMul(result[j], root);
        if (j + 1 < result.length) { result[j] ^= result[j + 1]; }
      }
      root = gfMul(root, 0x02);
    }
    return result;
  }
  function rsRemainder(data, divisor) {
    var result = divisor.map(function () { return 0; });
    data.forEach(function (b) {
      var factor = b ^ result.shift();
      result.push(0);
      divisor.forEach(function (coef, i) { result[i] ^= gfMul(coef, factor); });
    });
    return result;
  }

  /* ---- build the data codewords ---- */
  function buildData(bytes) {
    var ver, cap, ccBits;
    for (ver = 1; ver <= MAX_VERSION; ver++) {
      ccBits = ver <= 9 ? 8 : 16;
      cap = dataCodewords(ver) * 8;
      if (4 + ccBits + bytes.length * 8 <= cap) { break; }
    }
    if (ver > MAX_VERSION) { throw new Error('QR text too long'); }
    var bits = [];
    function put(val, len) { for (var i = len - 1; i >= 0; i--) { bits.push((val >>> i) & 1); } }
    put(0x4, 4);                                  // byte mode
    put(bytes.length, ccBits);
    bytes.forEach(function (b) { put(b, 8); });
    put(0, Math.min(4, cap - bits.length));       // terminator
    while (bits.length % 8 !== 0) { bits.push(0); }
    for (var pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) { put(pad, 8); }
    var words = [];
    for (var i = 0; i < bits.length; i += 8) {
      var w = 0;
      for (var k = 0; k < 8; k++) { w = (w << 1) | bits[i + k]; }
      words.push(w);
    }
    return { ver: ver, words: words };
  }

  function addEccAndInterleave(data, ver) {
    var numBlocks = NUM_BLOCKS[ver], eccLen = ECC_PER_BLOCK[ver];
    var raw = Math.floor(rawModules(ver) / 8);
    var numShort = numBlocks - raw % numBlocks, shortLen = Math.floor(raw / numBlocks);
    var blocks = [], div = rsDivisor(eccLen), k = 0, i;
    for (i = 0; i < numBlocks; i++) {
      var dat = data.slice(k, k + shortLen - eccLen + (i < numShort ? 0 : 1));
      k += dat.length;
      var ecc = rsRemainder(dat, div);
      if (i < numShort) { dat.push(0); }
      blocks.push(dat.concat(ecc));
    }
    var result = [];
    for (i = 0; i < blocks[0].length; i++) {
      blocks.forEach(function (block, j) {
        if (i !== shortLen - eccLen || j >= numShort) { result.push(block[i]); }
      });
    }
    return result;
  }

  /* ---- the module grid ---- */
  function Grid(ver) {
    this.ver = ver;
    this.size = ver * 4 + 17;
    this.m = [];
    this.fn = [];
    for (var y = 0; y < this.size; y++) {
      this.m.push(new Array(this.size).fill(false));
      this.fn.push(new Array(this.size).fill(false));
    }
  }
  Grid.prototype.setFn = function (x, y, dark) { this.m[y][x] = dark; this.fn[y][x] = true; };
  Grid.prototype.drawFunctionPatterns = function () {
    var size = this.size, i, self = this;
    for (i = 0; i < size; i++) { this.setFn(6, i, i % 2 === 0); this.setFn(i, 6, i % 2 === 0); }
    function finder(cx, cy) {
      for (var dy = -4; dy <= 4; dy++) {
        for (var dx = -4; dx <= 4; dx++) {
          var d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy;
          if (x >= 0 && x < size && y >= 0 && y < size) { self.setFn(x, y, d !== 2 && d !== 4); }
        }
      }
    }
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    var pos = this.alignPositions(), n = pos.length;
    for (i = 0; i < n; i++) {
      for (var j = 0; j < n; j++) {
        if ((i === 0 && j === 0) || (i === 0 && j === n - 1) || (i === n - 1 && j === 0)) { continue; }
        for (var dy = -2; dy <= 2; dy++) {
          for (var dx = -2; dx <= 2; dx++) { this.setFn(pos[i] + dx, pos[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }
        }
      }
    }
    this.drawFormat(0);
    this.drawVersion();
  };
  Grid.prototype.alignPositions = function () {
    var ver = this.ver;
    if (ver === 1) { return []; }
    var n = Math.floor(ver / 7) + 2;
    var step = Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
    var r = [6];
    for (var p = this.size - 7; r.length < n; p -= step) { r.splice(1, 0, p); }
    return r;
  };
  Grid.prototype.drawFormat = function (mask) {            // level M = format bits 0
    var data = (0 << 3) | mask, rem = data, i;
    for (i = 0; i < 10; i++) { rem = (rem << 1) ^ ((rem >>> 9) * 0x537); }
    var bits = ((data << 10) | rem) ^ 0x5412, size = this.size;
    for (i = 0; i <= 5; i++) { this.setFn(8, i, bit(bits, i)); }
    this.setFn(8, 7, bit(bits, 6)); this.setFn(8, 8, bit(bits, 7)); this.setFn(7, 8, bit(bits, 8));
    for (i = 9; i < 15; i++) { this.setFn(14 - i, 8, bit(bits, i)); }
    for (i = 0; i < 8; i++) { this.setFn(size - 1 - i, 8, bit(bits, i)); }
    for (i = 8; i < 15; i++) { this.setFn(8, size - 15 + i, bit(bits, i)); }
    this.setFn(8, size - 8, true);
  };
  Grid.prototype.drawVersion = function () {
    if (this.ver < 7) { return; }
    var rem = this.ver, i;
    for (i = 0; i < 12; i++) { rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25); }
    var bits = (this.ver << 12) | rem;
    for (i = 0; i < 18; i++) {
      var b = bit(bits, i), a = this.size - 11 + i % 3, c = Math.floor(i / 3);
      this.setFn(a, c, b); this.setFn(c, a, b);
    }
  };
  Grid.prototype.drawCodewords = function (data) {
    var size = this.size, i = 0;
    for (var right = size - 1; right >= 1; right -= 2) {
      if (right === 6) { right = 5; }
      for (var vert = 0; vert < size; vert++) {
        for (var j = 0; j < 2; j++) {
          var x = right - j, upward = ((right + 1) & 2) === 0, y = upward ? size - 1 - vert : vert;
          if (!this.fn[y][x] && i < data.length * 8) { this.m[y][x] = bit(data[i >>> 3], 7 - (i & 7)); i++; }
        }
      }
    }
  };
  Grid.prototype.applyMask = function (mask) {
    for (var y = 0; y < this.size; y++) {
      for (var x = 0; x < this.size; x++) {
        var inv;
        switch (mask) {
          case 0: inv = (x + y) % 2 === 0; break;
          case 1: inv = y % 2 === 0; break;
          case 2: inv = x % 3 === 0; break;
          case 3: inv = (x + y) % 3 === 0; break;
          case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: inv = x * y % 2 + x * y % 3 === 0; break;
          case 6: inv = (x * y % 2 + x * y % 3) % 2 === 0; break;
          default: inv = ((x + y) % 2 + x * y % 3) % 2 === 0;
        }
        if (inv && !this.fn[y][x]) { this.m[y][x] = !this.m[y][x]; }
      }
    }
  };
  Grid.prototype.penalty = function () {
    var size = this.size, m = this.m, score = 0, x, y, run, line;
    function lineScore(cells) {           // rules 1 and 3 for one row/column
      var s = 0, r = 1, i;
      for (i = 1; i <= cells.length; i++) {
        if (i < cells.length && cells[i] === cells[i - 1]) { r++; } else { if (r >= 5) { s += 3 + (r - 5); } r = 1; }
      }
      var str = cells.map(function (c) { return c ? '1' : '0'; }).join('');
      var re = /(?=(00001011101|10111010000))/g, hit;
      while ((hit = re.exec(str)) !== null) { s += 40; re.lastIndex = hit.index + 1; }
      return s;
    }
    for (y = 0; y < size; y++) { score += lineScore(m[y]); }
    for (x = 0; x < size; x++) { line = []; for (y = 0; y < size; y++) { line.push(m[y][x]); } score += lineScore(line); }
    for (y = 0; y < size - 1; y++) {
      for (x = 0; x < size - 1; x++) { if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) { score += 3; } }
    }
    var dark = 0;
    for (y = 0; y < size; y++) { for (x = 0; x < size; x++) { if (m[y][x]) { dark++; } } }
    var total = size * size;
    score += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
    return score;
  };

  function encode(text) {
    var built = buildData(utf8Bytes(text));
    var codewords = addEccAndInterleave(built.words, built.ver);
    var grid = new Grid(built.ver);
    grid.drawFunctionPatterns();
    grid.drawCodewords(codewords);
    var best = -1, bestScore = Infinity, mask;
    for (mask = 0; mask < 8; mask++) {
      grid.applyMask(mask); grid.drawFormat(mask);
      var p = grid.penalty();
      if (p < bestScore) { best = mask; bestScore = p; }
      grid.applyMask(mask);                       // undo (xor is its own inverse)
    }
    grid.applyMask(best); grid.drawFormat(best);
    return grid;
  }

  /** The QR code as an SVG string: black squares on white, with a quiet border of `quiet` modules. */
  function svg(text, opts) {
    var quiet = opts && opts.quiet != null ? opts.quiet : 3;
    var g = encode(text), n = g.size + quiet * 2, d = [];
    for (var y = 0; y < g.size; y++) {
      var x = 0;
      while (x < g.size) {
        if (!g.m[y][x]) { x++; continue; }
        var start = x;
        while (x < g.size && g.m[y][x]) { x++; }
        d.push('M' + (start + quiet) + ',' + (y + quiet) + 'h' + (x - start) + 'v1h-' + (x - start) + 'z');
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + n + ' ' + n + '" shape-rendering="crispEdges" role="img" aria-label="QR code">' +
      '<rect width="' + n + '" height="' + n + '" fill="#fff"/><path fill="#000" d="' + d.join('') + '"/></svg>';
  }

  root.MdbQR = { svg: svg, matrix: function (t) { return encode(t).m; } };
  if (typeof module !== 'undefined' && module.exports) { module.exports = root.MdbQR; }
})(typeof window !== 'undefined' ? window : this);
