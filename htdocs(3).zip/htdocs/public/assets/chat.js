// "Ask us" chat bubble. Loaded only when ANTHROPIC_API_KEY is set in .env.
(function () {
  var base = (document.querySelector('meta[name=base]') || {}).content || '';
  var csrf = (document.querySelector('meta[name=csrf]') || {}).content || '';
  var history = [];
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  var btn = el('button', 'chat-fab', 'Ask us'); btn.type = 'button'; btn.setAttribute('aria-expanded', 'false');
  var box = el('div', 'chat-box'); box.hidden = true; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Chat with our assistant');
  var head = el('div', 'chat-head', 'Ask about our cars'); var log = el('div', 'chat-log'); log.setAttribute('aria-live', 'polite');
  var form = el('form', 'chat-form'); var input = el('input'); input.maxLength = 600; input.placeholder = 'e.g. a family SUV under UGX 60m'; input.setAttribute('aria-label', 'Your message'); input.required = true;
  var send = el('button', 'btn small', 'Send'); form.appendChild(input); form.appendChild(send);
  box.appendChild(head); box.appendChild(log); box.appendChild(form); document.body.appendChild(box); document.body.appendChild(btn);
  function add(role, text) {
    var m = el('div', 'chat-msg ' + role);
    // Turn /vehicle.php?id=N paths into links without ever using innerHTML.
    text.split(/(\/vehicle\.php\?id=\d+)/).forEach(function (part) {
      if (/^\/vehicle\.php\?id=\d+$/.test(part)) { var a = el('a', '', 'view car'); a.href = base + part; m.appendChild(a); } else m.appendChild(document.createTextNode(part));
    });
    log.appendChild(m); log.scrollTop = log.scrollHeight;
  }
  btn.addEventListener('click', function () { box.hidden = !box.hidden; btn.setAttribute('aria-expanded', String(!box.hidden)); if (!box.hidden) { if (!log.children.length) add('bot', 'Hi! Tell me what kind of car you need and your budget, and I will suggest options from our stock.'); input.focus(); } });
  form.addEventListener('submit', function (e) {
    e.preventDefault(); var text = input.value.trim(); if (!text) return;
    add('user', text); input.value = ''; send.disabled = true;
    fetch(base + '/api/chat.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF': csrf }, body: JSON.stringify({ message: text, history: history }) })
      .then(function (r) { return r.json(); }).then(function (d) { add('bot', d.reply || 'Sorry, something went wrong.'); history.push({ role: 'user', text: text }, { role: 'assistant', text: d.reply || '' }); })
      .catch(function () { add('bot', 'Sorry, I could not connect. Please try again.'); }).then(function () { send.disabled = false; input.focus(); });
  });
})();
