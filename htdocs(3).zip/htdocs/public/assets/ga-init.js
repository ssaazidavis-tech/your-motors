// GA4 init and ecommerce events, kept in a file (not inline) so the Content-Security-Policy stays strict.
(function () {
  var id = document.currentScript && document.currentScript.getAttribute('data-id');
  if (!id) return;
  window.dataLayer = window.dataLayer || [];
  function gtag() { window.dataLayer.push(arguments); }
  window.gtag = gtag;
  gtag('js', new Date());
  gtag('config', id);
  document.addEventListener('DOMContentLoaded', function () {
    var box = document.getElementById('ga-events');
    if (!box) return;
    try {
      JSON.parse(box.getAttribute('data-events') || '[]').forEach(function (ev) { gtag('event', ev.n, ev.p); });
    } catch (e) { /* analytics must never break the page */ }
  });
  // Contact and inquiry form submissions as generate_lead.
  document.addEventListener('submit', function (e) {
    var a = e.target && e.target.getAttribute && e.target.getAttribute('action');
    if (e.target && e.target.querySelector && e.target.querySelector('textarea[name="message"]')) gtag('event', 'generate_lead');
  });
})();
