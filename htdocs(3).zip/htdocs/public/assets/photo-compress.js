/* Shrinks photos in the browser before upload: longest side 1600 px (or data-max), saved as JPEG.
   A 5 MB phone photo becomes roughly 300 to 600 KB, so a form with 10 photos stays far below
   the server's post_max_size. If a file cannot be decoded (for example HEIC), it is sent as is
   and the server converts or rejects it. */
(function () {
  var MAX = 1600, QUALITY = 0.82;
  var input = document.querySelector('input[type=file][data-compress]');
  if (input && input.dataset.max) MAX = parseInt(input.dataset.max, 10) || MAX;
  if (!input || !window.createImageBitmap || !window.DataTransfer || !HTMLCanvasElement.prototype.toBlob) return;
  var status = document.getElementById('photo-status');
  var picks = document.getElementById('photo-previews');
  var form = input.form, buttons = form ? form.querySelectorAll('button:not([type=button])') : [];

  function setBusy(b) { buttons.forEach(function (x) { x.disabled = b; }); }
  function mb(n) { return (n / 1048576).toFixed(1) + ' MB'; }

  function compress(file) {
    return createImageBitmap(file, { imageOrientation: 'from-image' }).then(function (bmp) {
      var k = Math.min(1, MAX / Math.max(bmp.width, bmp.height));
      var c = document.createElement('canvas');
      c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
      var ctx = c.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);   // flatten PNG/WebP transparency
      ctx.drawImage(bmp, 0, 0, c.width, c.height);
      if (bmp.close) bmp.close();
      return new Promise(function (res) {
        c.toBlob(function (blob) {
          if (!blob || (blob.size >= file.size && file.type === 'image/jpeg' && k === 1)) return res(file);
          res(new File([blob], file.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg', lastModified: Date.now() }));
        }, 'image/jpeg', QUALITY);
      });
    }).catch(function () { return file; });
  }

  // Thumbnails of the photos about to be uploaded, each with a radio to choose the primary one.
  // Data URLs are used because the site's security policy does not allow blob: images.
  function renderPicks(files) {
    if (!picks) return;
    picks.textContent = '';
    var hasPrimary = input.hasAttribute('data-has-primary');
    files.forEach(function (f, i) {
      var lab = document.createElement('label'); lab.className = 'pick';
      var img = document.createElement('img'); img.alt = f.name;
      var row = document.createElement('span'); row.className = 'pickrow';
      var r = document.createElement('input'); r.type = 'radio'; r.name = 'primary_new'; r.value = String(i); r.className = 'chk';
      if (i === 0 && !hasPrimary) r.checked = true;     // a vehicle with no photos yet gets the first one by default
      var t = document.createElement('span'); t.textContent = 'Primary photo';
      row.appendChild(r); row.appendChild(t); lab.appendChild(img); lab.appendChild(row); picks.appendChild(lab);
      var fr = new FileReader(); fr.onload = function () { img.src = fr.result; }; fr.readAsDataURL(f);
    });
  }

  input.addEventListener('change', function () {
    var files = Array.prototype.slice.call(input.files);
    if (!files.length) { if (status) status.textContent = ''; renderPicks([]); return; }
    var before = files.reduce(function (s, f) { return s + f.size; }, 0);
    if (status) status.textContent = 'Compressing ' + files.length + ' photo' + (files.length > 1 ? 's' : '') + '...';
    setBusy(true);
    Promise.all(files.map(compress)).then(function (out) {
      var dt = new DataTransfer();
      out.forEach(function (f) { dt.items.add(f); });
      input.files = dt.files;
      renderPicks(out);
      var after = out.reduce(function (s, f) { return s + f.size; }, 0);
      if (status) status.textContent = out.length + ' photo' + (out.length > 1 ? 's' : '') + ' ready: ' + mb(before) + ' down to ' + mb(after) + ' (JPEG). Tick the photo you want as the primary one.';
    }).then(function () { setBusy(false); }, function () { setBusy(false); });
  });
})();
