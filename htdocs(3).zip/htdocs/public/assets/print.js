// Print / Save as PDF button: <a href="#" data-print>. Kept as a file so the Content-Security-Policy stays strict.
document.addEventListener('click', function (e) {
  var a = e.target.closest && e.target.closest('[data-print]');
  if (a) { e.preventDefault(); window.print(); }
});
