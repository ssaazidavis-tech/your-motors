// No visitor controls. The only exception is automatic: visitors whose device is set to "reduce motion" get the still poster.
(function () {
  var v = document.getElementById('hero-video');
  if (v && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) v.pause();
})();
