var SITE_BASE = (document.currentScript && document.currentScript.src) ? document.currentScript.src.replace(/\/assets\/app\.js.*$/, '') : '';
// Dependent Make -> Model dropdowns. Progressive enhancement: forms work without JS.
document.querySelectorAll('select[data-models-for]').forEach(function (modelSel) {
  var makeSel = document.getElementById(modelSel.dataset.modelsFor);
  if (!makeSel) return;
  function load(keep) {
    var make = makeSel.value;
    modelSel.innerHTML = '<option value="">Any model</option>';
    if (!make) return;
    fetch(SITE_BASE + '/api/models.php?make=' + encodeURIComponent(make), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (list) {
        list.forEach(function (m) {
          var o = document.createElement('option');
          o.value = m; o.textContent = m;
          if (keep && keep === m) o.selected = true;
          modelSel.appendChild(o);
        });
      });
  }
  makeSel.addEventListener('change', function () { load(''); });
  if (makeSel.value) load(modelSel.dataset.selected || '');
});
// Gallery thumbnails
document.querySelectorAll('[data-thumb]').forEach(function (t) {
  t.addEventListener('click', function (ev) {
    ev.preventDefault();
    var main = document.getElementById('mainphoto');
    if (main) { main.src = t.dataset.thumb; }
  });
});
