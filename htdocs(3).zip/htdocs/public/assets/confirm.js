// Confirmation popup. Add data-confirm="Message" to a <form> or to its submit <button>.
// Optional: data-confirm-title, data-confirm-ok (button label), data-confirm-danger (red button).
// Kept as a file (not inline) so the Content-Security-Policy stays strict.
(function () {
  var dlg = null, confirmed = new WeakSet();
  function build() {
    dlg = document.createElement('dialog');
    dlg.className = 'cdialog';
    dlg.setAttribute('aria-labelledby', 'cd-title');
    dlg.innerHTML = '<h2 id="cd-title"></h2><p id="cd-msg"></p><div class="cd-actions"><button type="button" class="ghost" id="cd-no">Go back</button><button type="button" class="btn" id="cd-yes"></button></div>';
    document.body.appendChild(dlg);
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close('no'); }); // click on the backdrop
    dlg.querySelector('#cd-no').addEventListener('click', function () { dlg.close('no'); });
    dlg.querySelector('#cd-yes').addEventListener('click', function () { dlg.close('yes'); });
  }
  function ask(opts, done) {
    if (typeof HTMLDialogElement === 'undefined') { done(window.confirm(opts.msg)); return; }
    if (!dlg) build();
    dlg.querySelector('#cd-title').textContent = opts.title;
    dlg.querySelector('#cd-msg').textContent = opts.msg;
    var yes = dlg.querySelector('#cd-yes');
    yes.textContent = opts.ok;
    yes.className = 'btn' + (opts.danger ? ' danger' : '');
    dlg.returnValue = '';
    dlg.onclose = function () { done(dlg.returnValue === 'yes'); };
    dlg.showModal();
    dlg.querySelector(opts.danger ? '#cd-no' : '#cd-yes').focus(); // risky actions default to "Go back"
  }
  document.addEventListener('submit', function (e) {
    var form = e.target, btn = e.submitter;
    if (confirmed.has(form)) { confirmed.delete(form); return; }
    var src = (btn && btn.hasAttribute('data-confirm')) ? btn : (form.hasAttribute('data-confirm') ? form : null);
    if (!src) return;
    e.preventDefault();
    ask({
      msg: src.getAttribute('data-confirm'),
      title: src.getAttribute('data-confirm-title') || 'Are you sure?',
      ok: src.getAttribute('data-confirm-ok') || 'Yes, continue',
      danger: src.hasAttribute('data-confirm-danger')
    }, function (yes) {
      if (!yes) return;
      confirmed.add(form);
      if (form.requestSubmit) form.requestSubmit(btn || undefined); else form.submit();
    });
  }, true);
})();
