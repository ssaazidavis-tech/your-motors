// Draws the QR code for the authenticator set-up page (CSP allows no inline scripts).
(function () {
  var box = document.getElementById('qrbox');
  if (!box || !window.MdbQR) return;
  try { box.innerHTML = MdbQR.svg(box.getAttribute('data-uri'), { quiet: 3 }); } catch (e) { box.textContent = ''; }
})();
