// Cart drawer + quick view. External file because the Content-Security-Policy blocks inline scripts.
(function () {
  var base = (document.querySelector('meta[name=base]') || {}).content || '';
  var csrf = (document.querySelector('meta[name=csrf]') || {}).content || '';
  function url(p) { return base + p; }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function getJSON(p) { return fetch(url(p), { credentials: 'same-origin' }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }); }
  function post(form) {
    return fetch(form.action, { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
      .then(function (r) { return r.json(); });
  }
  function toast(msg, type) {
    var t = el('div', 'toast ' + (type || ''), msg); t.setAttribute('role', 'status'); document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 3200);
  }
  function setCount(n) {
    document.querySelectorAll('.cartlink').forEach(function (a) {
      var b = a.querySelector('b'); if (n > 0) { if (!b) { b = document.createElement('b'); a.appendChild(document.createTextNode(' ')); a.appendChild(b); } b.textContent = n; } else if (b) b.remove();
    });
  }

  // ---------- cart drawer ----------
  var dlg = null, body = null;
  function ensureDrawer() {
    if (dlg) return;
    dlg = el('dialog', 'drawer'); dlg.setAttribute('aria-label', 'Your cart');
    var head = el('div', 'dr-head'); head.appendChild(el('strong', '', 'Your cart'));
    var x = el('button', 'ghost', 'Close'); x.type = 'button'; x.addEventListener('click', function () { dlg.close(); }); head.appendChild(x);
    body = el('div', 'dr-body'); dlg.appendChild(head); dlg.appendChild(body); document.body.appendChild(dlg);
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  }
  function render(d) {
    body.textContent = ''; setCount(d.count);
    if (!d.items.length) { body.appendChild(el('p', 'mute', 'Your cart is empty.')); var b = el('a', 'btn block', 'Browse cars'); b.href = url('/vehicles.php'); body.appendChild(b); return; }
    d.items.forEach(function (it) {
      var row = el('div', 'dr-item');
      if (it.img) { var im = el('img'); im.src = url(it.img); im.alt = ''; im.width = 72; im.height = 54; row.appendChild(im); }
      var info = el('div'); var a = el('a', '', it.title); a.href = url(it.url); info.appendChild(a); info.appendChild(el('div', it.ok ? 'mute' : 'bad', it.price)); row.appendChild(info);
      var rm = el('button', 'ghost', 'Remove'); rm.type = 'button';
      rm.addEventListener('click', function () {
        var f = document.createElement('form'); f.action = url('/cart.php');
        [['_csrf', csrf], ['id', it.id], ['do', 'remove']].forEach(function (p) { var i = document.createElement('input'); i.name = p[0]; i.value = p[1]; f.appendChild(i); });
        post(f).then(function () { return getJSON('/api/cart.php'); }).then(render);
      });
      row.appendChild(rm); body.appendChild(row);
    });
    var t = el('div', 'dr-total'); t.appendChild(el('span', '', 'Subtotal')); t.appendChild(el('strong', '', d.subtotal)); body.appendChild(t);
    if (d.discount) { var c = el('div', 'dr-total'); c.appendChild(el('span', '', 'Coupon ' + d.coupon)); c.appendChild(el('span', '', d.discount)); body.appendChild(c); var g = el('div', 'dr-total'); g.appendChild(el('span', '', 'After discount')); g.appendChild(el('strong', '', d.total)); body.appendChild(g); }
    var go = el('a', 'btn block', 'Checkout'); go.href = url('/checkout.php'); body.appendChild(go);
    var vc = el('a', 'ghost block', 'View cart and coupons'); vc.href = url('/cart.php'); body.appendChild(vc);
  }
  function openDrawer() {
    if (typeof HTMLDialogElement === 'undefined') { location.href = url('/cart.php'); return; }
    ensureDrawer(); body.textContent = 'Loading...'; dlg.showModal();
    getJSON('/api/cart.php').then(render).catch(function () { dlg.close(); location.href = url('/cart.php'); });
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a.cartlink');
    if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey && location.pathname.indexOf('/cart.php') === -1 && location.pathname.indexOf('/checkout.php') === -1) { e.preventDefault(); openDrawer(); }
  });
  // Add-to-cart forms: stay on the page and open the drawer.
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!(f instanceof HTMLFormElement) || !/\/cart\.php$/.test(f.getAttribute('action') || '') || !f.querySelector('input[name=do][value=add]') || typeof HTMLDialogElement === 'undefined') return;
    e.preventDefault();
    post(f).then(function (r) {
      (r.msgs || []).forEach(function (m) { if (m[0] !== 'ok') toast(m[1], m[0]); });
      setCount(r.count); if ((r.msgs || []).some(function (m) { return m[0] === 'ok'; })) openDrawer();
    }).catch(function () { f.submit(); });
  });

  // ---------- quick view ----------
  var qv = null;
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-quick]'); if (!b) return;
    e.preventDefault();
    if (typeof HTMLDialogElement === 'undefined') { location.href = url('/vehicle.php?id=' + b.getAttribute('data-quick')); return; }
    if (!qv) { qv = el('dialog', 'quick'); qv.setAttribute('aria-label', 'Quick view'); document.body.appendChild(qv); qv.addEventListener('click', function (ev) { if (ev.target === qv) qv.close(); }); }
    qv.textContent = 'Loading...'; qv.showModal();
    getJSON('/api/quick.php?id=' + encodeURIComponent(b.getAttribute('data-quick'))).then(function (d) {
      qv.textContent = '';
      if (d.img) { var im = el('img'); im.src = url(d.img); im.alt = d.title; qv.appendChild(im); }
      qv.appendChild(el('h2', '', d.title)); qv.appendChild(el('p', 'price big', d.price));
      var dl = el('dl', 'specs'); Object.keys(d.specs).forEach(function (k) { var r = el('div'); r.appendChild(el('dt', '', k)); r.appendChild(el('dd', '', String(d.specs[k]))); dl.appendChild(r); }); qv.appendChild(dl);
      var acts = el('div', 'actions'); var more = el('a', 'btn', 'Full details'); more.href = url(d.url); acts.appendChild(more);
      if (d.canAdd) { var add = el('button', 'btn alt', 'Add to cart'); add.type = 'button'; add.addEventListener('click', function () {
        var f = document.createElement('form'); f.action = url('/cart.php'); [['_csrf', csrf], ['id', d.id], ['do', 'add']].forEach(function (p) { var i = document.createElement('input'); i.name = p[0]; i.value = p[1]; f.appendChild(i); });
        post(f).then(function (r) { qv.close(); setCount(r.count); (r.msgs || []).forEach(function (m) { if (m[0] !== 'ok') toast(m[1], m[0]); }); if ((r.msgs || []).some(function (m) { return m[0] === 'ok'; })) openDrawer(); }); }); acts.appendChild(add); }
      var cl = el('button', 'ghost', 'Close'); cl.type = 'button'; cl.addEventListener('click', function () { qv.close(); }); acts.appendChild(cl); qv.appendChild(acts);
    }).catch(function () { qv.close(); });
  });
})();
