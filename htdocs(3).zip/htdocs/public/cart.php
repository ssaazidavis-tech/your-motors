<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
release_expired_reservations();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $id = (int)($_POST['id'] ?? 0);
    $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'add' || $do === 'buy') {
            cart_add($id);
            $gv = q('SELECT id, stock_ref, year, make, model, grade, price FROM vehicles WHERE id = ?', [$id])->fetch();
            if ($gv) ga_queue('add_to_cart', ['value' => (float)$gv['price'], 'items' => [ga_item($gv)]]);
            if ($do === 'buy') redirect(current_customer() ? '/checkout.php' : '/login.php?next=' . urlencode('/checkout.php'));
            flash('Added to your cart.');
        } elseif ($do === 'remove') { cart_remove($id); flash('Removed from your cart.'); }
        elseif ($do === 'coupon') {
            $sub = 0.0; foreach (cart_vehicles() as $cv) if ($cv['status'] === 'Available') $sub += (float)$cv['price'];
            [$ok, $msg] = coupon_apply((string)($_POST['code'] ?? ''), $sub); flash($msg, $ok ? 'ok' : 'warn');
        } elseif ($do === 'coupon_remove') { coupon_remove(); flash('Coupon removed.'); }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch') {   // cart drawer: answer with JSON instead of redirecting
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['msgs' => flash() ?? [], 'count' => count(cart_ids())]); exit;
    }
    redirect(safe_return($_POST['return'] ?? null, '/cart.php'));
}

$items = cart_vehicles();
$subtotal = 0.0; $blocked = false;
foreach ($items as $v) { if ($v['status'] === 'Available') $subtotal += (float)$v['price']; else $blocked = true; }
$coupon = coupon_applied($subtotal); $discount = $coupon ? coupon_discount($coupon, $subtotal) : 0.0;
back_to('/vehicles.php', 'Continue browsing'); page_header('Your cart');
?>
<h1 class="h1s">Your cart</h1>
<?php if (!$items): ?>
  <div class="panel"><p>Your cart is empty.</p><a class="btn" href="/vehicles.php">Browse cars</a></div>
<?php else: ?>
<div class="notice">Adding a car to your cart does not reserve it. The car is held for you only after you place your order.</div>
<table class="t"><thead><tr><th>Vehicle</th><th>Status</th><th class="right">Price</th><th></th></tr></thead><tbody>
<?php foreach ($items as $v): $ok = $v['status'] === 'Available'; ?>
<tr><td><a href="/vehicle.php?id=<?= (int)$v['id'] ?>"><strong><?= e(vehicle_title($v)) ?></strong></a><br><span class="mute"><?= e($v['stock_ref']) ?></span></td>
<td><?= $ok ? '<span class="pill ok">Available</span>' : '<span class="pill bad">No longer available</span>' ?></td>
<td class="right"><?= $ok ? money($v['price']) : 'n/a' ?></td>
<td class="right"><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="do" value="remove"><button class="ghost">Remove</button></form></td></tr>
<?php endforeach; ?></tbody></table>
<div class="totals panel"><div class="line"><span>Subtotal</span><span><?= money($subtotal) ?></span></div>
  <?php if ($coupon): ?><div class="line"><span>Coupon <?= e($coupon['code']) ?></span><span>-<?= money($discount) ?></span></div>
  <div class="line grand"><span>After discount</span><span><?= money($subtotal - $discount) ?></span></div>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="coupon_remove"><button class="ghost">Remove coupon</button></form>
  <?php else: ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="do" value="coupon"><label for="cc" class="mute">Have a coupon?</label>
    <input id="cc" name="code" maxlength="40" placeholder="Enter code" autocomplete="off"> <button class="ghost">Apply</button></form><?php endif; ?>
  <p class="mute">Delivery or registration fees, if any, are added at checkout.</p>
  <?php if ($blocked): ?><p class="flash warn">Remove the unavailable vehicles to continue.</p>
  <?php else: ?><a class="btn block" href="/checkout.php">Proceed to checkout</a><?php endif; ?></div>
<?php endif; page_footer();
