<?php
// For hosts without cron (InfinityFree): an outside scheduler opens  https://yoursite/cron.php?token=YOUR_CRON_TOKEN  every 10 minutes.
// Set CRON_TOKEN in .env to a long random string. Without it this page does nothing.
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
header('Content-Type: text/plain; charset=utf-8'); header('X-Robots-Tag: noindex'); header('Cache-Control: no-store');
$token = (string)env('CRON_TOKEN', '');
if (strlen($token) < 16 || !hash_equals($token, (string)($_GET['token'] ?? ''))) { http_response_code(404); exit('Not found'); }
try { echo run_scheduled_jobs(), "\n"; }
catch (Throwable $e) { error_log('cron: ' . $e->getMessage()); http_response_code(500); echo "error\n"; }
