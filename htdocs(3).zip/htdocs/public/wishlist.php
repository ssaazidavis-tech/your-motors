<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/dash_layout.php';
$c = require_customer();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $id = (int)($_POST['id'] ?? 0);
    if (q('SELECT 1 FROM vehicles WHERE id = ?', [$id])->fetchColumn()) {
        if (q('SELECT 1 FROM wishlists WHERE customer_id = ? AND vehicle_id = ?', [$c['id'], $id])->fetchColumn()) {
            q('DELETE FROM wishlists WHERE customer_id = ? AND vehicle_id = ?', [$c['id'], $id]); flash('Removed from your wishlist.');
        } else { q('INSERT IGNORE INTO wishlists (customer_id, vehicle_id) VALUES (?,?)', [$c['id'], $id]); flash('Saved to your wishlist.'); }
    }
    redirect(safe_return($_POST['return'] ?? null, '/wishlist.php'));
}
$rows = q(VEHICLE_SELECT . ' JOIN wishlists w ON w.vehicle_id = v.id WHERE w.customer_id = ? ORDER BY w.created_at DESC', [$c['id']])->fetchAll();
dash_header('Wishlist', 'wishlist');
dash_head('Your wishlist', 'Cars you saved to come back to.');
if (!$rows) echo '<div class="panel"><p>Nothing saved yet.</p><a class="btn" href="/vehicles.php">Browse cars</a></div>';
else { echo '<div class="grid">'; foreach ($rows as $v) vehicle_card($v, array_column($rows, 'id')); echo '</div>'; }
dash_footer();
