<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
if (current_customer()) redirect('/');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $pw = (string)($_POST['password'] ?? '');
    if (rate_limited('login:' . client_ip() . ':' . $email, 6, 900)) {
        $error = 'Too many attempts. Wait 15 minutes and try again.';
    } else {
        $u = q('SELECT id, password_hash FROM customers WHERE email = ? AND is_active = 1', [$email])->fetch();
        if ($u && password_verify($pw, $u['password_hash'])) {
            audit('customer', (int)$u['id'], 'login', 'customer', (int)$u['id']);
            customer_login((int)$u['id']);
            redirect(safe_return($_GET['next'] ?? null, '/'));
        }
        $error = 'Email or password is incorrect.';
    }
}
back_to('/', 'Back to home'); page_header('Log in');
?>
<div class="narrow panel"><h1 class="h1s">Log in</h1>
<?php if ($error): ?><div class="flash err"><?= e($error) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
  <div class="field"><label for="em">Email</label><input id="em" type="email" name="email" required autocomplete="email"></div>
  <div class="field"><label for="pw">Password</label><input id="pw" type="password" name="password" required autocomplete="current-password"></div>
  <button class="btn block">Log in</button>
</form>
<p>New here? <a href="/register.php<?= isset($_GET['next']) ? '?next=' . urlencode((string)$_GET['next']) : '' ?>">Create an account</a></p>
<p class="mute">Forgot your password? <a href="/forgot.php">Reset it by email</a>.</p></div>
<?php page_footer();
