<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$c = require_customer();
require_post();
$id = (int)($_POST['id'] ?? 0);
$kind = (string)($_POST['kind'] ?? '');
$v = q("SELECT id, price, status FROM vehicles WHERE id = ? AND status IN ('Available','Reserved')", [$id])->fetch();
if ($v && in_array($kind, ['price_drop', 'available'], true)) {
    if (alert_has((int)$c['id'], $id, $kind)) {
        q('DELETE FROM vehicle_alerts WHERE customer_id = ? AND vehicle_id = ? AND kind = ?', [$c['id'], $id, $kind]);
        flash('Alert turned off.');
    } elseif (rate_limited('alert:' . $c['id'], 20, 3600)) {
        flash('Too many alerts. Try again later.', 'warn');
    } else {
        // Replace an old, already-sent alert of the same kind with a fresh one at today's price.
        q('REPLACE INTO vehicle_alerts (customer_id, vehicle_id, kind, price_at_signup) VALUES (?,?,?,?)', [$c['id'], $id, $kind, $v['price']]);
        flash($kind === 'available' ? 'We will email you if this car becomes available.' : 'We will email you if the price drops.');
    }
}
redirect(safe_return($_POST['return'] ?? null, '/vehicle.php?id=' . $id));
