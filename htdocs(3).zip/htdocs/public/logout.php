<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';
require_post();
$_SESSION = [];
if (ini_get('session.use_cookies')) { $p = session_get_cookie_params(); setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']); }
session_destroy();
redirect('/');
