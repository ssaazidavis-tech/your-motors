<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
// SANDBOX payment gateway simulation. No card data is stored and no real money moves.
// Test card 4242 4242 4242 4242 succeeds, 4000 0000 0000 0002 is declined.
// Test mobile money 0770000000 with PIN 1234 succeeds.
$c = require_customer();
release_expired_reservations();
$ref = (string)($_GET['ref'] ?? $_POST['ref'] ?? '');
$o = q('SELECT * FROM orders WHERE reference = ? AND customer_id = ?', [$ref, $c['id']])->fetch();
$isTest = $o && in_array($o['payment_method'], ['card_test', 'momo_test'], true);
if (!$o || !$isTest || $o['status'] !== 'Awaiting Payment') {
    flash('This order cannot be paid in test mode right now.', 'warn');
    redirect($o ? '/order.php?ref=' . urlencode($ref) : '/orders.php');
}
$balance = (float)$o['total_amount'] - (float)$o['amount_paid'];
$dueNow  = (float)$o['amount_due_now'] - (float)$o['amount_paid'];
$amount  = round($dueNow > 0.001 ? min($dueNow, $balance) : $balance);
if ($amount <= 0) { flash('Nothing left to pay on this order.'); redirect('/order.php?ref=' . urlencode($ref)); }
$isCard = $o['payment_method'] === 'card_test';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    if (rate_limited('pay:' . $c['id'], 8, 600)) $errors[] = 'Too many attempts. Wait a few minutes.';
    $ok = false;
    if ($isCard) {
        $num = preg_replace('/\D/', '', (string)($_POST['card'] ?? ''));
        $exp = trim((string)($_POST['exp'] ?? ''));
        $cvc = preg_replace('/\D/', '', (string)($_POST['cvc'] ?? ''));
        if (!preg_match('/^(0[1-9]|1[0-2])\s*\/\s*(\d{2})$/', $exp, $m) || ((int)('20' . $m[2]) * 12 + (int)$m[1]) < ((int)date('Y') * 12 + (int)date('n'))) $errors[] = 'Enter a valid, future expiry date (MM/YY).';
        if (strlen($cvc) !== 3) $errors[] = 'Enter the 3-digit security code.';
        if ($num === '4000000000000002') $errors[] = 'Card declined (sandbox test card). Try 4242 4242 4242 4242.';
        elseif ($num !== '4242424242424242') $errors[] = 'Test mode accepts only the test card 4242 4242 4242 4242.';
        $ok = !$errors;
        $detail = 'card ending ' . substr($num, -4);
    } else {
        $ph = preg_replace('/\s+/', '', (string)($_POST['phone'] ?? ''));
        $pin = (string)($_POST['pin'] ?? '');
        if ($ph !== '0770000000' || $pin !== '1234') $errors[] = 'Test mode accepts only number 0770000000 with PIN 1234.';
        $ok = !$errors;
        $detail = 'mobile money test number';
    }
    if ($ok) {
        $pdo = db(); $pdo->beginTransaction();
        try {
            $lo = q('SELECT * FROM orders WHERE id = ? FOR UPDATE', [$o['id']])->fetch();
            if ($lo['status'] !== 'Awaiting Payment') throw new UserError('This order is no longer awaiting payment.');
            $txn = 'SBX-' . strtoupper(bin2hex(random_bytes(5)));
            $pend = q("SELECT id FROM payments WHERE order_id = ? AND status = 'Pending' ORDER BY id LIMIT 1 FOR UPDATE", [$o['id']])->fetchColumn();
            if ($pend) q("UPDATE payments SET status='Verified', provider='sandbox', provider_txn_id=?, amount=?, verified_at=NOW() WHERE id = ?", [$txn, $amount, $pend]);
            else q("INSERT INTO payments (order_id, method, provider, provider_txn_id, reference, amount, status, verified_at) VALUES (?,?,?,?,?,?, 'Verified', NOW())",
                   [$o['id'], $o['payment_method'], 'sandbox', $txn, $o['reference'], $amount]);
            $paid = (float)q("SELECT COALESCE((SELECT SUM(amount) FROM payments WHERE order_id = ? AND status = 'Verified'),0)
                - COALESCE((SELECT SUM(r.amount) FROM refunds r JOIN payments p ON p.id = r.payment_id WHERE p.order_id = ?),0)", [$o['id'], $o['id']])->fetchColumn();
            $ps = $paid + 0.001 >= (float)$lo['total_amount'] ? 'Paid' : 'Partially Paid';
            q('UPDATE orders SET amount_paid = ?, payment_status = ? WHERE id = ?', [$paid, $ps, $o['id']]);
            if ($paid + 0.001 >= (float)$lo['amount_due_now']) {
                q("UPDATE orders SET status='Payment Verified' WHERE id = ?", [$o['id']]);
                q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?,?,?,?,'system',NULL)",
                  [$o['id'], 'Awaiting Payment', 'Payment Verified', 'Sandbox payment succeeded (' . $txn . ')']);
            }
            audit('customer', (int)$c['id'], 'sandbox_payment', 'order', (int)$o['id'], money($amount) . ' ' . $txn . ' ' . $detail);
            $pdo->commit();
            queue_mail((string)$o['contact_email'], 'Payment received for order ' . $o['reference'], "Hello " . $o['contact_name'] . ",\n\nWe received your TEST-MODE payment of " . money($amount) . " (" . $txn . "). " . mail_button('View my order', app_url('/order.php?ref=' . urlencode((string)$o['reference']))) . setting('business_name'));
            flash('Payment successful (test mode). Receipt reference ' . $txn . '.');
            redirect('/order.php?ref=' . urlencode($ref));
        } catch (UserError $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash($ex->getMessage(), 'warn'); redirect('/order.php?ref=' . urlencode($ref));
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('pay_test: ' . $ex->getMessage());
            $errors[] = 'The test payment could not be completed. Nothing was charged.';
        }
    }
}
page_header('Pay for order ' . $o['reference']);
?>
<h1 class="h1s">Pay for order <?= e($o['reference']) ?></h1>
<div class="notice"><strong>Test mode.</strong> This is a simulated gateway for demonstration. Never enter a real card or PIN. No money moves.</div>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<div class="panel w480">
  <div class="line"><span>Amount to pay</span><strong><?= money($amount) ?></strong></div>
  <form method="post" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="ref" value="<?= e($ref) ?>">
  <?php if ($isCard): ?>
    <div class="field"><label for="card">Test card number</label><input id="card" name="card" inputmode="numeric" maxlength="23" placeholder="4242 4242 4242 4242" required></div>
    <div class="field"><label for="exp">Expiry (MM/YY)</label><input id="exp" name="exp" maxlength="7" placeholder="12/30" required></div>
    <div class="field"><label for="cvc">CVC</label><input id="cvc" name="cvc" inputmode="numeric" maxlength="3" placeholder="123" required></div>
    <p class="mute"><small>Card data is checked and then discarded; only the last 4 digits are written to the audit log.</small></p>
  <?php else: ?>
    <div class="field"><label for="phone">Test mobile money number</label><input id="phone" name="phone" inputmode="numeric" placeholder="0770000000" required></div>
    <div class="field"><label for="pin">PIN</label><input id="pin" name="pin" type="password" inputmode="numeric" maxlength="4" placeholder="1234" required></div>
  <?php endif; ?>
  <button class="btn block" data-confirm="<?= e('Pay ' . money($amount) . ' now? This is a test payment, no real money moves.') ?>" data-confirm-title="Confirm payment" data-confirm-ok="Yes, pay">Pay <?= money($amount) ?> (test)</button></form>
  <p><a href="/order.php?ref=<?= urlencode($ref) ?>">Back to order</a></p>
</div>
<?php page_footer();
