<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
release_expired_reservations();

$g = fn(string $k): string => trim((string)($_GET[$k] ?? ''));
$where = []; $p = [];
$avail = $g('avail');
if ($avail === 'Available' || $avail === 'Reserved') { $where[] = 'v.status = ?'; $p[] = $avail; }
else $where[] = "v.status IN ('Available','Reserved')";
if ($g('q') !== '') {
    $where[] = "CONCAT_WS(' ', v.year, v.make, v.model, v.grade, v.stock_ref, v.colour) LIKE ?";
    $p[] = '%' . addcslashes($g('q'), '%_\\') . '%';
}
foreach (['make' => 'v.make', 'model' => 'v.model'] as $k => $col) if ($g($k) !== '') { $where[] = "$col = ?"; $p[] = $g($k); }
if (ctype_digit($g('category'))) { $where[] = 'v.category_id = ?'; $p[] = (int)$g('category'); }
if (ctype_digit($g('min_price'))) { $where[] = 'v.price >= ?'; $p[] = (int)$g('min_price'); }
if (ctype_digit($g('max_price'))) { $where[] = 'v.price <= ?'; $p[] = (int)$g('max_price'); }
if (ctype_digit($g('min_year'))) { $where[] = 'v.year >= ?'; $p[] = (int)$g('min_year'); }
if (ctype_digit($g('max_year'))) { $where[] = 'v.year <= ?'; $p[] = (int)$g('max_year'); }
if (ctype_digit($g('max_km')))   { $where[] = 'v.mileage_km <= ?'; $p[] = (int)$g('max_km'); }
foreach (['fuel' => ['v.fuel_type', ['Petrol','Diesel','Hybrid','Electric','LPG']],
          'trans' => ['v.transmission', ['Automatic','Manual']],
          'cond' => ['v.vehicle_condition', ['New','Foreign Used','Locally Used']]] as $k => [$col, $ok])
    if (in_array($g($k), $ok, true)) { $where[] = "$col = ?"; $p[] = $g($k); }

$sorts = ['new' => 'v.created_at DESC, v.id DESC', 'price_asc' => 'v.price ASC', 'price_desc' => 'v.price DESC',
          'year_desc' => 'v.year DESC', 'km_asc' => 'v.mileage_km ASC'];
$sort = array_key_exists($g('sort'), $sorts) ? $g('sort') : 'new';
$per = 12;
$page = max(1, (int)($g('page') ?: 1));
$sqlWhere = ' WHERE ' . implode(' AND ', $where);
$total = (int)q("SELECT COUNT(*) FROM vehicles v $sqlWhere", $p)->fetchColumn();
$pages = max(1, (int)ceil($total / $per));
$page = min($page, $pages);
$offset = ($page - 1) * $per;
$rows = q(VEHICLE_SELECT . $sqlWhere . ' ORDER BY ' . $sorts[$sort] . " LIMIT $per OFFSET $offset", $p)->fetchAll();

$makes = q("SELECT DISTINCT make FROM vehicles WHERE status IN ('Available','Reserved') ORDER BY make")->fetchAll(PDO::FETCH_COLUMN);
$cats = q('SELECT id, name FROM categories WHERE is_active = 1 ORDER BY sort_order')->fetchAll();
$wish = customer_wishlist_ids();
$qs = fn(array $over) => '/vehicles.php?' . http_build_query(array_filter(array_merge($_GET, $over), fn($x) => $x !== '' && $x !== null));
$sel = fn(string $k, string $v) => $g($k) === $v ? ' selected' : '';

page_header('Cars for sale');
?>
<h1 class="h1s">Cars for sale</h1>
<div class="catalog">
<form class="filters" method="get" action="/vehicles.php">
  <div class="field"><label for="q">Search</label><input id="q" name="q" value="<?= e($g('q')) ?>" placeholder="Make, model, stock no."></div>
  <div class="field"><label for="make">Make</label><select id="make" name="make"><option value="">Any make</option>
    <?php foreach ($makes as $m): ?><option<?= $sel('make', $m) ?>><?= e($m) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="model">Model</label><select id="model" name="model" data-models-for="make" data-selected="<?= e($g('model')) ?>"><option value="">Any model</option>
    <?php if ($g('model') !== ''): ?><option selected><?= e($g('model')) ?></option><?php endif; ?></select></div>
  <div class="field"><label for="category">Category</label><select id="category" name="category"><option value="">All</option>
    <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"<?= $g('category') === (string)$c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
  <div class="row">
    <div class="field"><label for="min_price">Min price</label><input id="min_price" type="number" name="min_price" value="<?= e($g('min_price')) ?>"></div>
    <div class="field"><label for="max_price">Max price</label><input id="max_price" type="number" name="max_price" value="<?= e($g('max_price')) ?>"></div>
    <div class="field"><label for="min_year">Year from</label><input id="min_year" type="number" name="min_year" value="<?= e($g('min_year')) ?>"></div>
    <div class="field"><label for="max_year">Year to</label><input id="max_year" type="number" name="max_year" value="<?= e($g('max_year')) ?>"></div>
  </div>
  <div class="field"><label for="max_km">Max mileage (km)</label><input id="max_km" type="number" name="max_km" value="<?= e($g('max_km')) ?>"></div>
  <div class="field"><label for="fuel">Fuel</label><select id="fuel" name="fuel"><option value="">Any</option>
    <?php foreach (['Petrol','Diesel','Hybrid','Electric','LPG'] as $o): ?><option<?= $sel('fuel', $o) ?>><?= $o ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="trans">Transmission</label><select id="trans" name="trans"><option value="">Any</option>
    <?php foreach (['Automatic','Manual'] as $o): ?><option<?= $sel('trans', $o) ?>><?= $o ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="cond">Condition</label><select id="cond" name="cond"><option value="">Any</option>
    <?php foreach (['New','Foreign Used','Locally Used'] as $o): ?><option<?= $sel('cond', $o) ?>><?= $o ?></option><?php endforeach; ?></select></div>
  <div class="field"><label for="avail">Availability</label><select id="avail" name="avail"><option value="">Available and reserved</option>
    <?php foreach (['Available','Reserved'] as $o): ?><option<?= $sel('avail', $o) ?>><?= $o ?> only</option><?php endforeach; ?></select></div>
  <div class="field"><label for="sort">Sort by</label><select id="sort" name="sort">
    <?php foreach (['new' => 'Newest', 'price_asc' => 'Price: low to high', 'price_desc' => 'Price: high to low', 'year_desc' => 'Year: newest', 'km_asc' => 'Mileage: lowest'] as $k => $l): ?>
      <option value="<?= $k ?>"<?= $sort === $k ? ' selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
  <button class="btn block">Apply filters</button>
  <p><a href="/vehicles.php">Clear all</a></p>
</form>
<section>
  <p class="mute"><?= $total ?> vehicle<?= $total === 1 ? '' : 's' ?> found</p>
  <?php if ($rows): ?><div class="grid"><?php foreach ($rows as $v) vehicle_card($v, $wish); ?></div>
  <?php else: ?><div class="panel"><strong>No vehicles match those filters.</strong><p>Try removing a filter, or <a href="/vehicles.php">see all cars</a>.</p></div><?php endif; ?>
  <?php if ($pages > 1): ?><nav class="pager" aria-label="Pages">
    <?php for ($i = 1; $i <= $pages; $i++): ?>
      <?php if ($i === $page): ?><span class="cur" aria-current="page"><?= $i ?></span>
      <?php else: ?><a href="<?= e($qs(['page' => $i])) ?>"><?= $i ?></a><?php endif; ?>
    <?php endfor; ?></nav><?php endif; ?>
</section>
</div>
<script src="/assets/app.js"></script>
<?php page_footer();
