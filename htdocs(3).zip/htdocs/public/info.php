<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';

// Static business and policy pages. Business details are pulled from Admin > Settings.
// Review every page against your real business practice and Ugandan law before going live.
$biz = e(setting('business_name', 'Our dealership'));
$mail = e(setting('email')); $phone = e(setting('phone')); $addr = e(setting('address'));
$hours = e(setting('reservation_hours', '48'));
$dep = (int)setting('deposit_percent', '0');
$fee = money((float)setting('delivery_fee', '0'));

$pages = [
'about' => ['About us', "
<p>$biz sells inspected used vehicles online in Uganda. Every listing shows the real price, mileage, grade and photos, so you can compare cars from your phone before you visit.</p>
<h2>What we promise</h2>
<ul><li>Honest listings: price, mileage and condition grade are shown on every vehicle.</li>
<li>A fair reservation: a vehicle you order is held for $hours hours while we confirm it.</li>
<li>Clear payment: you pay by bank transfer, cash, or (in demo mode) a test card; staff verify every payment before it counts.</li>
<li>Real support: call, WhatsApp, email or use the <a href=\"/contact.php\">contact form</a>.</li></ul>
<p>Visit us: $addr</p>"],

'delivery' => ['Delivery and handover', "
<p>Choose <strong>Pickup</strong> or <strong>Delivery</strong> at checkout.</p>
<h2>How your order reaches you</h2>
<ol><li><strong>Order placed:</strong> your vehicle is reserved for $hours hours.</li>
<li><strong>We confirm:</strong> we check the vehicle is ready and contact you.</li>
<li><strong>You pay:</strong> by the method you chose; we verify the payment.</li>
<li><strong>Processing:</strong> final inspection, cleaning, documents and registration paperwork.</li>
<li><strong>Ready for handover:</strong> we tell you by email and phone.</li>
<li><strong>Handover:</strong> you collect from our showroom, or we deliver to your address.</li></ol>
<h2>Pickup</h2><p>Free. Bring your ID and the order reference. Inspect the car and sign the handover note.</p>
<h2>Delivery</h2>
<p>Delivery fee: <strong>$fee</strong> within our delivery area (confirmed when we call you). Usual time after full payment: 2 to 5 working days, depending on documents and location. The car is delivered on a carrier or driven by our staff, insured while in our care.</p>
<h2>Buying from another country</h2>
<p>Regional buyers (for example Rwanda, South Sudan, DR Congo, Kenya) can order too. Export paperwork, transit and import duties are the buyer's responsibility; we supply the invoice, ownership documents and inspection record, and can recommend a clearing agent. Prices are in Uganda shillings (UGX).</p>"],

'faq' => ['Frequently asked questions', "
<h2>Is my order a final sale?</h2><p>No. Placing an order is a purchase request. The sale is confirmed after we confirm the vehicle and verify your payment.</p>
<h2>How long is a car held for me?</h2><p>$hours hours. If payment is not made in that time the car goes back on sale.</p>
<h2>How can I pay?</h2><p>Bank transfer or cash at the showroom. In demo mode you can also pay with a test card or test mobile money. A real mobile money and card gateway can be added later.</p>
<h2>Can I pay a deposit?</h2><p>" . ($dep > 0 ? "Yes, a $dep% reservation deposit; the balance is due before handover." : "Deposits are not currently offered.") . "</p>
<h2>Can I see the car first?</h2><p>Yes. Book a test drive from any vehicle page.</p>
<h2>What if the car is not as described?</h2><p>You can request a return from your order page within " . return_days() . " days of handover. See our <a href=\"/info.php?p=refunds\">returns and refunds policy</a>.</p>
<h2>How do I track my order?</h2><p>Log in and open My orders.</p>
<h2>Still stuck?</h2><p><a href=\"/contact.php\">Contact us</a> by form, phone or WhatsApp.</p>"],

'terms' => ['Terms of sale', "
<p>These terms apply to purchases from $biz. By placing an order you accept them.</p>
<h2>1. Orders</h2><p>An order is a request to buy. We may decline it, for example if the vehicle is no longer available. The sale is concluded when we confirm in writing and your payment is verified.</p>
<h2>2. Prices</h2><p>Prices are in Uganda shillings (UGX), as shown on the vehicle page when you order. Delivery or registration costs, if any, are shown at checkout.</p>
<h2>3. Reservation</h2><p>A vehicle is held for $hours hours after you order. Unpaid reservations expire automatically.</p>
<h2>4. Payment</h2><p>Payments count only after our finance team verifies them. Beware of fraud: confirm our bank details with us by phone before sending money.</p>
<h2>5. Vehicle condition</h2><p>Each vehicle is described as accurately as we can, including mileage and grade. You are welcome to inspect it before handover.</p>
<h2>6. Ownership and risk</h2><p>Ownership passes when the full price is paid and the vehicle is handed over. Risk passes at handover.</p>
<h2>7. Cancellation and refunds</h2><p>See the <a href=\"/info.php?p=refunds\">returns and refunds policy</a>.</p>
<h2>8. Liability and law</h2><p>Nothing here limits your rights under Ugandan consumer law. These terms are governed by the laws of Uganda.</p>
<p class=\"mute\">Contact: $mail, $phone.</p>"],

'refunds' => ['Returns and refunds', "
<h2>Before handover</h2><p>You can cancel an order at any time before handover. If you have paid, we refund the verified amount to the account or mobile money number you used, normally within 7 working days. Contact us to cancel.</p>
<h2>If we cannot supply the car</h2><p>If the vehicle is sold, damaged or fails our final inspection, we refund every shilling you paid, or offer another vehicle if you prefer.</p>
<h2>After handover</h2><p>Inspect the car at handover. If something is not as described (for example wrong mileage, undisclosed damage or a hidden fault), you can <strong>request a return within " . return_days() . " days</strong> of handover from your order page. We review every request within one working day. If it is approved, you bring the car back, we inspect it, and we refund the amount we agree with you (the full price when the description was wrong). Normal wear and faults that start after handover are not covered.</p><h2>How a return works</h2><ol><li>Open your order and press <strong>Request a return</strong>.</li><li>Our team approves or declines it and emails you.</li><li>You return the vehicle; we mark it received.</li><li>We record your refund and close the case.</li></ol>
<h2>Deposits</h2><p>A reservation deposit is refunded if we cancel; if you cancel after the car was prepared for you, we may keep a fair amount for costs we actually incurred, explained to you in writing.</p>
<p class=\"mute\">Questions: $mail.</p>"],

'privacy' => ['Privacy policy', "
<p>$biz respects your privacy and handles personal data under Uganda's Data Protection and Privacy Act, 2019.</p>
<h2>What we collect</h2><ul><li>Account details: name, email, phone, password (stored only as a one-way hash).</li>
<li>Order details: vehicles ordered, delivery location, payment status. We do not store card numbers.</li>
<li>Messages you send us, and wishlist and cart items.</li>
<li>Technical data about visits through Google Analytics (pages viewed, approximate location, device).</li></ul>
<h2>Why</h2><p>To process orders and payments, deliver vehicles, give support, prevent fraud and improve the site.</p>
<h2>Sharing</h2><p>We do not sell your data. We share it only with service providers needed to run the shop (hosting, email, analytics) or when the law requires.</p>
<h2>Keeping it safe</h2><p>We use HTTPS, hashed passwords, access control for staff and audit logs.</p>
<h2>Your rights</h2><p>You can ask to see, correct or delete your personal data, or object to its use, by writing to $mail. We keep order and payment records as long as the law requires.</p>
<h2>Complaints</h2><p>You may also complain to the Personal Data Protection Office in Uganda.</p>"],

'cookies' => ['Cookies', "
<p>This site uses:</p>
<ul><li><strong>Essential cookie (CARSESS):</strong> keeps you logged in and holds your cart. It is deleted when you close your browser.</li>
<li><strong>Analytics cookies (Google Analytics 4):</strong> count visits, pages and traffic sources so we can improve the site. They do not identify you by name.</li></ul>
<p>You can block analytics cookies in your browser settings or with Google's opt-out add-on. The shop still works without them.</p>"],

'sustainability' => ['Ethics, sustainability and international trade', "
<h2>Honest selling</h2><p>We show the real mileage, grade and condition, never hide damage, and do not use fake urgency. Odometer tampering is a serious problem in used-car imports; we record mileage from the inspection report.</p>
<h2>Cleaner vehicles</h2><p>You can filter by fuel type and engine size to compare running costs and emissions. We favour newer, more efficient vehicles, and we do not sell cars that fail Uganda's import age and roadworthiness rules.</p>
<h2>Reuse over scrap</h2><p>Selling used vehicles extends their life. Old parts, oil and tyres from our preparation work go to licensed recyclers.</p>
<h2>Digital and paper waste</h2><p>Receipts and order updates are digital. Photos are compressed to save bandwidth for customers on mobile data.</p>
<h2>International buyers</h2><p>We welcome buyers from neighbouring countries, state prices in UGX, and provide the documents needed for export. Customers must follow their own country's import, emission and tax rules.</p>
<h2>Your data</h2><p>See our <a href=\"/info.php?p=privacy\">privacy policy</a>.</p>"],
];

$p = (string)($_GET['p'] ?? '');
if (!isset($pages[$p])) { http_response_code(404); page_header('Page not found'); echo '<div class="panel"><h1>Page not found</h1><p><a href="/">Home</a></p></div>'; page_footer(); exit; }
[$title, $body] = $pages[$p];
back_to('/', 'Back to home', true); page_header($title);
?>
<article class="panel prose w760"><h1 class="h1s"><?= e($title) ?></h1>
<?= $body ?>
<p class="mute"><small>Last updated <?= date('j F Y') ?>.</small></p></article>
<?php page_footer();
