<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/dash_layout.php';
$c = require_customer();
release_expired_reservations();
$rows = q('SELECT o.reference, o.status, o.payment_status, o.total_amount, o.amount_paid, o.created_at,
    (SELECT title FROM order_items WHERE order_id = o.id ORDER BY id LIMIT 1) AS title,
    (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items,
    (SELECT i.path FROM order_items oi JOIN vehicle_images i ON i.vehicle_id = oi.vehicle_id WHERE oi.order_id = o.id ORDER BY oi.id, i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS img
    FROM orders o WHERE o.customer_id = ? ORDER BY o.created_at DESC', [$c['id']])->fetchAll();
dash_header('My orders', 'orders');
dash_head('My orders', 'Every order you have placed and where it stands.');
if (!$rows): ?><div class="panel"><p class="empty">You have not placed an order yet.</p><a class="btn" href="/vehicles.php">Browse cars</a></div>
<?php else: ?><div class="panel flush"><div class="scroll"><table class="dt"><thead><tr><th>Vehicle</th><th>Order</th><th>Placed</th><th>Order status</th><th>Payment</th><th class="right">Total</th></tr></thead><tbody>
<?php foreach ($rows as $o): ?>
  <tr><td><div class="vcell"><?= vthumb($o['img'], (string)$o['title']) ?><span><b><?= e((string)$o['title']) ?></b><?php if ((int)$o['items'] > 1): ?><small>+<?= (int)$o['items'] - 1 ?> more</small><?php endif; ?></span></div></td>
    <td class="num-cell"><a href="/order.php?ref=<?= urlencode($o['reference']) ?>"><?= e($o['reference']) ?></a></td>
    <td class="num-cell"><?= e(date('j M Y, H:i', strtotime($o['created_at']))) ?></td>
    <td><?= order_pill($o['status']) ?></td><td><?= pay_pill($o['payment_status']) ?></td>
    <td class="right num-cell"><?= money($o['total_amount']) ?></td></tr>
<?php endforeach; ?></tbody></table></div></div><?php endif; dash_footer();
