<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
if (current_customer()) redirect('/');
$errors = []; $old = ['full_name' => '', 'email' => '', 'phone' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($old as $k => $_) $old[$k] = trim((string)($_POST[$k] ?? ''));
    $pw = (string)($_POST['password'] ?? '');
    if (rate_limited('reg:' . client_ip(), 5, 3600)) $errors[] = 'Too many sign-ups from this connection. Try again later.';
    if ($old['full_name'] === '' || mb_strlen($old['full_name']) > 120) $errors[] = 'Enter your full name.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email']) > 160) $errors[] = 'Enter a valid email address.';
    if (!preg_match('/^\+?[0-9 ]{9,15}$/', $old['phone'])) $errors[] = 'Enter a valid phone number, for example +256 700 000000.';
    if (strlen($pw) < 8) $errors[] = 'Use a password of at least 8 characters.';
    if ($pw !== (string)($_POST['password2'] ?? '')) $errors[] = 'The two passwords do not match.';
    if (!$errors && q('SELECT 1 FROM customers WHERE email = ?', [strtolower($old['email'])])->fetchColumn()) $errors[] = 'An account with this email already exists. Log in instead.';
    if (!$errors) {
        q('INSERT INTO customers (full_name, email, phone, password_hash) VALUES (?,?,?,?)',
          [$old['full_name'], strtolower($old['email']), $old['phone'], password_hash($pw, PASSWORD_DEFAULT)]);
        $id = (int)db()->lastInsertId();
        q('UPDATE customers SET marketing_opt_in = ? WHERE id = ?', [!empty($_POST['marketing_opt_in']) ? 1 : 0, $id]);
        audit('customer', $id, 'register', 'customer', $id);
        send_verification($id, $old['full_name'], strtolower($old['email']));
        customer_login($id);
        flash('Welcome! Your account is ready. We sent a link to your email: please confirm it before placing an order.');
        redirect(safe_return($_GET['next'] ?? null, '/'));
    }
}
back_to('/', 'Back to home'); page_header('Create account');
?>
<div class="narrow panel"><h1 class="h1s">Create your account</h1>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<form method="post"><?= csrf_field() ?>
  <div class="field"><label for="fn">Full name</label><input id="fn" name="full_name" required autocomplete="name" value="<?= e($old['full_name']) ?>"></div>
  <div class="field"><label for="em">Email</label><input id="em" type="email" name="email" required autocomplete="email" value="<?= e($old['email']) ?>"></div>
  <div class="field"><label for="ph">Phone</label><input id="ph" name="phone" required autocomplete="tel" inputmode="tel" value="<?= e($old['phone']) ?>"></div>
  <div class="field"><label for="pw">Password (8+ characters)</label><input id="pw" type="password" name="password" required minlength="8" autocomplete="new-password"></div>
  <div class="field"><label for="pw2">Confirm password</label><input id="pw2" type="password" name="password2" required minlength="8" autocomplete="new-password"></div>
  <label><input class="chk" type="checkbox" name="marketing_opt_in" value="1"> Email me about new vehicle arrivals and promotions.</label>
  <button class="btn block">Create account</button>
</form><p>Already registered? <a href="/login.php<?= isset($_GET['next']) ? '?next=' . urlencode((string)$_GET['next']) : '' ?>">Log in</a></p></div>
<?php page_footer();
