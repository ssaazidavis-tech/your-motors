<?php
// TEMPORARY diagnostic. Upload to htdocs/public/diag.php, open /public/diag.php, then DELETE it.
ini_set('display_errors', '1');
error_reporting(E_ALL);
header('Content-Type: text/plain');

echo "PHP version: " . PHP_VERSION . "\n";
echo "pdo_mysql:   " . (extension_loaded('pdo_mysql') ? 'yes' : 'NO') . "\n";
echo "mbstring:    " . (extension_loaded('mbstring') ? 'yes' : 'NO') . "\n";
echo "fileinfo:    " . (extension_loaded('fileinfo') ? 'yes' : 'NO') . "\n\n";

$root = dirname(__DIR__);
echo ".env exists: " . (is_file("$root/.env") ? 'yes' : 'NO (wrong folder level?)') . "\n";
echo "app/bootstrap.php exists: " . (is_file("$root/app/bootstrap.php") ? 'yes' : 'NO') . "\n\n";

// Read .env (no passwords printed)
$env = [];
foreach (@file("$root/.env", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $l) {
    $l = trim($l);
    if ($l === '' || $l[0] === '#' || !str_contains($l, '=')) continue;
    [$k, $v] = explode('=', $l, 2);
    $env[trim($k)] = trim($v);
}
echo "DB_HOST: " . ($env['DB_HOST'] ?? '?') . "\nDB_NAME: " . ($env['DB_NAME'] ?? '?') . "\nDB_USER: " . ($env['DB_USER'] ?? '?') . "\n\n";

try {
    $pdo = new PDO(
        "mysql:host={$env['DB_HOST']};port=" . ($env['DB_PORT'] ?? '3306') . ";dbname={$env['DB_NAME']};charset=utf8mb4",
        $env['DB_USER'], $env['DB_PASS'] ?? '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "DB connection: OK\n";
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    echo "Tables found (" . count($tables) . "): " . ($tables ? implode(', ', $tables) : 'NONE - import schema.sql') . "\n";
} catch (Throwable $e) {
    echo "DB ERROR: " . $e->getMessage() . "\n";
}

echo "\n--- Loading the real app ---\n";
try {
    require $root . '/app/layout.php';
    echo "layout.php loaded OK\n";
    release_expired_reservations();
    echo "release_expired_reservations OK\n";
    echo "Vehicles: " . q('SELECT COUNT(*) FROM vehicles')->fetchColumn() . "\n";
} catch (Throwable $e) {
    echo get_class($e) . ": " . $e->getMessage() . "\n  at " . $e->getFile() . ':' . $e->getLine() . "\n";
}
