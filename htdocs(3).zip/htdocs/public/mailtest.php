<?php
// TEMPORARY. Upload to public/mailtest.php, open it in the browser, read the result, then DELETE it.
// It only ever emails the MAIL_USERNAME account itself.
ini_set('display_errors', '1'); error_reporting(E_ALL);
header('Content-Type: text/plain; charset=utf-8');
$_SERVER['REMOTE_ADDR'] ??= '127.0.0.1';
try { require dirname(__DIR__) . '/app/bootstrap.php'; } catch (Throwable $e) { exit('bootstrap failed: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine()); }

$host = (string)env('MAIL_HOST', ''); $user = (string)env('MAIL_USERNAME', ''); $pass = (string)env('MAIL_PASSWORD', '');
echo "1. SETTINGS READ FROM .env\n";
echo "   MAIL_HOST       = " . ($host ?: '(EMPTY - .env not read or MAIL_HOST missing)') . "\n";
echo "   MAIL_PORT       = " . env('MAIL_PORT', '(missing)') . "\n";
echo "   MAIL_ENCRYPTION = " . env('MAIL_ENCRYPTION', '(missing)') . "\n";
echo "   MAIL_USERNAME   = " . ($user ?: '(EMPTY)') . "\n";
echo "   MAIL_PASSWORD   = " . strlen(str_replace(' ', '', $pass)) . " characters (must be exactly 16)\n";
echo "   APP_URL         = " . env('APP_URL', '(missing)') . "\n\n";

echo "2. CAN THIS SERVER REACH GMAIL?\n";
foreach ([465, 587] as $port) {
    $t = microtime(true);
    $fp = @stream_socket_client(($port === 465 ? 'ssl://' : 'tcp://') . 'smtp.gmail.com:' . $port, $en, $es, 8);
    echo "   port $port: " . ($fp ? 'connected (' . round((microtime(true) - $t) * 1000) . ' ms)' : "BLOCKED/FAILED: $es ($en)") . "\n";
    if ($fp) fclose($fp);
}

echo "\n3. SENDING ONE TEST EMAIL TO $user\n";
$GLOBALS['mail_last_error'] = '';
$ok = $user !== '' && deliver_mail($user, 'Motors mail test ' . date('H:i:s'), "If you can read this, email works." . mail_button('Open the site', app_url()));
echo $ok ? "   RESULT: SENT OK. Check that inbox (and Spam).\n" : "   RESULT: FAILED\n   ERROR : " . ($GLOBALS['mail_last_error'] ?: 'unknown') . "\n";

echo "\n4. LAST 5 ROWS IN THE OUTBOX TABLE\n";
try {
    foreach (q('SELECT id, to_email, status, attempts, created_at FROM outbox ORDER BY id DESC LIMIT 5')->fetchAll() as $r) echo '   #' . implode(' | ', $r) . "\n";
} catch (Throwable $e) { echo '   outbox table problem: ' . $e->getMessage() . "\n"; }
