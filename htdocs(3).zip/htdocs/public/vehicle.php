<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
release_expired_reservations();

$id = (int)($_GET['id'] ?? 0);
$v = q(VEHICLE_SELECT . " WHERE v.id = ? AND v.status IN ('Available','Reserved','Sold')", [$id])->fetch();
if (!$v) { http_response_code(404); page_header('Vehicle not found'); echo '<div class="panel"><h1>Vehicle not found</h1><p><a href="/vehicles.php">Browse all cars</a></p></div>'; page_footer(); exit; }

$errors = [];
$cust = current_customer();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $type = in_array($_POST['type'] ?? '', ['Inquiry', 'Test Drive', 'Price Request'], true) ? $_POST['type'] : 'Inquiry';
    $name = trim((string)($_POST['name'] ?? '')); $phone = trim((string)($_POST['phone'] ?? ''));
    $email = trim((string)($_POST['email'] ?? '')); $msg = trim((string)($_POST['message'] ?? ''));
    $date = trim((string)($_POST['preferred_date'] ?? ''));
    if (rate_limited('inq:' . client_ip(), 5, 600)) $errors[] = 'Too many inquiries. Please wait a few minutes.';
    if ($name === '' || mb_strlen($name) > 120) $errors[] = 'Enter your name.';
    if (!preg_match('/^\+?[0-9 ]{9,15}$/', $phone)) $errors[] = 'Enter a valid phone number.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $errors[] = 'Enter a valid date.';
    if (mb_strlen($msg) > 2000) $errors[] = 'Message is too long.';
    if (!$errors) {
        q('INSERT INTO inquiries (vehicle_id, customer_id, type, name, phone, email, message, preferred_date) VALUES (?,?,?,?,?,?,?,?)',
          [$id, $cust['id'] ?? null, $type, $name, $phone, $email ?: null, $msg ?: null, $date ?: null]);
        notify_staff('New ' . strtolower($type) . ' request', $type . ' for ' . vehicle_title($v) . "\nName: $name\nPhone: $phone\nEmail: " . ($email ?: '-') . ($date ? "\nPreferred date: $date" : '') . ($msg ? "\nMessage: $msg" : ''));
        flash('Thanks. Our sales team will contact you shortly.');
        redirect('/vehicle.php?id=' . $id);
    }
}

$images = q('SELECT path FROM vehicle_images WHERE vehicle_id = ? ORDER BY is_primary DESC, sort_order, id', [$id])->fetchAll(PDO::FETCH_COLUMN);
$features = q('SELECT feature FROM vehicle_features WHERE vehicle_id = ? ORDER BY id', [$id])->fetchAll(PDO::FETCH_COLUMN);
$title = vehicle_title($v);
if ($_SERVER['REQUEST_METHOD'] === 'GET') ga_queue('view_item', ['value' => (float)$v['price'], 'items' => [ga_item($v)]]);
$pct = discount_pct($v);
$wished = in_array($id, customer_wishlist_ids(), true);
$cmp = in_array($id, $_SESSION['compare'] ?? [], true);
$canBuy = $v['status'] === 'Available' && !$v['price_on_request'];

back_to('/vehicles.php', 'Back to cars', true);
page_header($title, "$title for sale. " . ($v['mileage_km'] !== null ? number_format((int)$v['mileage_km']) . ' km. ' : '') . $v['transmission'] . ', ' . $v['fuel_type'] . '.');
foreach ($errors as $er) echo '<div class="flash err">' . e($er) . '</div>';
$spec = ['Stock no.' => $v['stock_ref'], 'Year' => $v['year'], 'Make' => $v['make'], 'Model' => $v['model'], 'Grade' => $v['grade'],
  'Category' => $v['category_name'], 'Condition' => $v['vehicle_condition'],
  'Mileage' => $v['mileage_km'] !== null ? number_format((int)$v['mileage_km']) . ' km' : null,
  'Engine' => $v['engine_cc'] ? number_format((int)$v['engine_cc']) . ' cc' : null, 'Fuel' => $v['fuel_type'],
  'Transmission' => $v['transmission'], 'Drivetrain' => $v['drivetrain'], 'Seats' => $v['seats'], 'Colour' => $v['colour']];
?>
<div class="detail">
  <section class="gallery">
    <div class="main">
      <?php if ($images): ?><img id="mainphoto" src="/uploads/<?= e($images[0]) ?>" alt="<?= e($title) ?>">
      <?php else: ?><span class="noimg"><?= e($v['make']) ?></span><?php endif; ?>
    </div>
    <?php if (count($images) > 1): ?><div class="actions"><?php foreach ($images as $im): ?>
      <a href="/uploads/<?= e($im) ?>" data-thumb="/uploads/<?= e($im) ?>"><img class="thumb" src="/uploads/<?= e($im) ?>" alt="" width="84" height="56"></a>
    <?php endforeach; ?></div><?php endif; ?>
    <h2>Description</h2>
    <p><?= nl2br(e($v['description'] ?: 'No description yet.')) ?></p>
    <?php if ($features): ?><h2>Features</h2><ul class="chips"><?php foreach ($features as $f): ?><li><?= e($f) ?></li><?php endforeach; ?></ul><?php endif; ?>
    <?php if ($v['inspection_notes']): ?><h2>Inspection</h2><p><?= nl2br(e($v['inspection_notes'])) ?></p><?php endif; ?>
  </section>
  <aside>
    <div class="panel">
      
      <h1 class="h1s"><?= e($title) ?></h1>
      <p><span class="pill <?= $v['status'] === 'Available' ? 'ok' : ($v['status'] === 'Reserved' ? 'warn' : 'bad') ?>"><?= e($v['status']) ?></span></p>
      <p class="price big"><?php if ($v['price_on_request']): ?>Ask for price<?php else: ?><?= money($v['price']) ?><?php if ($pct): ?> <s><?= money($v['original_price']) ?></s> <span class="pill ok"><?= $pct ?>% off</span><?php endif; ?><?php endif; ?></p>
      <?php if ($canBuy): ?>
        <form method="post" action="/cart.php"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="do" value="buy">
          <button class="btn block">Buy now</button></form><br>
        <form method="post" action="/cart.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="do" value="add">
          <button class="btn block alt">Add to cart</button></form>
      <?php elseif ($v['status'] === 'Reserved'): ?><div class="notice">Another customer has reserved this vehicle. If the reservation lapses it returns to stock. Send an inquiry to be contacted.</div>
      <?php elseif ($v['status'] === 'Sold'): ?><div class="notice">This vehicle has been sold. <a href="/vehicles.php">See similar cars</a>.</div><?php endif; ?>
      <?php $alertKind = $v['status'] === 'Reserved' ? 'available' : ($v['status'] === 'Available' && !$v['price_on_request'] ? 'price_drop' : null);
      if ($alertKind): $has = $cust && alert_has((int)$cust['id'], $id, $alertKind); ?>
      <form method="post" action="/alerts.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="kind" value="<?= e($alertKind) ?>">
        <button class="ghost block"><?= $has ? 'Alert on (tap to turn off)' : ($alertKind === 'available' ? 'Email me if it becomes available' : 'Email me if the price drops') ?></button></form>
      <?php endif; ?>
      <div class="actions">
        <form method="post" action="/wishlist.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= $id ?>"><button class="ghost" aria-pressed="<?= $wished ? 'true' : 'false' ?>"><?= $wished ? 'Saved' : 'Save' ?></button></form>
        <form method="post" action="/compare.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="do" value="<?= $cmp ? 'remove' : 'add' ?>"><button class="ghost"><?= $cmp ? 'Remove compare' : 'Compare' ?></button></form>
        <a class="ghost" href="https://wa.me/<?= e(setting('whatsapp')) ?>?text=<?= rawurlencode('Hello, I am interested in ' . $title . ' (' . $v['stock_ref'] . ')') ?>">WhatsApp</a>
      </div>
    </div>
    <div class="panel" id="inquiry"><h3>Send an inquiry or book a test drive</h3>
      <form method="post"><?= csrf_field() ?>
        <div class="field"><label for="type">I want to</label><select id="type" name="type">
          <option>Inquiry</option><option>Test Drive</option><option>Price Request</option></select></div>
        <div class="field"><label for="name">Name</label><input id="name" name="name" required maxlength="120" value="<?= e($cust['full_name'] ?? ($_POST['name'] ?? '')) ?>"></div>
        <div class="field"><label for="phone">Phone</label><input id="phone" name="phone" required inputmode="tel" value="<?= e($cust['phone'] ?? ($_POST['phone'] ?? '')) ?>"></div>
        <div class="field"><label for="email">Email (optional)</label><input id="email" type="email" name="email" value="<?= e($cust['email'] ?? ($_POST['email'] ?? '')) ?>"></div>
        <div class="field"><label for="pd">Preferred date (test drive)</label><input id="pd" type="date" name="preferred_date" min="<?= date('Y-m-d') ?>"></div>
        <div class="field"><label for="message">Message</label><textarea id="message" name="message" maxlength="2000"><?= e($_POST['message'] ?? '') ?></textarea></div>
        <button class="btn block">Send</button>
      </form></div>
    <div class="panel"><h3>Specifications</h3><dl class="specs">
      <?php foreach ($spec as $k => $val): if ($val === null || $val === '') continue; ?>
        <div><dt><?= e($k) ?></dt><dd><?= e((string)$val) ?></dd></div><?php endforeach; ?></dl></div>
  </aside>
</div>
<script src="/assets/app.js"></script>
<?php page_footer();
