<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$sum = review_summary();
$rows = q("SELECT r.rating, r.title, r.body, r.created_at, c.full_name, oi.title AS car
           FROM reviews r JOIN customers c ON c.id = r.customer_id
           JOIN order_items oi ON oi.order_id = r.order_id AND oi.vehicle_id = r.vehicle_id
           WHERE r.status = 'Approved' ORDER BY r.created_at DESC LIMIT 50")->fetchAll();
back_to('/', 'Back to home'); page_header('Customer reviews', 'Reviews from customers who bought a car from us.');
?>
<h1 class="h1s">Customer reviews</h1>
<?php if ($sum['count']): ?><p class="price"><?= e(stars((int)round($sum['avg']))) ?> <?= e((string)$sum['avg']) ?> / 5 <span class="mute">from <?= (int)$sum['count'] ?> review<?= $sum['count'] === 1 ? '' : 's' ?></span></p>
<?php else: ?><div class="panel"><p>No reviews yet. Buyers can review their car from their order page once the sale is completed.</p></div><?php endif; ?>
<?php foreach ($rows as $r): $first = explode(' ', trim($r['full_name']))[0]; ?>
<div class="panel"><p><strong><?= e(stars((int)$r['rating'])) ?></strong> <?= $r['title'] ? '<strong>' . e($r['title']) . '</strong>' : '' ?></p>
<?= $r['body'] ? '<p>' . nl2br(e($r['body'])) . '</p>' : '' ?>
<p class="mute"><?= e($first) ?> bought <?= e($r['car']) ?> · <?= e(date('j M Y', strtotime($r['created_at']))) ?></p></div>
<?php endforeach; page_footer();
