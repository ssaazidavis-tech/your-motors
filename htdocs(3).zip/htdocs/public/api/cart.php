<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
$items = []; $sub = 0.0;
foreach (cart_vehicles() as $v) {
    $ok = $v['status'] === 'Available'; if ($ok) $sub += (float)$v['price'];
    $items[] = ['id' => (int)$v['id'], 'title' => vehicle_title($v), 'price' => $ok ? money($v['price']) : 'No longer available', 'ok' => $ok,
                'img' => $v['img'] ? '/uploads/' . $v['img'] : null, 'url' => '/vehicle.php?id=' . (int)$v['id']];
}
$c = coupon_applied($sub); $d = $c ? coupon_discount($c, $sub) : 0.0;
echo json_encode(['items' => $items, 'subtotal' => money($sub), 'discount' => $d > 0 ? '-' . money($d) : null, 'coupon' => $c['code'] ?? null, 'total' => money($sub - $d), 'count' => count($items)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
