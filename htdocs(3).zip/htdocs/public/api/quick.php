<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
$v = q(VEHICLE_SELECT . " WHERE v.id = ? AND v.status IN ('Available','Reserved','Sold')", [(int)($_GET['id'] ?? 0)])->fetch();
if (!$v) { http_response_code(404); echo '{"error":"Not found"}'; exit; }
$specs = array_filter(['Year' => $v['year'], 'Mileage' => $v['mileage_km'] !== null ? number_format((int)$v['mileage_km']) . ' km' : null, 'Transmission' => $v['transmission'], 'Fuel' => $v['fuel_type'],
    'Engine' => $v['engine_cc'] ? number_format((int)$v['engine_cc']) . ' cc' : null, 'Seats' => $v['seats'], 'Colour' => $v['colour'], 'Condition' => $v['vehicle_condition']], fn($x) => $x !== null && $x !== '');
echo json_encode(['id' => (int)$v['id'], 'title' => vehicle_title($v), 'status' => $v['status'], 'price' => $v['price_on_request'] ? 'Ask for price' : money($v['price']),
    'img' => $v['img'] ? '/uploads/' . $v['img'] : null, 'specs' => $specs, 'url' => '/vehicle.php?id=' . (int)$v['id'],
    'canAdd' => $v['status'] === 'Available' && !$v['price_on_request']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
