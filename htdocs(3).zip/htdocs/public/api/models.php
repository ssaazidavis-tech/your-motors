<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
$make = (string)($_GET['make'] ?? '');
$rows = q("SELECT DISTINCT model FROM vehicles WHERE make = ? AND status IN ('Available','Reserved') ORDER BY model", [$make])->fetchAll(PDO::FETCH_COLUMN);
echo json_encode($rows, JSON_UNESCAPED_UNICODE);
