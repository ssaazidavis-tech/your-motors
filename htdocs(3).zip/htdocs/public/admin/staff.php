<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$me = require_staff('staff.manage');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'add') {
            $name = trim((string)($_POST['full_name'] ?? '')); $email = strtolower(trim((string)($_POST['email'] ?? ''))); $pw = (string)($_POST['password'] ?? '');
            $rid = q('SELECT id FROM roles WHERE code = ?', [(string)($_POST['role'] ?? '')])->fetchColumn();
            if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$rid) throw new UserError('Enter a name, a valid email and a role.');
            if (strlen($pw) < 10) throw new UserError('Use a password of at least 10 characters.');
            q('INSERT INTO users (role_id, full_name, email, password_hash) VALUES (?,?,?,?)', [$rid, $name, $email, password_hash($pw, PASSWORD_DEFAULT)]);
            audit('staff', (int)$me['id'], 'staff_created', 'user', (int)db()->lastInsertId(), $email); flash('Staff account created.');
        } elseif ($do === 'toggle' || $do === 'password') {
            $uid = (int)($_POST['id'] ?? 0);
            $u = q('SELECT u.id, u.is_active, r.code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?', [$uid])->fetch();
            if (!$u) throw new UserError('Account not found.');
            if ($do === 'toggle') {
                if ($uid === (int)$me['id']) throw new UserError('You cannot deactivate your own account.');
                if ($u['is_active'] && $u['code'] === 'admin' && (int)q("SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id WHERE r.code='admin' AND u.is_active=1")->fetchColumn() <= 1) throw new UserError('Keep at least one active administrator.');
                q('UPDATE users SET is_active = ? WHERE id = ?', [$u['is_active'] ? 0 : 1, $uid]); audit('staff', (int)$me['id'], 'staff_toggled', 'user', $uid); flash('Account updated.');
            } else {
                $pw = (string)($_POST['password'] ?? ''); if (strlen($pw) < 10) throw new UserError('Use a password of at least 10 characters.');
                q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($pw, PASSWORD_DEFAULT), $uid]); audit('staff', (int)$me['id'], 'staff_password_reset', 'user', $uid); flash('Password changed.');
            }
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    catch (PDOException $ex) { flash('That email is already used.', 'warn'); }
    redirect('/admin/staff.php');
}
$roles = q('SELECT code, label FROM roles ORDER BY id')->fetchAll();
$rows = q('SELECT u.id, u.full_name, u.email, u.is_active, u.last_login_at, r.label FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.id')->fetchAll();
admin_header('Staff'); ?>
<h1 class="h1s">Staff accounts</h1>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="do" value="add"><h3>Add staff member</h3><div class="row">
<div class="field"><label>Full name</label><input name="full_name" required></div><div class="field"><label>Email</label><input type="email" name="email" required></div>
<div class="field"><label>Role</label><select name="role"><?php foreach ($roles as $r) echo '<option value="' . e($r['code']) . '">' . e($r['label']) . '</option>'; ?></select></div>
<div class="field"><label>Temporary password (10+ characters)</label><input type="password" name="password" minlength="10" required autocomplete="new-password"></div></div><button class="btn">Create account</button></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Name</th><th>Role</th><th>Last login</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($rows as $u): ?><tr><td><?= e($u['full_name']) ?><br><span class="mute"><?= e($u['email']) ?></span></td><td><?= e($u['label']) ?></td><td><?= $u['last_login_at'] ? e(date('j M Y, H:i', strtotime($u['last_login_at']))) : 'Never' ?></td>
<td><?= $u['is_active'] ? 'Active' : 'Inactive' ?></td><td class="actions">
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="ghost" data-confirm="<?= $u['is_active'] ? 'Deactivate this staff account? They will no longer be able to log in.' : 'Activate this staff account so they can log in again?' ?>" data-confirm-ok="<?= $u['is_active'] ? 'Yes, deactivate' : 'Yes, activate' ?>"<?= $u['is_active'] ? ' data-confirm-danger' : '' ?>><?= $u['is_active'] ? 'Deactivate' : 'Activate' ?></button></form>
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="password"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input type="password" name="password" placeholder="New password" minlength="10" required autocomplete="new-password"><button class="ghost">Set password</button></form></td></tr><?php endforeach; ?></tbody></table></div>
<?php admin_footer();
