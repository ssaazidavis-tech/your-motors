<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('orders.view');
$st = (string)($_GET['status'] ?? ''); $oref = trim((string)($_GET['order'] ?? ''));
$statuses = ['Requested', 'Approved', 'Received', 'Completed', 'Rejected'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    try {
        $id = (int)($_POST['id'] ?? 0); $do = (string)($_POST['do'] ?? '');
        if ($do === 'approve' || $do === 'reject') {
            require_staff('orders.manage');
            decide_return($id, $do === 'approve' ? 'Approved' : 'Rejected', (string)($_POST['note'] ?? ''), $s);
            flash($do === 'approve' ? 'Return approved. The customer was emailed.' : 'Return rejected. The customer was emailed.');
        } elseif ($do === 'receive') {
            require_staff('orders.manage');
            receive_return($id, $s);
            flash('Marked as received. The vehicle is now a Draft: inspect it, then relist it from Inventory.');
        } elseif ($do === 'complete') {
            $amt = (float)str_replace(',', '', (string)($_POST['refund'] ?? '0'));
            require_staff($amt > 0 ? 'payments.verify' : 'orders.manage');
            complete_return($id, $amt, (string)($_POST['note'] ?? ''), $s);
            flash('Return completed.');
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    redirect('/admin/returns.php' . ($st !== '' ? '?status=' . urlencode($st) : ''));
}

$w = []; $p = [];
if (in_array($st, $statuses, true)) { $w[] = 'r.status = ?'; $p[] = $st; }
if ($oref !== '') { $w[] = 'o.reference = ?'; $p[] = $oref; }
$rows = q('SELECT r.*, o.reference, o.contact_name, o.contact_phone, o.amount_paid, oi.title, oi.stock_ref, oi.price, u.full_name AS decider
  FROM order_returns r JOIN orders o ON o.id = r.order_id JOIN order_items oi ON oi.order_id = r.order_id AND oi.vehicle_id = r.vehicle_id LEFT JOIN users u ON u.id = r.decided_by'
  . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . " ORDER BY FIELD(r.status,'Requested','Approved','Received','Completed','Rejected'), r.id DESC LIMIT 200", $p)->fetchAll();
$canManage = staff_can('orders.manage'); $canRefund = staff_can('payments.verify');
$tone = ['Requested' => 'warn', 'Approved' => 'ok', 'Received' => 'ok', 'Completed' => 'ok', 'Rejected' => 'bad'];
admin_header('Returns'); ?>
<h1 class="h1s">Returns</h1>
<form class="actions" method="get"><select name="status" aria-label="Status"><option value="">Any status</option><?php foreach ($statuses as $o) echo '<option' . ($st === $o ? ' selected' : '') . '>' . e($o) . '</option>'; ?></select>
<input name="order" placeholder="Order reference" value="<?= e($oref) ?>"><button class="btn small">Filter</button></form>
<p class="mute">Flow: <strong>Requested</strong> → Approved or Rejected → <strong>Received</strong> (vehicle is back) → <strong>Completed</strong> (refund recorded). The return period is <?= return_days() ?> days (change it in Settings).</p>
<?php foreach ($rows as $r): ?>
<div class="panel">
  <h3><a href="/admin/order.php?ref=<?= urlencode($r['reference']) ?>"><?= e($r['reference']) ?></a> · <?= e($r['title']) ?> (<?= e($r['stock_ref']) ?>) <?= pill($r['status'], $tone[$r['status']] ?? '') ?></h3>
  <p class="mute"><?= e($r['contact_name']) ?>, <?= e($r['contact_phone']) ?> · Requested <?= e(date('j M Y, H:i', strtotime($r['created_at']))) ?> · Price <?= money($r['price']) ?> · Paid on order <?= money($r['amount_paid']) ?></p>
  <p><strong><?= e($r['reason']) ?></strong><br><?= nl2br(e((string)$r['details'])) ?></p>
  <?php if ($r['decided_at']): ?><p class="mute"><?= e($r['status'] === 'Rejected' ? 'Rejected' : 'Approved') ?> by <?= e((string)$r['decider']) ?> on <?= e(date('j M Y', strtotime($r['decided_at']))) ?><?= $r['decision_note'] ? ': ' . e($r['decision_note']) : '' ?></p><?php endif; ?>
  <?php if ($r['status'] === 'Completed'): ?><p class="mute">Refund <?= money($r['refund_amount']) ?>. <?= e((string)$r['outcome_note']) ?></p><?php endif; ?>

  <?php if ($r['status'] === 'Requested' && $canManage): ?>
  <div class="actions">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="do" value="approve"><input name="note" placeholder="Note to customer (optional)" maxlength="255">
      <button class="btn small" data-confirm="Approve this return? The customer is emailed and asked to bring the vehicle back." data-confirm-title="Approve return?" data-confirm-ok="Yes, approve">Approve</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="do" value="reject"><input name="note" placeholder="Reason for rejecting (required)" required maxlength="255">
      <button class="btn small alt" data-confirm="Reject this return? The customer is emailed your reason." data-confirm-title="Reject return?" data-confirm-ok="Yes, reject" data-confirm-danger>Reject</button></form>
  </div>
  <?php elseif ($r['status'] === 'Approved' && $canManage): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="do" value="receive">
    <button class="btn small" data-confirm="Only confirm when the vehicle is physically back. It will be taken off the sold list and set to Draft until it is inspected." data-confirm-title="Vehicle received?" data-confirm-ok="Yes, vehicle is back">Mark vehicle received</button></form>
  <?php elseif ($r['status'] === 'Received' && ($canManage || $canRefund)): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="do" value="complete">
    <div class="field"><label>Refund to the customer (UGX, 0 for none; max <?= e(money(min((float)$r['price'], (float)$r['amount_paid']))) ?>)<?= $canRefund ? '' : ' (finance must record a refund above 0)' ?></label><input name="refund" required inputmode="numeric" value="0"></div>
    <div class="field"><label>Outcome note</label><input name="note" required minlength="5" maxlength="255" placeholder="e.g. Full refund, brake fault confirmed"></div>
    <button class="btn small alt" data-confirm="This records the refund and closes the case. It cannot be undone. Only enter money you have actually returned." data-confirm-title="Complete this return?" data-confirm-ok="Yes, complete return" data-confirm-danger>Record refund and complete</button></form>
  <?php endif; ?>
</div>
<?php endforeach; if (!$rows) echo '<p>No returns match.</p>'; ?>
<?php admin_footer();
