<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
require_staff('orders.view');
release_expired_reservations();
$st = (string)($_GET['status'] ?? ''); $ps = (string)($_GET['pay'] ?? ''); $qv = trim((string)($_GET['q'] ?? ''));
$from = (string)($_GET['from'] ?? ''); $to = (string)($_GET['to'] ?? '');
$w = []; $p = [];
if ($st !== '') { $w[] = 'o.status = ?'; $p[] = $st; }
if ($ps !== '') { $w[] = 'o.payment_status = ?'; $p[] = $ps; }
if ($qv !== '') { $w[] = "CONCAT_WS(' ', o.reference, c.full_name, c.email, c.phone) LIKE ?"; $p[] = '%' . addcslashes($qv, '%_\\') . '%'; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $w[] = 'o.created_at >= ?'; $p[] = $from . ' 00:00:00'; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) { $w[] = 'o.created_at <= ?'; $p[] = $to . ' 23:59:59'; }
$rows = q('SELECT o.reference, o.status, o.payment_status, o.total_amount, o.amount_paid, o.created_at, c.full_name FROM orders o JOIN customers c ON c.id = o.customer_id'
    . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY o.id DESC LIMIT 200', $p)->fetchAll();
$statuses = ['Awaiting Confirmation','Awaiting Payment','Payment Verified','Order Processing','Ready for Handover','Completed','Cancelled'];
admin_header('Orders'); ?>
<h1 class="h1s">Orders</h1>
<form class="actions" method="get"><input name="q" placeholder="Reference, customer, phone" value="<?= e($qv) ?>">
<select name="status"><option value="">Any status</option><?php foreach ($statuses as $o) echo '<option' . ($st === $o ? ' selected' : '') . '>' . e($o) . '</option>'; ?></select>
<select name="pay"><option value="">Any payment</option><?php foreach (['Unpaid','Pending Verification','Partially Paid','Paid','Refunded'] as $o) echo '<option' . ($ps === $o ? ' selected' : '') . '>' . e($o) . '</option>'; ?></select>
<input type="date" name="from" value="<?= e($from) ?>" aria-label="From date"><input type="date" name="to" value="<?= e($to) ?>" aria-label="To date"><button class="btn small">Filter</button></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Reference</th><th>Customer</th><th>Placed</th><th>Status</th><th>Payment</th><th class="right">Total</th><th class="right">Paid</th></tr></thead><tbody>
<?php foreach ($rows as $o): ?><tr><td><a href="/admin/order.php?ref=<?= urlencode($o['reference']) ?>"><?= e($o['reference']) ?></a></td><td><?= e($o['full_name']) ?></td>
<td><?= e(date('j M Y', strtotime($o['created_at']))) ?></td><td><?= e($o['status']) ?></td><td><?= e($o['payment_status']) ?></td><td class="right"><?= money($o['total_amount']) ?></td><td class="right"><?= money($o['amount_paid']) ?></td></tr><?php endforeach; ?>
<?php if (!$rows) echo '<tr><td colspan="7">No orders match.</td></tr>'; ?></tbody></table></div>
<?php admin_footer();
