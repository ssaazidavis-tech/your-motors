<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('dashboard.view');
release_expired_reservations();

// Period: the last 7, 30 or 90 days including today, compared with the same number of days before it.
$range = (int)($_GET['range'] ?? 30);
if (!in_array($range, [7, 30, 90], true)) $range = 30;
$today = new DateTimeImmutable('today');
$start = $today->modify('-' . ($range - 1) . ' days');
$d0 = $start->format('Y-m-d');
$d1 = $today->modify('+1 day')->format('Y-m-d');
$dp = $start->modify('-' . $range . ' days')->format('Y-m-d');
$vs = 'vs previous ' . $range . ' days';

$one = fn(string $sql, array $p = []) => q($sql, $p)->fetchColumn();
$cnt = fn(string $sql, array $p = []): int => (int)$one($sql, $p);
$canOrders = staff_can('orders.view');
$canCust   = staff_can('customers.view');
$canInq    = staff_can('inquiries.manage');
$canInv    = staff_can('inventory.manage');
$showMoney = staff_can('payments.verify') || staff_can('reports.view') || $s['role'] === 'admin';
// Revenue = verified payments received minus refunds paid out in the period. It is not profit.
$net = fn(string $a, string $b): float =>
      (float)$one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status = 'Verified' AND verified_at >= ? AND verified_at < ?", [$a, $b])
    - (float)$one('SELECT COALESCE(SUM(amount),0) FROM refunds WHERE processed_at >= ? AND processed_at < ?', [$a, $b]);

$inv = q('SELECT status, COUNT(*) c FROM vehicles GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);

// ----- Trend + mix -----
$labels = [];
for ($i = 0; $i < $range; $i++) $labels[] = $start->modify("+$i days")->format('Y-m-d');
$orders = $revenue = null;
if ($canOrders) {
    $ob = q('SELECT DATE(created_at) d, COUNT(*) c FROM orders WHERE created_at >= ? AND created_at < ? GROUP BY DATE(created_at)', [$d0, $d1])->fetchAll(PDO::FETCH_KEY_PAIR);
    $orders = array_map(fn(string $d): int => (int)($ob[$d] ?? 0), $labels);
    if ($showMoney) {
        $pb = q("SELECT DATE(verified_at) d, SUM(amount) s FROM payments WHERE status = 'Verified' AND verified_at >= ? AND verified_at < ? GROUP BY DATE(verified_at)", [$d0, $d1])->fetchAll(PDO::FETCH_KEY_PAIR);
        $rb = q('SELECT DATE(processed_at) d, SUM(amount) s FROM refunds WHERE processed_at >= ? AND processed_at < ? GROUP BY DATE(processed_at)', [$d0, $d1])->fetchAll(PDO::FETCH_KEY_PAIR);
        $revenue = array_map(fn(string $d): float => max(0.0, (float)($pb[$d] ?? 0) - (float)($rb[$d] ?? 0)), $labels);
    }
}
$mix = q("SELECT c.name AS label, COUNT(*) AS n FROM vehicles v JOIN categories c ON c.id = v.category_id
          WHERE v.status IN ('Available','Reserved') GROUP BY c.id, c.name ORDER BY n DESC, c.name")->fetchAll();
if (count($mix) > 6) {
    $rest = array_slice($mix, 5);
    $mix = array_slice($mix, 0, 5);
    $mix[] = ['label' => 'Other', 'n' => array_sum(array_column($rest, 'n'))];
}
$mixTotal = (int)array_sum(array_column($mix, 'n'));

// ----- Tables -----
if ($canOrders) {
    $recent = q('SELECT o.reference, o.status, o.payment_status, o.total_amount, o.created_at, c.full_name,
        (SELECT title FROM order_items WHERE order_id = o.id ORDER BY id LIMIT 1) AS title,
        (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items,
        (SELECT i.path FROM order_items oi JOIN vehicle_images i ON i.vehicle_id = oi.vehicle_id WHERE oi.order_id = o.id ORDER BY oi.id, i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS img
        FROM orders o JOIN customers c ON c.id = o.customer_id ORDER BY o.id DESC LIMIT 6')->fetchAll();
    $top = q("SELECT v.make, v.model, COUNT(*) AS n,
        (SELECT i.path FROM vehicle_images i JOIN vehicles v2 ON v2.id = i.vehicle_id WHERE v2.make = v.make AND v2.model = v.model ORDER BY i.is_primary DESC, i.id LIMIT 1) AS img
        FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN vehicles v ON v.id = oi.vehicle_id
        WHERE o.status = 'Completed' GROUP BY v.make, v.model ORDER BY n DESC, v.make LIMIT 4")->fetchAll();
}
if ($canInq)  $enqs = q('SELECT i.name, i.type, i.status, i.created_at, v.make, v.model FROM inquiries i LEFT JOIN vehicles v ON v.id = i.vehicle_id ORDER BY i.id DESC LIMIT 5')->fetchAll();
if ($canCust) $custs = q('SELECT full_name, email, created_at FROM customers ORDER BY id DESC LIMIT 5')->fetchAll();
$act = $s['role'] === 'admin'
    ? q("SELECT a.actor_type, a.action, a.detail, a.created_at, u.full_name FROM audit_log a LEFT JOIN users u ON a.actor_type = 'staff' AND u.id = a.actor_id ORDER BY a.id DESC LIMIT 6")->fetchAll()
    : [];

// ----- Needs attention -----
$todo = [];
if ($canOrders) {
    $todo[] = [$cnt("SELECT COUNT(*) FROM orders WHERE status = 'Awaiting Confirmation'"), 'Orders to confirm', '/admin/orders.php?' . http_build_query(['status' => 'Awaiting Confirmation'])];
    if (staff_can('payments.verify')) $todo[] = [$cnt("SELECT COUNT(*) FROM orders WHERE payment_status = 'Pending Verification'"), 'Payments to verify', '/admin/orders.php?' . http_build_query(['pay' => 'Pending Verification'])];
    $todo[] = [$cnt("SELECT COUNT(*) FROM reservations WHERE status = 'Active' AND expires_at < DATE_ADD(NOW(), INTERVAL 12 HOUR)"), 'Reservations ending within 12 hours', '/admin/orders.php'];
}
if ($canInq) $todo[] = [$cnt("SELECT COUNT(*) FROM inquiries WHERE status = 'New'"), 'New enquiries', '/admin/inquiries.php'];
if ($canInv) $todo[] = [$cnt("SELECT COUNT(*) FROM vehicles v WHERE v.status IN ('Available','Draft') AND NOT EXISTS (SELECT 1 FROM vehicle_images i WHERE i.vehicle_id = v.id)"), 'Cars without photos', '/admin/vehicles.php'];

$quick = array_filter([
    $canInv    ? ['/admin/vehicle_edit.php', 'Add a vehicle', 'plus'] : null,
    $canOrders ? ['/admin/orders.php', 'Manage orders', 'cart'] : null,
    $canInq    ? ['/admin/inquiries.php', 'Reply to enquiries', 'chat'] : null,
    staff_can('reports.view') ? ['/admin/reports.php', 'View reports', 'chart'] : null,
]);

$seg = '<nav class="seg" aria-label="Period">';
foreach ([7, 30, 90] as $r) $seg .= '<a href="?range=' . $r . '"' . ($r === $range ? ' aria-current="true"' : '') . '>' . $r . ' days</a>';
$seg .= '</nav>';

admin_header('Dashboard');
dash_head('Dashboard', date('j M', strtotime($d0)) . ' to ' . date('j M Y') . '. Figures are for this period unless a card says otherwise.', $seg);
?>
<div class="dgrid">
<div class="dcol">

  <div class="kpis">
    <?= kpi('car', 'y', 'Cars for sale', (string)(int)($inv['Available'] ?? 0),
        (int)($inv['Reserved'] ?? 0) . ' reserved, ' . (int)($inv['Sold'] ?? 0) . ' sold', $canInv ? '/admin/vehicles.php' : '', 'View inventory') ?>
    <?php if ($canOrders): $oNow = $cnt('SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ?', [$d0, $d1]); $oPrev = $cnt('SELECT COUNT(*) FROM orders WHERE created_at >= ? AND created_at < ?', [$dp, $d0]); ?>
      <?= kpi('cart', 'k', 'Orders', (string)$oNow, delta($oNow, $oPrev, $vs), '/admin/orders.php', 'View orders') ?>
    <?php endif; if ($canCust): $cNow = $cnt('SELECT COUNT(*) FROM customers WHERE created_at >= ? AND created_at < ?', [$d0, $d1]); $cPrev = $cnt('SELECT COUNT(*) FROM customers WHERE created_at >= ? AND created_at < ?', [$dp, $d0]); ?>
      <?= kpi('users', 'g', 'New customers', (string)$cNow, delta($cNow, $cPrev, $vs), '/admin/customers.php', 'View customers') ?>
    <?php endif; if ($showMoney): $rNow = $net($d0, $d1); $rPrev = $net($dp, $d0); ?>
      <?= kpi('card', 'w', 'Revenue (UGX)', short_num($rNow), delta($rNow, $rPrev, $vs), staff_can('reports.view') ? '/admin/reports.php' : '', 'View reports') ?>
    <?php endif; if ($canInq): $tdNew = $cnt("SELECT COUNT(*) FROM inquiries WHERE status = 'New' AND type = 'Test Drive'"); ?>
      <?= kpi('chat', 'y', 'New enquiries', (string)$cnt("SELECT COUNT(*) FROM inquiries WHERE status = 'New'"), $tdNew . ' of them test drives', '/admin/inquiries.php', 'View enquiries') ?>
    <?php endif; ?>
  </div>

  <div class="two">
    <?php if ($orders !== null): ?>
    <section class="panel" aria-labelledby="so-h">
      <div class="phead"><h2 id="so-h">Sales overview</h2>
        <div class="legend"><?php if ($revenue !== null): ?><span><i class="rev"></i>Revenue (UGX)</span><?php endif; ?><span><i class="ord"></i>Orders</span></div></div>
      <div class="chartbox"><?= svg_trend($labels, $orders, $revenue) ?></div>
      <?php if ($revenue !== null): ?><p class="sub note">Revenue is verified payments received, less refunds. It is not profit.</p><?php endif; ?>
    </section>
    <?php endif; ?>
    <section class="panel" aria-labelledby="vm-h">
      <div class="phead"><h2 id="vm-h">Stock by type</h2></div>
      <?php if (!$mixTotal): ?><p class="empty">No cars are for sale yet.</p><?php else: ?>
      <div class="donut"><?= svg_donut($mix, (string)$mixTotal, 'cars') ?>
        <ul class="lg"><?php foreach ($mix as $i => $m): ?><li><i class="k<?= min($i, 5) ?>"></i><?= e((string)$m['label']) ?><b><?= (int)$m['n'] ?> (<?= (int)round($m['n'] / $mixTotal * 100) ?>%)</b></li><?php endforeach; ?></ul></div>
      <?php endif; ?>
    </section>
  </div>

  <?php if ($canOrders): ?>
  <section class="panel flush" aria-labelledby="rc-h">
    <div class="phead"><h2 id="rc-h">Recent orders</h2><a href="/admin/orders.php">View all</a></div>
    <?php if (!$recent): ?><p class="empty">No orders yet.</p><?php else: ?><div class="scroll"><table class="dt"><thead><tr><th>Vehicle</th><th>Order</th><th>Status</th><th class="right">Total</th></tr></thead><tbody>
    <?php foreach ($recent as $o): ?>
      <tr><td><div class="vcell"><?= vthumb($o['img'], (string)$o['title']) ?><span><b><?= e((string)$o['title']) ?></b><small><?= e($o['full_name']) ?><?= (int)$o['items'] > 1 ? ' (+' . ((int)$o['items'] - 1) . ' more)' : '' ?></small></span></div></td>
        <td class="num-cell"><a href="/admin/order.php?ref=<?= urlencode($o['reference']) ?>"><?= e($o['reference']) ?></a><div class="sub"><?= e(date('j M', strtotime($o['created_at']))) ?></div></td>
        <td><div class="stack"><?= order_pill($o['status']) ?><?= pay_pill($o['payment_status']) ?></div></td>
        <td class="right num-cell"><?= money($o['total_amount']) ?></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </section>
  <?php endif; ?>

  <div class="three">
    <?php if ($canOrders): ?>
    <section class="panel" aria-labelledby="tp-h"><div class="phead"><h2 id="tp-h">Top sellers</h2></div>
      <?php if (!$top): ?><p class="empty">Completed sales will rank here.</p><?php endif; ?>
      <?php foreach ($top as $i => $t): ?><div class="rank"><span class="pos"><?= $i + 1 ?></span>
        <span class="grow"><b><?= e($t['make'] . ' ' . $t['model']) ?></b><small><?= (int)$t['n'] ?> sold</small></span></div><?php endforeach; ?>
    </section>
    <?php endif; if ($canInq): ?>
    <section class="panel" aria-labelledby="le-h"><div class="phead"><h2 id="le-h">Latest enquiries</h2><a href="/admin/inquiries.php">View all</a></div>
      <?php if (!$enqs): ?><p class="empty">No enquiries yet.</p><?php endif; ?>
      <?php foreach ($enqs as $en): ?><div class="rank"><span class="grow"><b><?= e($en['name']) ?></b><small><?= e($en['type']) ?><?= $en['make'] ? ': ' . e($en['make'] . ' ' . $en['model']) : '' ?></small></span>
        <span class="r"><?= pill($en['status'], $en['status'] === 'New' ? 'warn' : ($en['status'] === 'Contacted' ? 'sig' : '')) ?></span></div><?php endforeach; ?>
    </section>
    <?php endif; if ($canCust): ?>
    <section class="panel" aria-labelledby="cu-h"><div class="phead"><h2 id="cu-h">Recent customers</h2><a href="/admin/customers.php">View all</a></div>
      <?php if (!$custs): ?><p class="empty">No customers yet.</p><?php endif; ?>
      <?php foreach ($custs as $cu): ?><div class="rank"><span class="avatar sm"><?= e(initials($cu['full_name'])) ?></span>
        <span class="grow"><b><?= e($cu['full_name']) ?></b><small><?= e($cu['email']) ?></small></span></div><?php endforeach; ?>
    </section>
    <?php endif; ?>
  </div>

</div>
<aside class="rail" aria-label="Shortcuts">

  <?php if ($todo): ?>
  <section class="panel" aria-labelledby="na-h">
    <div class="phead"><h2 id="na-h">Needs attention</h2></div>
    <nav class="todo" aria-label="Needs attention">
    <?php foreach ($todo as [$count, $label, $href]): ?>
      <a href="<?= e($href) ?>"<?= $count ? '' : ' class="zero-row"' ?>><span class="n<?= $count ? '' : ' zero' ?>"><?= (int)$count ?></span><?= e($label) ?><?= icon('chevron', 16) ?></a>
    <?php endforeach; ?></nav>
  </section>
  <?php endif; if ($quick): ?>
  <section class="panel" aria-labelledby="qa-h">
    <div class="phead"><h2 id="qa-h">Quick actions</h2></div>
    <nav class="qa" aria-label="Quick actions"><?php foreach ($quick as [$href, $label, $ic]): ?>
      <a href="<?= e($href) ?>"><span class="ico"><?= icon($ic, 18) ?></span><?= e($label) ?><?= icon('chevron', 16) ?></a>
    <?php endforeach; ?></nav>
  </section>
  <?php endif; if ($act): ?>
  <section class="panel" aria-labelledby="ay-h">
    <div class="phead"><h2 id="ay-h">System activity</h2></div>
    <ul class="feed"><?php foreach ($act as $a): ?>
      <li><span class="dot"><?= icon('clock', 15) ?></span><div><?= e(ucfirst(str_replace('_', ' ', $a['action']))) ?><?= $a['detail'] ? ': ' . e(mb_strimwidth((string)$a['detail'], 0, 60, '...')) : '' ?>
        <small><?= e($a['full_name'] ?: ucfirst($a['actor_type'])) ?>, <?= e(time_ago($a['created_at'])) ?></small></div></li>
    <?php endforeach; ?></ul>
  </section>
  <?php endif; ?>

</aside>
</div>
<?php admin_footer();
