<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
if (current_staff()) redirect('/admin/');
$uid = (int)($_SESSION['2fa_uid'] ?? 0);
if (!$uid || time() - (int)($_SESSION['2fa_at'] ?? 0) > 300) { unset($_SESSION['2fa_uid'], $_SESSION['2fa_at']); flash('Please log in again.', 'warn'); redirect('/admin/login.php'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $code = trim((string)($_POST['code'] ?? ''));
    if (rate_limited('2fa:' . $uid, 5, 600)) { $error = 'Too many attempts. Log in again in 10 minutes.'; }
    else {
        $u = q('SELECT id, totp_secret_enc, totp_last_step FROM users WHERE id = ? AND is_active = 1 AND totp_enabled = 1', [$uid])->fetch();
        $secret = $u ? secret_decrypt((string)$u['totp_secret_enc']) : null;
        $step = $secret ? totp_verify($secret, $code, (int)$u['totp_last_step']) : null;
        $ok = false;
        if ($step !== null && q('UPDATE users SET totp_last_step = ? WHERE id = ? AND totp_last_step < ?', [$step, $uid, $step])->rowCount()) $ok = true;
        elseif ($u && preg_match('/^[A-Za-z0-9]{4}-?[A-Za-z0-9]{4}$/', $code) && backup_code_use($uid, strlen($code) === 8 ? substr($code, 0, 4) . '-' . substr($code, 4) : $code)) $ok = true;
        if ($ok) {
            session_regenerate_id(true);
            unset($_SESSION['2fa_uid'], $_SESSION['2fa_at']);
            $_SESSION['uid'] = $uid;
            q('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$uid]);
            audit('staff', $uid, 'login', 'user', $uid, 'two-factor');
            redirect('/admin/');
        }
        audit('staff', $uid, 'two_factor_failed', 'user', $uid);
        $error = 'That code is not correct.';
    }
}
admin_header('Two-factor check'); ?>
<div class="narrow panel"><h1 class="h1s">Enter your code</h1>
<?php if ($error) echo '<div class="flash err">' . e($error) . '</div>'; ?>
<p class="mute">Open your authenticator app and type the 6-digit code, or use one of your backup codes.</p>
<form method="post"><?= csrf_field() ?><div class="field"><label for="c">Code</label><input id="c" name="code" required autocomplete="one-time-code" autofocus maxlength="12"></div><button class="btn block">Verify</button></form>
<p class="mute"><a href="/admin/login.php">Start again</a></p></div>
<?php admin_footer();
