<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('settings.manage');
const UPLOAD_DIR = __DIR__ . '/../uploads/';
$text = ['business_name' => 'Business name', 'phone' => 'Phone', 'email' => 'Sales email', 'address' => 'Address', 'whatsapp' => 'WhatsApp number (digits only, with country code)'];
$nums = ['reservation_hours' => ['Reservation hours', 1, 720], 'deposit_percent' => ['Deposit percent (0 turns deposits off)', 0, 90], 'delivery_fee' => ['Delivery fee (UGX)', 0, 100000000], 'cart_limit' => ['Max vehicles per cart', 1, 10], 'return_days' => ['Return period after handover, in days (0 turns returns off)', 0, 90]];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $errs = []; $set = [];
    foreach ($text as $k => $_) { $v = trim((string)($_POST[$k] ?? '')); if ($v === '' || mb_strlen($v) > 200) $errs[] = "$text[$k] is required (max 200 characters)."; $set[$k] = $v; }
    if (!preg_match('/^[0-9]{9,15}$/', $set['whatsapp'] ?? '')) $errs[] = 'WhatsApp number must be 9 to 15 digits, no plus sign or spaces.';
    if (!filter_var($set['email'] ?? '', FILTER_VALIDATE_EMAIL)) $errs[] = 'Enter a valid sales email.';
    foreach ($nums as $k => [$l, $min, $max]) { $v = (string)($_POST[$k] ?? ''); if (!ctype_digit($v) || (int)$v < $min || (int)$v > $max) $errs[] = "$l must be between $min and $max."; $set[$k] = $v; }
    $bank = trim((string)($_POST['bank_details'] ?? '')); if (mb_strlen($bank) > 1000) $errs[] = 'Bank details are too long.'; $set['bank_details'] = $bank;
    // Home page banner photo: shrunk to 2000 px wide and saved as JPEG; "remove" clears it.
    $hero = setting('hero_image'); $newHero = $hero;
    $hf = $_FILES['hero_image'] ?? null;
    if ($hf && $hf['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($hf['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($hf['tmp_name'])) $errs[] = 'The banner photo failed to upload.';
        elseif ($hf['size'] > 15 * 1024 * 1024) $errs[] = 'The banner photo is over 15 MB.';
        else {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($hf['tmp_name']);
            if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true) || @getimagesize($hf['tmp_name']) === false) $errs[] = 'The banner photo must be a real JPG, PNG or WebP image.';
            else {
                $name = 'hero-' . bin2hex(random_bytes(8)) . '.jpg';
                if (save_as_jpeg($hf['tmp_name'], $mime, UPLOAD_DIR . $name, 2000)) $newHero = $name;
                else $errs[] = 'The banner photo could not be processed. PHP needs the GD extension enabled.';
            }
        }
    } elseif (!empty($_POST['remove_hero'])) $newHero = '';
    $set['hero_image'] = $newHero;
    // Optional banner video: MP4 or WebM, max 40 MB, stored as-is under a random name.
    $vid = setting('hero_video'); $newVid = $vid;
    $vf = $_FILES['hero_video'] ?? null;
    if ($vf && $vf['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($vf['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($vf['tmp_name'])) $errs[] = 'The banner video failed to upload (it may be over the server upload limit).';
        elseif ($vf['size'] > 40 * 1024 * 1024) $errs[] = 'The banner video is over 40 MB. Compress it to under 10 MB for fast loading.';
        else {
            $vmime = (new finfo(FILEINFO_MIME_TYPE))->file($vf['tmp_name']);
            $vext = ['video/mp4' => 'mp4', 'video/webm' => 'webm'][$vmime] ?? null;
            if ($vext === null) $errs[] = 'The banner video must be a real MP4 or WebM file.';
            else {
                $vname = 'hero-' . bin2hex(random_bytes(8)) . '.' . $vext;
                if (move_uploaded_file($vf['tmp_name'], UPLOAD_DIR . $vname)) $newVid = $vname;
                else $errs[] = 'The banner video could not be saved. Check that the uploads folder is writable.';
            }
        }
    } elseif (!empty($_POST['remove_video'])) $newVid = '';
    $set['hero_video'] = $newVid;
    if ($errs && $newVid !== $vid && $newVid !== '') @unlink(UPLOAD_DIR . $newVid);
    if ($errs && $newHero !== $hero && $newHero !== '') @unlink(UPLOAD_DIR . $newHero);
    if (!$errs) {
        if ($hero !== '' && $hero !== $newHero) @unlink(UPLOAD_DIR . basename($hero));
        if ($vid !== '' && $vid !== $newVid) @unlink(UPLOAD_DIR . basename($vid));
        foreach ($set as $k => $v) q('INSERT INTO settings (k, v) VALUES (?,?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$k, $v]);
        // Only methods that need no provider may be switched on; provider methods wait for a real integration.
        $on = (array)($_POST['methods'] ?? []);
        foreach (q('SELECT code FROM payment_methods WHERE requires_provider = 0')->fetchAll(PDO::FETCH_COLUMN) as $code)
            q('UPDATE payment_methods SET enabled = ? WHERE code = ?', [in_array($code, $on, true) ? 1 : 0, $code]);
        audit('staff', (int)$s['id'], 'settings_updated', 'settings', null, 'by ' . $s['email']);
        flash('Settings saved.'); redirect('/admin/settings.php');
    }
    foreach ($errs as $er) flash($er, 'err');
}
$methods = q('SELECT * FROM payment_methods ORDER BY sort_order')->fetchAll();
admin_header('Settings'); ?>
<h1 class="h1s">Business settings</h1>
<form method="post" class="panel" enctype="multipart/form-data"><?= csrf_field() ?><div class="row">
<?php foreach ($text as $k => $l) echo '<div class="field"><label>' . e($l) . '</label><input name="' . $k . '" required value="' . e($_POST[$k] ?? setting($k)) . '"></div>'; ?>
<?php foreach ($nums as $k => [$l]) echo '<div class="field"><label>' . e($l) . '</label><input type="number" name="' . $k . '" required value="' . e($_POST[$k] ?? setting($k)) . '"></div>'; ?></div>
<div class="field"><label for="hero_image">Home page banner photo (JPG, PNG or WebP, wide landscape works best)</label>
<?php if (setting('hero_image')): ?><p><img src="/uploads/<?= e(setting('hero_image')) ?>" alt="Current banner photo" width="320"> </p><label><input class="chk" type="checkbox" name="remove_hero" value="1"> Remove the current banner photo</label><?php endif; ?>
<input id="hero_image" type="file" name="hero_image" accept="image/jpeg,image/png,image/webp" data-compress data-max="2000">
<small id="photo-status" role="status" aria-live="polite">The photo is shrunk and saved as JPEG automatically. Leave empty to keep the current one.</small></div>
<div class="field"><label for="hero_video">Home page banner video (optional, MP4 or WebM, under 40 MB; 5 to 10 MB works best)</label>
<?php if (setting('hero_video')): ?><p><video src="/uploads/<?= e(setting('hero_video')) ?>" width="320" muted controls preload="metadata"></video></p><label><input class="chk" type="checkbox" name="remove_video" value="1"> Remove the current banner video</label><?php endif; ?>
<input id="hero_video" type="file" name="hero_video" accept="video/mp4,video/webm">
<small>Plays silently and loops behind the headline; the banner photo above is shown while it loads and on slow connections. Leave empty to keep the current one.</small></div>
<div class="field"><label>Bank details shown to customers who pay by transfer</label><textarea name="bank_details"><?= e($_POST['bank_details'] ?? setting('bank_details')) ?></textarea></div>
<h3>Payment methods</h3>
<?php foreach ($methods as $m): ?><label><input class="chk" type="checkbox" name="methods[]" value="<?= e($m['code']) ?>"<?= $m['enabled'] ? ' checked' : '' ?><?= $m['requires_provider'] ? ' disabled' : '' ?>> <?= e($m['label']) ?><?= $m['requires_provider'] ? ' (needs a payment provider integration, not available yet)' : '' ?></label><?php endforeach; ?>
<br><button class="btn">Save settings</button></form><script src="/assets/photo-compress.js" defer></script><?php admin_footer();
