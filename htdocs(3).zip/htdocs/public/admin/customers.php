<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
require_staff('customers.view');
$qv = trim((string)($_GET['q'] ?? ''));
$rows = q("SELECT c.id, c.full_name, c.email, c.phone, c.created_at, COUNT(o.id) AS orders, COALESCE(SUM(o.amount_paid),0) AS paid
  FROM customers c LEFT JOIN orders o ON o.customer_id = c.id AND o.status <> 'Cancelled'
  WHERE CONCAT_WS(' ', c.full_name, c.email, c.phone) LIKE ? GROUP BY c.id ORDER BY c.id DESC LIMIT 200", ['%' . addcslashes($qv, '%_\\') . '%'])->fetchAll();
admin_header('Customers'); ?>
<h1 class="h1s">Customers</h1>
<form class="actions" method="get"><input name="q" placeholder="Name, email or phone" value="<?= e($qv) ?>"><button class="btn small">Search</button></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th class="right">Orders</th><th class="right">Verified paid</th></tr></thead><tbody>
<?php foreach ($rows as $c): ?><tr><td><?= e($c['full_name']) ?></td><td><?= e($c['email']) ?></td><td><?= e($c['phone']) ?></td><td><?= e(date('j M Y', strtotime($c['created_at']))) ?></td><td class="right"><?= (int)$c['orders'] ?></td><td class="right"><?= money($c['paid']) ?></td></tr><?php endforeach; ?>
<?php if (!$rows) echo '<tr><td colspan="6">No customers found.</td></tr>'; ?></tbody></table></div><?php admin_footer();
