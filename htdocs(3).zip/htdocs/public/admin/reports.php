<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('reports.view');
$valid = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d) !== false;
$from = $valid($_GET['from'] ?? null) ? $_GET['from'] : date('Y-m-01');
$to = $valid($_GET['to'] ?? null) ? $_GET['to'] : date('Y-m-d');
$a = $from . ' 00:00:00'; $b = $to . ' 23:59:59';
$dr = [$a, $b];

// key => [title, SQL, params, money columns, column to total]
$R = [
 'inventory' => ['Inventory by status (current, ignores dates)',
   "SELECT status AS Status, COUNT(*) AS Vehicles, COALESCE(SUM(price),0) AS `Listed value` FROM vehicles GROUP BY status ORDER BY FIELD(status,'Available','Reserved','Sold','Draft','Archived')", [], ['Listed value'], null],
 'stock' => ['Reserved and sold vehicles (current)',
   "SELECT v.stock_ref AS Stock, CONCAT(v.year,' ',v.make,' ',v.model) AS Vehicle, v.status AS Status, v.price AS Price FROM vehicles v WHERE v.status IN ('Reserved','Sold') ORDER BY v.status, v.stock_ref", [], ['Price'], null],
 'orders' => ['Orders by date and status',
   "SELECT o.reference AS Reference, c.full_name AS Customer, o.status AS Status, o.payment_status AS Payment, o.total_amount AS Total, o.amount_paid AS Paid, DATE(o.created_at) AS Placed FROM orders o JOIN customers c ON c.id=o.customer_id WHERE o.created_at BETWEEN ? AND ? ORDER BY o.id DESC", $dr, ['Total','Paid'], null],
 'sales' => ['Completed vehicle sales (by handover date)',
   "SELECT DATE(h.created_at) AS Completed, o.reference AS Reference, c.full_name AS Customer, GROUP_CONCAT(oi.title SEPARATOR '; ') AS Vehicles, o.total_amount AS Total FROM orders o JOIN order_status_history h ON h.order_id=o.id AND h.to_status='Completed' JOIN customers c ON c.id=o.customer_id JOIN order_items oi ON oi.order_id=o.id WHERE h.created_at BETWEEN ? AND ? GROUP BY o.id, h.created_at ORDER BY h.created_at DESC", $dr, ['Total'], 'Total'],
 'revenue' => ['Gross verified payments (before refunds, not profit)',
   "SELECT DATE(p.verified_at) AS Date, o.reference AS Order_ref, p.method AS Method, p.provider_txn_id AS Reference, p.amount AS Amount FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.status='Verified' AND p.verified_at BETWEEN ? AND ? ORDER BY p.verified_at DESC", $dr, ['Amount'], 'Amount'],
 'refunds' => ['Refunds issued',
   "SELECT DATE(r.processed_at) AS Date, o.reference AS Order_ref, r.reason AS Reason, u.full_name AS Approved_by, r.amount AS Amount FROM refunds r JOIN payments p ON p.id=r.payment_id JOIN orders o ON o.id=p.order_id JOIN users u ON u.id=r.approved_by WHERE r.processed_at BETWEEN ? AND ? ORDER BY r.id DESC", $dr, ['Amount'], 'Amount'],
 'outstanding' => ['Outstanding balances (open orders, current)',
   "SELECT o.reference AS Reference, c.full_name AS Customer, c.phone AS Phone, o.status AS Status, o.total_amount AS Total, o.amount_paid AS Paid, (o.total_amount-o.amount_paid) AS Balance FROM orders o JOIN customers c ON c.id=o.customer_id WHERE o.status NOT IN ('Cancelled','Completed') AND o.total_amount>o.amount_paid ORDER BY Balance DESC", [], ['Total','Paid','Balance'], 'Balance'],
 'methods' => ['Verified payments by method',
   "SELECT method AS Method, COUNT(*) AS Payments, SUM(amount) AS Amount FROM payments WHERE status='Verified' AND verified_at BETWEEN ? AND ? GROUP BY method ORDER BY Amount DESC", $dr, ['Amount'], 'Amount'],
 'categories' => ['Popular categories (vehicles ordered, excluding cancelled)',
   "SELECT cat.name AS Category, COUNT(*) AS Vehicles_ordered, SUM(oi.price) AS Value FROM order_items oi JOIN orders o ON o.id=oi.order_id AND o.status<>'Cancelled' JOIN vehicles v ON v.id=oi.vehicle_id JOIN categories cat ON cat.id=v.category_id WHERE o.created_at BETWEEN ? AND ? GROUP BY cat.id ORDER BY Vehicles_ordered DESC", $dr, ['Value'], null],
 'inquiries' => ['Customer inquiries',
   "SELECT DATE(i.created_at) AS Date, i.type AS Type, i.name AS Name, i.phone AS Phone, COALESCE(CONCAT(v.year,' ',v.make,' ',v.model),'-') AS Vehicle, i.status AS Status FROM inquiries i LEFT JOIN vehicles v ON v.id=i.vehicle_id WHERE i.created_at BETWEEN ? AND ? ORDER BY i.id DESC", $dr, [], null],
 'monthly' => ['Monthly summary (orders and order value)',
   "SELECT DATE_FORMAT(created_at,'%Y-%m') AS Month, COUNT(*) AS Orders, SUM(status='Completed') AS Completed, SUM(status='Cancelled') AS Cancelled, SUM(CASE WHEN status<>'Cancelled' THEN total_amount ELSE 0 END) AS Order_value FROM orders WHERE created_at BETWEEN ? AND ? GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY Month", $dr, ['Order_value'], 'Order_value'],
 'profit' => ['Profit on completed sales (vehicles with a recorded purchase cost)',
   "SELECT DATE(h.created_at) AS Completed, oi.stock_ref AS Stock, oi.title AS Vehicle, oi.price AS Sold_for, v.acquisition_cost AS Cost, (oi.price - v.acquisition_cost) AS Profit FROM orders o JOIN order_status_history h ON h.order_id=o.id AND h.to_status='Completed' JOIN order_items oi ON oi.order_id=o.id JOIN vehicles v ON v.id=oi.vehicle_id WHERE h.created_at BETWEEN ? AND ? AND v.acquisition_cost IS NOT NULL ORDER BY h.created_at", $dr, ['Sold_for', 'Cost', 'Profit'], 'Profit'],
 'bestsellers' => ['Best-selling makes (completed orders)',
   "SELECT v.make AS Make, COUNT(*) AS Sold, SUM(oi.price) AS Value FROM order_items oi JOIN orders o ON o.id=oi.order_id AND o.status='Completed' JOIN vehicles v ON v.id=oi.vehicle_id WHERE o.created_at BETWEEN ? AND ? GROUP BY v.make ORDER BY Sold DESC, Value DESC", $dr, ['Value'], 'Value'],
 'handover' => ['Pickup versus delivery (not cancelled)',
   "SELECT handover_type AS Handover, COUNT(*) AS Orders, SUM(delivery_fee) AS Delivery_fees FROM orders WHERE status<>'Cancelled' AND created_at BETWEEN ? AND ? GROUP BY handover_type ORDER BY Orders DESC", $dr, ['Delivery_fees'], 'Delivery_fees'],
 'returns' => ['Vehicle returns after handover',
   "SELECT DATE(r.created_at) AS Requested, o.reference AS Order_ref, CONCAT(v.year,' ',v.make,' ',v.model) AS Vehicle, r.reason AS Reason, r.status AS Status, r.refund_amount AS Refund FROM order_returns r JOIN orders o ON o.id=r.order_id JOIN vehicles v ON v.id=r.vehicle_id WHERE r.created_at BETWEEN ? AND ? ORDER BY r.created_at DESC", $dr, ['Refund'], 'Refund'],
 'cancelled' => ['Cancelled orders and reasons',
   "SELECT DATE(o.updated_at) AS Date, o.reference AS Reference, c.full_name AS Customer, o.cancel_reason AS Reason, o.total_amount AS Total FROM orders o JOIN customers c ON c.id=o.customer_id WHERE o.status='Cancelled' AND o.created_at BETWEEN ? AND ? ORDER BY o.updated_at DESC", $dr, ['Total'], 'Total'],
 'stockage' => ['Stock ageing: available vehicles by days in stock (current)',
   "SELECT stock_ref AS Stock, CONCAT(year,' ',make,' ',model) AS Vehicle, price AS Price, acquisition_cost AS Cost, DATEDIFF(CURDATE(), COALESCE(acquired_on, DATE(created_at))) AS Days_in_stock FROM vehicles WHERE status='Available' ORDER BY Days_in_stock DESC", [], ['Price', 'Cost'], null],
 'newcustomers' => ['New customer accounts',
   "SELECT DATE(c.created_at) AS Joined, c.full_name AS Name, c.email AS Email, IF(c.email_verified_at IS NULL,'No','Yes') AS Email_verified, (SELECT COUNT(*) FROM orders o WHERE o.customer_id=c.id) AS Orders FROM customers c WHERE c.created_at BETWEEN ? AND ? ORDER BY c.created_at DESC", $dr, [], null],
 'topcustomers' => ['Top customers by order value (not cancelled, top 20)',
   "SELECT c.full_name AS Customer, c.phone AS Phone, COUNT(*) AS Orders, SUM(o.total_amount) AS Value FROM orders o JOIN customers c ON c.id=o.customer_id WHERE o.status<>'Cancelled' AND o.created_at BETWEEN ? AND ? GROUP BY c.id, c.full_name, c.phone ORDER BY Value DESC LIMIT 20", $dr, ['Value'], null],
 'support' => ['Support response times',
   "SELECT DATE(i.created_at) AS Date, i.type AS Type, i.name AS Name, i.status AS Status, IF(i.reply IS NULL,'No','Yes') AS Replied, TIMESTAMPDIFF(HOUR, i.created_at, i.replied_at) AS Hours_to_reply FROM inquiries i WHERE i.created_at BETWEEN ? AND ? ORDER BY i.created_at DESC", $dr, [], null],
 'emails' => ['Emails sent by the system (last 500 in period)',
   "SELECT DATE(created_at) AS Date, to_email AS To_email, subject AS Subject, status AS Status, attempts AS Attempts FROM outbox WHERE created_at BETWEEN ? AND ? ORDER BY id DESC LIMIT 500", $dr, [], null],
];
$groups = [
  'Sales and money' => ['monthly', 'orders', 'sales', 'revenue', 'methods', 'refunds', 'profit', 'outstanding', 'cancelled', 'returns'],
  'Inventory' => ['inventory', 'stock', 'stockage', 'bestsellers', 'categories', 'handover'],
  'Customers and support' => ['newcustomers', 'topcustomers', 'inquiries', 'support', 'emails'],
];
$key = array_key_exists($_GET['r'] ?? '', $R) ? $_GET['r'] : 'orders';
[$title, $sql, $params, $moneyCols, $totalCol] = $R[$key];
$rows = q($sql, $params)->fetchAll();

if (($_GET['export'] ?? '') === '1') {
    audit('staff', (int)$s['id'], 'report_export', 'report', null, "$key $from..$to");
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="report-' . $key . '-' . $from . '-to-' . $to . '.csv"');
    $out = fopen('php://output', 'w'); fwrite($out, "\xEF\xBB\xBF");
    // Neutralise spreadsheet formula injection from customer-supplied text.
    $safe = fn($c) => is_string($c) && $c !== '' && strpbrk($c[0], "=+-@\t\r") !== false ? "'" . $c : $c;
    if ($rows) fputcsv($out, array_keys($rows[0]));
    foreach ($rows as $r) fputcsv($out, array_map($safe, array_values($r)));
    fclose($out); exit;
}
admin_header('Reports'); ?>
<?php
$one = fn(string $sql, array $p = []) => (float)(q($sql, $p)->fetchColumn() ?: 0);
$k_orders = (int)$one("SELECT COUNT(*) FROM orders WHERE created_at BETWEEN ? AND ?", $dr);
$k_done   = (int)$one("SELECT COUNT(DISTINCT order_id) FROM order_status_history WHERE to_status='Completed' AND created_at BETWEEN ? AND ?", $dr);
$k_gross  = $one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Verified' AND verified_at BETWEEN ? AND ?", $dr);
$k_ref    = $one("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE processed_at BETWEEN ? AND ?", $dr);
$k_avg    = $one("SELECT COALESCE(AVG(total_amount),0) FROM orders WHERE status<>'Cancelled' AND created_at BETWEEN ? AND ?", $dr);
$k_cust   = (int)$one("SELECT COUNT(*) FROM customers WHERE created_at BETWEEN ? AND ?", $dr);
$k_inq    = (int)$one("SELECT COUNT(*) FROM inquiries WHERE created_at BETWEEN ? AND ?", $dr);
$k_profit = $one("SELECT COALESCE(SUM(oi.price - v.acquisition_cost),0) FROM order_status_history h JOIN order_items oi ON oi.order_id=h.order_id JOIN vehicles v ON v.id=oi.vehicle_id WHERE h.to_status='Completed' AND v.acquisition_cost IS NOT NULL AND h.created_at BETWEEN ? AND ?", $dr);
?>
<h1 class="h1s">Reports</h1>
<div class="kpis">
  <div class="kpi"><span class="lbl">Orders placed</span><span class="num"><?= $k_orders ?></span><span class="sub"><?= $k_done ?> completed</span></div>
  <div class="kpi"><span class="lbl">Money received</span><span class="num long"><?= e(money($k_gross - $k_ref)) ?></span><span class="sub">after <?= e(money($k_ref)) ?> refunds</span></div>
  <div class="kpi"><span class="lbl">Average order</span><span class="num long"><?= e(money($k_avg)) ?></span><span class="sub">not cancelled</span></div>
  <div class="kpi"><span class="lbl">Profit on sales</span><span class="num long"><?= e(money($k_profit)) ?></span><span class="sub">where cost is recorded</span></div>
  <div class="kpi"><span class="lbl">New customers</span><span class="num"><?= $k_cust ?></span><span class="sub"><?= $k_inq ?> inquiries</span></div>
</div>
<br>
<form class="actions" method="get"><select name="r" aria-label="Report"><?php foreach ($groups as $gn => $ks) { echo '<optgroup label="' . e($gn) . '">'; foreach ($ks as $k) if (isset($R[$k])) echo '<option value="' . e($k) . '"' . ($k === $key ? ' selected' : '') . '>' . e($R[$k][0]) . '</option>'; echo '</optgroup>'; } ?></select>
<input type="date" name="from" value="<?= e($from) ?>" aria-label="From"><input type="date" name="to" value="<?= e($to) ?>" aria-label="To">
<button class="btn small">Show</button>
<a class="btn small alt" href="?<?= e(http_build_query(['r' => $key, 'from' => $from, 'to' => $to, 'export' => 1])) ?>">Download CSV</a>
<a class="btn small alt" href="#" data-print>Print / Save as PDF</a></form>
<h2><?= e($title) ?></h2><p class="mute">Dates: <?= e($from) ?> to <?= e($to) ?>. Money received means verified payments minus refunds. Profit uses the purchase cost saved on each vehicle; it ignores other expenses.</p>
<div class="scroll"><table class="t"><thead><tr><?php if ($rows) foreach (array_keys($rows[0]) as $h) echo '<th' . (in_array($h, $moneyCols, true) ? ' class="right"' : '') . '>' . e(str_replace('_', ' ', $h)) . '</th>'; ?></tr></thead><tbody>
<?php $sum = 0.0; foreach ($rows as $r): echo '<tr>'; foreach ($r as $c => $val) { $m = in_array($c, $moneyCols, true); echo '<td' . ($m ? ' class="right"' : '') . '>' . e($m ? money($val) : (string)$val) . '</td>'; } echo '</tr>'; if ($totalCol) $sum += (float)$r[$totalCol]; endforeach;
if (!$rows) echo '<tr><td>No data for this period.</td></tr>';
elseif ($totalCol) echo '<tr><th>Total</th><th colspan="' . (count($rows[0]) - 1) . '" class="right">' . e(money($sum)) . '</th></tr>'; ?></tbody></table></div>
<?php admin_footer();
