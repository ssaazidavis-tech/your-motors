<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$staff = require_staff('customers.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $type = (string)($_POST['campaign_type'] ?? 'promotion');
    $subject = trim((string)($_POST['subject'] ?? ''));
    $message = trim((string)($_POST['message'] ?? ''));
    $ids = array_values(array_filter(array_map('intval', (array)($_POST['recipient_ids'] ?? []))));
    if (!in_array($type, ['promotion', 'announcement', 'new-arrival'], true)) flash('Choose a valid email type.', 'err');
    elseif ($subject === '' || mb_strlen($subject) > 120) flash('Enter a subject of 120 characters or less.', 'err');
    elseif ($message === '') flash('Enter a message.', 'err');
    elseif (!$ids) flash('Select at least one opted-in customer.', 'err');
    else {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $customers = q("SELECT id, full_name, email FROM customers WHERE id IN ($placeholders) AND email_verified_at IS NOT NULL AND marketing_opt_in = 1 AND is_active = 1", $ids)->fetchAll();
        foreach ($customers as $customer) {
            if ($type === 'new-arrival') {
                new_arrival_mail((string)$customer['full_name'], (string)$customer['email'], ['make' => $subject, 'description' => $message]);
            } else {
                promotion_mail((string)$customer['email'], (string)$customer['full_name'], $subject, $message);
            }
        }
        audit('staff', (int)$staff['id'], 'marketing_email_sent', 'customer_campaign', null, count($customers) . ' recipients / ' . $type);
        flash(count($customers) . ' email(s) queued.');
        redirect('/admin/email.php');
    }
}

$customers = q("SELECT id, full_name, email FROM customers WHERE email_verified_at IS NOT NULL AND marketing_opt_in = 1 AND is_active = 1 ORDER BY full_name")->fetchAll();
admin_header('Email campaigns');
?>
<h1 class="h1s">Email campaigns</h1>
<div class="panel">
  <p>Messages are sent only to customers with a verified email address who opted in to marketing.</p>
  <form method="post"><?= csrf_field() ?>
    <div class="field"><label for="campaign_type">Email type</label>
      <select id="campaign_type" name="campaign_type">
        <option value="promotion">Promotion</option>
        <option value="new-arrival">New arrival</option>
        <option value="announcement">Announcement</option>
      </select>
    </div>
    <div class="field"><label for="subject">Subject / vehicle link</label><input id="subject" name="subject" maxlength="120" required></div>
    <div class="field"><label for="message">Message / vehicle details</label><textarea id="message" name="message" rows="7" required></textarea></div>
    <h3>Recipients</h3>
    <?php if (!$customers): ?>
      <p class="mute">No opted-in, verified customers yet.</p>
    <?php else: ?>
      <?php foreach ($customers as $customer): ?>
        <label><input class="chk" type="checkbox" name="recipient_ids[]" value="<?= (int)$customer['id'] ?>"> <?= e($customer['full_name']) ?> &lt;<?= e($customer['email']) ?>&gt;</label><br>
      <?php endforeach; ?>
    <?php endif; ?>
    <br><button class="btn"<?= !$customers ? ' disabled' : '' ?>>Queue emails</button>
  </form>
</div>
<?php admin_footer();
