<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
require_post();
$_SESSION = []; session_destroy();
redirect('/');
