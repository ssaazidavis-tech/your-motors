<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$me = require_staff('offers.manage');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'add') {
            $code = strtoupper(trim((string)($_POST['code'] ?? ''))); $type = (string)($_POST['type'] ?? 'percent');
            $val = (float)($_POST['value'] ?? 0); $min = max(0, (float)($_POST['min_subtotal'] ?? 0));
            $max = trim((string)($_POST['max_uses'] ?? '')); $exp = trim((string)($_POST['expires_at'] ?? ''));
            if (!preg_match('/^[A-Z0-9_-]{3,40}$/', $code)) throw new UserError('Code must be 3 to 40 letters, numbers, dashes or underscores.');
            if (!in_array($type, ['percent', 'fixed'], true)) throw new UserError('Choose a discount type.');
            if ($val <= 0 || ($type === 'percent' && $val > 50)) throw new UserError('Percent discounts must be between 1 and 50. Fixed amounts must be above zero.');
            if ($exp !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) throw new UserError('Enter a valid expiry date.');
            q('INSERT INTO coupons (code, type, value, min_subtotal, max_uses, expires_at) VALUES (?,?,?,?,?,?)', [$code, $type, $val, $min, $max === '' ? null : max(1, (int)$max), $exp ?: null]);
            audit('staff', (int)$me['id'], 'coupon_created', 'coupon', (int)db()->lastInsertId(), $code); flash('Coupon created.');
        } elseif ($do === 'toggle') {
            q('UPDATE coupons SET is_active = 1 - is_active WHERE id = ?', [(int)($_POST['id'] ?? 0)]); flash('Coupon updated.');
        } elseif ($do === 'welcome') {
            foreach (['welcome_enabled' => !empty($_POST['enabled']) ? '1' : '0', 'welcome_percent' => (string)max(1, min(50, (int)($_POST['percent'] ?? 2))), 'welcome_days' => (string)max(1, min(90, (int)($_POST['days'] ?? 14)))] as $k => $v)
                q('INSERT INTO settings (k, v) VALUES (?,?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [$k, $v]);
            audit('staff', (int)$me['id'], 'welcome_offer_saved', 'settings', null); flash('Welcome offer saved.');
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    catch (PDOException $ex) { flash('That coupon code already exists.', 'warn'); }
    redirect('/admin/offers.php');
}
$rows = q('SELECT * FROM coupons ORDER BY id DESC LIMIT 200')->fetchAll();
admin_header('Offers'); ?>
<h1 class="h1s">Offers and coupons</h1>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="do" value="welcome"><h3>Welcome offer</h3>
<p class="mute">Each new customer gets one single-use code by email when they verify their address.</p><div class="row">
<div class="field"><label><input type="checkbox" name="enabled" value="1" class="chk"<?= welcome_enabled() ? ' checked' : '' ?>> Switched on</label></div>
<div class="field"><label>Percent off (1-50)</label><input type="number" name="percent" min="1" max="50" value="<?= (int)setting('welcome_percent', '2') ?>"></div>
<div class="field"><label>Valid for (days)</label><input type="number" name="days" min="1" max="90" value="<?= (int)setting('welcome_days', '14') ?>"></div></div><button class="btn">Save</button></form><br>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="do" value="add"><h3>New coupon</h3><div class="row">
<div class="field"><label>Code</label><input name="code" required maxlength="40"></div>
<div class="field"><label>Type</label><select name="type"><option value="percent">Percent off</option><option value="fixed">Fixed amount (UGX)</option></select></div>
<div class="field"><label>Value</label><input type="number" name="value" min="1" step="any" required></div>
<div class="field"><label>Minimum cart (UGX)</label><input type="number" name="min_subtotal" min="0" value="0"></div>
<div class="field"><label>Max uses (blank = unlimited)</label><input type="number" name="max_uses" min="1"></div>
<div class="field"><label>Expires (optional)</label><input type="date" name="expires_at"></div></div><button class="btn">Create coupon</button></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Code</th><th>Discount</th><th>Min cart</th><th>Used</th><th>Expires</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $c): ?><tr><td><strong><?= e($c['code']) ?></strong></td><td><?= $c['type'] === 'percent' ? rtrim(rtrim((string)$c['value'], '0'), '.') . '%' : money($c['value']) ?></td>
<td><?= money($c['min_subtotal']) ?></td><td><?= (int)$c['used_count'] ?><?= $c['max_uses'] !== null ? ' / ' . (int)$c['max_uses'] : '' ?></td><td><?= $c['expires_at'] ? e($c['expires_at']) : 'Never' ?></td>
<td><?= $c['is_active'] ? 'Active' : 'Off' ?></td><td><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="ghost"><?= $c['is_active'] ? 'Turn off' : 'Turn on' ?></button></form></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php admin_footer();
