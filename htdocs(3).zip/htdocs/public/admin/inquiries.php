<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('inquiries.manage');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $to = (string)($_POST['to'] ?? '');
    $iid = (int)($_POST['id'] ?? 0);
    $reply = trim((string)($_POST['reply'] ?? ''));
    if (mb_strlen($reply) > 2000) { flash('Reply is too long (max 2000 characters).', 'warn'); redirect('/admin/inquiries.php'); }
    if (in_array($to, ['New', 'Contacted', 'Closed'], true)) {
        if ($reply !== '') {
            q('UPDATE inquiries SET status = ?, reply = ?, replied_at = NOW() WHERE id = ?', [$to === 'New' ? 'Contacted' : $to, $reply, $iid]);
            $inq = q('SELECT name, email FROM inquiries WHERE id = ?', [$iid])->fetch();
            if ($inq && $inq['email']) queue_mail((string)$inq['email'], 'Reply to your question', "Hello " . $inq['name'] . ",\n\n" . $reply . mail_button('View my messages', app_url('/contact.php')) . setting('business_name'));
            audit('staff', (int)$s['id'], 'inquiry_reply', 'inquiry', $iid, null);
        } else {
            q('UPDATE inquiries SET status = ? WHERE id = ?', [$to, $iid]);
            audit('staff', (int)$s['id'], 'inquiry_status', 'inquiry', $iid, $to);
        }
    }
    redirect('/admin/inquiries.php');
}
$rows = q("SELECT i.*, v.make, v.model, v.year, v.stock_ref FROM inquiries i LEFT JOIN vehicles v ON v.id = i.vehicle_id ORDER BY i.status = 'New' DESC, i.id DESC LIMIT 200")->fetchAll();
admin_header('Inquiries'); ?>
<h1 class="h1s">Customer inquiries</h1>
<div class="scroll"><table class="t"><thead><tr><th>When</th><th>Type</th><th>Vehicle</th><th>Contact</th><th>Message</th><th>Status</th></tr></thead><tbody>
<?php foreach ($rows as $i): ?><tr><td><?= e(date('j M, H:i', strtotime($i['created_at']))) ?></td><td><?= e($i['type']) ?><?= $i['preferred_date'] ? '<br>' . e($i['preferred_date']) : '' ?></td>
<td><?= $i['make'] ? e($i['year'] . ' ' . $i['make'] . ' ' . $i['model']) . '<br><span class="mute">' . e($i['stock_ref']) . '</span>' : '-' ?></td>
<td><?= e($i['name']) ?><br><a href="tel:<?= e($i['phone']) ?>"><?= e($i['phone']) ?></a><?= $i['email'] ? '<br>' . e($i['email']) : '' ?></td><td><?= nl2br(e((string)$i['message'])) ?></td>
<td><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$i['id'] ?>"><select name="to" aria-label="Status"><?php foreach (['New','Contacted','Closed'] as $o) echo '<option' . ($i['status'] === $o ? ' selected' : '') . '>' . $o . '</option>'; ?></select> <br><textarea name="reply" rows="2" maxlength="2000" placeholder="Reply to customer (optional)" aria-label="Reply"><?= '' ?></textarea><button class="ghost">Save</button><?php if ($i['reply']): ?><br><span class="mute">Replied <?= e(date('j M, H:i', strtotime((string)$i['replied_at']))) ?>: <?= e(mb_strimwidth((string)$i['reply'], 0, 80, '...')) ?></span><?php endif; ?></form></td></tr><?php endforeach; ?>
<?php if (!$rows) echo '<tr><td colspan="6">No inquiries yet.</td></tr>'; ?></tbody></table></div><?php admin_footer();
