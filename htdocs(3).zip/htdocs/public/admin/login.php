<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
if (current_staff()) redirect('/admin/');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    if (rate_limited('staff:' . client_ip() . ':' . $email, 5, 900)) $error = 'Too many attempts. Wait 15 minutes.';
    else {
        $u = q('SELECT id, password_hash, totp_enabled FROM users WHERE email = ? AND is_active = 1', [$email])->fetch();
        if ($u && password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) {
            if (!empty($u['totp_enabled'])) { session_regenerate_id(true); $_SESSION['2fa_uid'] = (int)$u['id']; $_SESSION['2fa_at'] = time(); redirect('/admin/two-factor.php'); }
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$u['id'];
            q('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$u['id']]);
            audit('staff', (int)$u['id'], 'login', 'user', (int)$u['id']);
            redirect('/admin/');
        }
        audit('staff', null, 'login_failed', 'user', null, substr($email, 0, 100));
        $error = 'Email or password is incorrect.';
    }
}
admin_header('Staff log in'); ?>
<div class="narrow panel"><h1 class="h1s">Staff log in</h1>
<?php if ($error) echo '<div class="flash err">' . e($error) . '</div>'; ?>
<form method="post"><?= csrf_field() ?>
<div class="field"><label for="em">Email</label><input id="em" type="email" name="email" required autocomplete="username"></div>
<div class="field"><label for="pw">Password</label><input id="pw" type="password" name="password" required autocomplete="current-password"></div>
<button class="btn block">Log in</button></form></div>
<?php admin_footer();
