<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('inventory.manage');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $name = trim((string)($_POST['name'] ?? '')); $sort = (int)($_POST['sort_order'] ?? 0); $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'add' || $do === 'save') {
            if ($name === '' || mb_strlen($name) > 60) throw new UserError('Enter a category name up to 60 characters.');
            $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)), '-') ?: 'category';
            if ($do === 'add') { q('INSERT INTO categories (name, slug, sort_order) VALUES (?,?,?)', [$name, $slug, $sort]); flash('Category added.'); }
            else { q('UPDATE categories SET name = ?, sort_order = ?, is_active = ? WHERE id = ?', [$name, $sort, !empty($_POST['is_active']) ? 1 : 0, (int)$_POST['id']]); flash('Category saved.'); }
            audit('staff', (int)$s['id'], 'category_' . $do, 'category', (int)($_POST['id'] ?? 0), $name);
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    catch (PDOException $ex) { flash('That category name is already used.', 'warn'); }
    redirect('/admin/categories.php');
}
$rows = q('SELECT c.*, (SELECT COUNT(*) FROM vehicles v WHERE v.category_id = c.id) AS n FROM categories c ORDER BY c.sort_order, c.name')->fetchAll();
admin_header('Categories'); ?>
<h1 class="h1s">Vehicle categories</h1>
<form method="post" class="actions panel"><?= csrf_field() ?><input type="hidden" name="do" value="add"><input name="name" placeholder="New category" required maxlength="60"><input type="number" name="sort_order" value="99" aria-label="Sort order"><button class="btn small">Add</button></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Name</th><th>Order</th><th>Active</th><th>Vehicles</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $c): $f = 'f' . (int)$c['id']; ?><tr>
<td><input form="<?= $f ?>" name="name" value="<?= e($c['name']) ?>" required maxlength="60" aria-label="Name"></td><td><input form="<?= $f ?>" type="number" name="sort_order" value="<?= (int)$c['sort_order'] ?>" aria-label="Order"></td>
<td><input form="<?= $f ?>" class="chk" type="checkbox" name="is_active" value="1"<?= $c['is_active'] ? ' checked' : '' ?> aria-label="Active"></td><td><?= (int)$c['n'] ?></td>
<td><form id="<?= $f ?>" method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>"><button class="ghost">Save</button></form></td></tr><?php endforeach; ?></tbody></table></div>
<?php admin_footer();
