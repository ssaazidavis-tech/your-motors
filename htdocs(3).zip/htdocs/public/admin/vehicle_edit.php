<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('inventory.manage');
$id = (int)($_GET['id'] ?? 0);
$v = $id ? q('SELECT * FROM vehicles WHERE id = ?', [$id])->fetch() : null;
if ($id && !$v) { http_response_code(404); exit('Vehicle not found'); }
$locked = $v && in_array($v['status'], ['Reserved', 'Sold'], true); // status is system-managed once an order exists
$errors = [];
const UPLOAD_DIR = __DIR__ . '/../uploads/';
const MAX_IMAGES = 10;

/** @return array<int,int> upload position => new vehicle_images id */
function save_images(int $vid, array $files, int &$count): array {
    $ids = [];
    $fi = new finfo(FILEINFO_MIME_TYPE);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $canConvert = function_exists('imagecreatetruecolor');
    foreach ($files['name'] as $i => $name) {
        if ($files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
        if ($count >= MAX_IMAGES) throw new UserError('A vehicle can have at most ' . MAX_IMAGES . ' photos.');
        if ($files['error'][$i] !== UPLOAD_ERR_OK || !is_uploaded_file($files['tmp_name'][$i])) throw new UserError("Photo \"$name\" failed to upload.");
        // With GD every photo is shrunk and saved as JPEG, so a larger original is fine; without it keep the old 5 MB cap.
        if ($files['size'][$i] > ($canConvert ? 15 : 5) * 1024 * 1024) throw new UserError("Photo \"$name\" is over " . ($canConvert ? 15 : 5) . " MB.");
        $mime = $fi->file($files['tmp_name'][$i]);
        if (!isset($ext[$mime]) || @getimagesize($files['tmp_name'][$i]) === false) throw new UserError("Photo \"$name\" must be a real JPG, PNG or WebP image.");
        $base = bin2hex(random_bytes(12)); // never reuse the client's file name
        $file = $base . '.jpg';
        if (!save_as_jpeg($files['tmp_name'][$i], $mime, UPLOAD_DIR . $file)) {
            if ($canConvert && $files['size'][$i] > 5 * 1024 * 1024) throw new UserError("Photo \"$name\" could not be processed.");
            $file = $base . '.' . $ext[$mime];  // GD missing or failed on a small file: keep the original
            if (!move_uploaded_file($files['tmp_name'][$i], UPLOAD_DIR . $file)) throw new UserError('Could not save the photo.');
        }
        q('INSERT INTO vehicle_images (vehicle_id, path, is_primary, sort_order) VALUES (?,?,?,?)', [$vid, $file, $count === 0 ? 1 : 0, $count]);
        $ids[(int)$i] = (int)db()->lastInsertId();
        $count++;
    }
    return $ids;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $do = (string)($_POST['do'] ?? 'save');
    try {
        if ($v && $do === 'primary') {
            q('UPDATE vehicle_images SET is_primary = (id = ?) WHERE vehicle_id = ?', [(int)$_POST['img'], $id]); flash('Primary photo updated.'); redirect("/admin/vehicle_edit.php?id=$id");
        }
        if ($v && $do === 'delimg') {
            $im = q('SELECT id, path FROM vehicle_images WHERE id = ? AND vehicle_id = ?', [(int)$_POST['img'], $id])->fetch();
            if ($im) { q('DELETE FROM vehicle_images WHERE id = ?', [$im['id']]); @unlink(UPLOAD_DIR . basename($im['path'])); }
            $first = q('SELECT id FROM vehicle_images WHERE vehicle_id = ? ORDER BY sort_order, id LIMIT 1', [$id])->fetchColumn();
            if ($first && !q('SELECT 1 FROM vehicle_images WHERE vehicle_id = ? AND is_primary = 1', [$id])->fetchColumn()) q('UPDATE vehicle_images SET is_primary = 1 WHERE id = ?', [$first]);
            flash('Photo deleted.'); redirect("/admin/vehicle_edit.php?id=$id");
        }
        $f = [];
        foreach (['stock_ref','make','model','grade','colour','vin','description','inspection_notes'] as $k) $f[$k] = trim((string)($_POST[$k] ?? ''));
        $num = fn(string $k) => ($_POST[$k] ?? '') === '' ? null : $_POST[$k];
        $year = (int)($_POST['year'] ?? 0);
        $price = $num('price'); $orig = $num('original_price');
        $por = !empty($_POST['price_on_request']) ? 1 : 0;
        $cat = (int)($_POST['category_id'] ?? 0);
        $fuel = (string)($_POST['fuel_type'] ?? ''); $trans = (string)($_POST['transmission'] ?? '');
        $drv = (string)($_POST['drivetrain'] ?? ''); $cond = (string)($_POST['vehicle_condition'] ?? '');
        $status = $locked ? $v['status'] : (string)($_POST['status'] ?? 'Draft');
        if (!preg_match('/^[A-Za-z0-9\-]{2,30}$/', $f['stock_ref'])) $errors[] = 'Stock reference: 2-30 letters, numbers or dashes.';
        if ($f['make'] === '' || $f['model'] === '') $errors[] = 'Make and model are required.';
        if ($year < 1980 || $year > (int)date('Y') + 1) $errors[] = 'Enter a valid year.';
        if (!$por && ($price === null || !is_numeric($price) || (float)$price <= 0)) $errors[] = 'Enter a price above zero, or tick price on request.';
        if ($orig !== null && (!is_numeric($orig) || (float)$orig < (float)$price)) $errors[] = 'Original price must be at least the selling price.';
        if (!q('SELECT 1 FROM categories WHERE id = ?', [$cat])->fetchColumn()) $errors[] = 'Choose a category.';
        if (!in_array($fuel, ['Petrol','Diesel','Hybrid','Electric','LPG'], true)) $errors[] = 'Choose a fuel type.';
        if (!in_array($trans, ['Automatic','Manual'], true)) $errors[] = 'Choose a transmission.';
        if ($drv !== '' && !in_array($drv, ['2WD','4WD','AWD','FWD','RWD'], true)) $errors[] = 'Invalid drivetrain.';
        if (!in_array($cond, ['New','Foreign Used','Locally Used'], true)) $errors[] = 'Choose a condition.';
        if (!in_array($status, ['Draft','Available','Archived','Reserved','Sold'], true)) $errors[] = 'Invalid status.';
        if ($status === 'Available' && !$por && !$v && empty(array_filter($_FILES['photos']['name'] ?? []))) { /* allowed, but warn */ }
        if (!$errors) {
            $vals = [$f['stock_ref'], $cat, $f['make'], $f['model'], $f['grade'] ?: null, $year, $por ? 0 : $price, $orig, $por,
                $num('mileage_km'), $num('engine_cc'), $fuel, $trans, $drv ?: null, $num('seats'), $f['colour'] ?: null, $cond,
                $f['vin'] ?: null, $f['description'] ?: null, $f['inspection_notes'] ?: null, $num('acquisition_cost'), $status, !empty($_POST['is_featured']) ? 1 : 0];
            $pdo = db(); $pdo->beginTransaction();
            try {
                if ($v) { q('UPDATE vehicles SET stock_ref=?, category_id=?, make=?, model=?, grade=?, year=?, price=?, original_price=?, price_on_request=?, mileage_km=?, engine_cc=?, fuel_type=?, transmission=?, drivetrain=?, seats=?, colour=?, vehicle_condition=?, vin=?, description=?, inspection_notes=?, acquisition_cost=?, status=?, is_featured=? WHERE id=?', [...$vals, $id]); }
                else { q('INSERT INTO vehicles (stock_ref, category_id, make, model, grade, year, price, original_price, price_on_request, mileage_km, engine_cc, fuel_type, transmission, drivetrain, seats, colour, vehicle_condition, vin, description, inspection_notes, acquisition_cost, status, is_featured, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [...$vals, $s['id']]); $id = (int)$pdo->lastInsertId(); }
                q('DELETE FROM vehicle_features WHERE vehicle_id = ?', [$id]);
                foreach (array_slice(array_unique(array_filter(array_map('trim', explode(',', (string)($_POST['features'] ?? ''))))), 0, 30) as $ft) q('INSERT INTO vehicle_features (vehicle_id, feature) VALUES (?,?)', [$id, mb_substr($ft, 0, 80)]);
                $count = (int)q('SELECT COUNT(*) FROM vehicle_images WHERE vehicle_id = ?', [$id])->fetchColumn();
                if (!empty($_FILES['photos'])) {
                    $newIds = save_images($id, $_FILES['photos'], $count);
                    $pn = $_POST['primary_new'] ?? '';   // the photo the staff member picked as primary among the new ones
                    if ($pn !== '' && ctype_digit((string)$pn) && isset($newIds[(int)$pn])) q('UPDATE vehicle_images SET is_primary = (id = ?) WHERE vehicle_id = ?', [$newIds[(int)$pn], $id]);
                }
                audit('staff', (int)$s['id'], $v ? 'vehicle_updated' : 'vehicle_created', 'vehicle', $id, $f['stock_ref'] . ' ' . $status);
                $pdo->commit();
            } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $ex; }
            flash('Vehicle saved.'); redirect("/admin/vehicle_edit.php?id=$id");
        }
    } catch (UserError $ex) { $errors[] = $ex->getMessage(); }
    catch (PDOException $ex) { $errors[] = $ex->getCode() === '23000' ? 'That stock reference is already used.' : 'Could not save. Check the values and try again.'; error_log('vehicle_edit: ' . $ex->getMessage()); }
    $v = array_merge($v ?: [], $_POST, ['status' => $v['status'] ?? ($_POST['status'] ?? 'Draft')]);
}
$cats = q('SELECT id, name FROM categories ORDER BY sort_order')->fetchAll();
$feats = $id ? implode(', ', q('SELECT feature FROM vehicle_features WHERE vehicle_id = ? ORDER BY id', [$id])->fetchAll(PDO::FETCH_COLUMN)) : '';
$imgs = $id ? q('SELECT id, path, is_primary FROM vehicle_images WHERE vehicle_id = ? ORDER BY sort_order, id', [$id])->fetchAll() : [];
$g = fn(string $k, $d = '') => e((string)($v[$k] ?? $d));
$opt = function (array $list, string $k) use ($v) { foreach ($list as $o) echo '<option' . (($v[$k] ?? '') === $o ? ' selected' : '') . '>' . e($o) . '</option>'; };
back_to('/admin/vehicles.php', 'Back to vehicles'); admin_header($id ? 'Edit vehicle' : 'Add vehicle'); ?>
<h1 class="h1s"><?= $id ? 'Edit ' . e($v['stock_ref'] ?? '') : 'Add a vehicle' ?></h1>
<?php foreach ($errors as $er) echo '<div class="flash err">' . e($er) . '</div>'; ?>
<form method="post" enctype="multipart/form-data" class="panel"><?= csrf_field() ?>
<div class="row">
<div class="field"><label>Stock reference</label><input name="stock_ref" required value="<?= $g('stock_ref') ?>"></div>
<div class="field"><label>Make</label><input name="make" required value="<?= $g('make') ?>"></div>
<div class="field"><label>Model</label><input name="model" required value="<?= $g('model') ?>"></div>
<div class="field"><label>Grade / variant</label><input name="grade" value="<?= $g('grade') ?>"></div>
<div class="field"><label>Year</label><input type="number" name="year" required value="<?= $g('year') ?>"></div>
<div class="field"><label>Category</label><select name="category_id"><?php foreach ($cats as $c) echo '<option value="' . (int)$c['id'] . '"' . ((int)($v['category_id'] ?? 0) === (int)$c['id'] ? ' selected' : '') . '>' . e($c['name']) . '</option>'; ?></select></div>
<div class="field"><label>Selling price (UGX)</label><input type="number" step="1" min="0" name="price" value="<?= $g('price') ?>"></div>
<div class="field"><label>Original price (shows % off)</label><input type="number" step="1" min="0" name="original_price" value="<?= $g('original_price') ?>"></div>
<div class="field"><label>Mileage (km)</label><input type="number" min="0" name="mileage_km" value="<?= $g('mileage_km') ?>"></div>
<div class="field"><label>Engine (cc)</label><input type="number" min="0" name="engine_cc" value="<?= $g('engine_cc') ?>"></div>
<div class="field"><label>Fuel</label><select name="fuel_type"><?php $opt(['Petrol','Diesel','Hybrid','Electric','LPG'], 'fuel_type'); ?></select></div>
<div class="field"><label>Transmission</label><select name="transmission"><?php $opt(['Automatic','Manual'], 'transmission'); ?></select></div>
<div class="field"><label>Drivetrain</label><select name="drivetrain"><option value="">-</option><?php $opt(['2WD','4WD','AWD','FWD','RWD'], 'drivetrain'); ?></select></div>
<div class="field"><label>Seats</label><input type="number" min="1" max="80" name="seats" value="<?= $g('seats') ?>"></div>
<div class="field"><label>Colour</label><input name="colour" value="<?= $g('colour') ?>"></div>
<div class="field"><label>Condition</label><select name="vehicle_condition"><?php $opt(['Foreign Used','Locally Used','New'], 'vehicle_condition'); ?></select></div>
<div class="field"><label>VIN / chassis (staff only)</label><input name="vin" value="<?= $g('vin') ?>"></div>
<div class="field"><label>Acquisition cost (staff only)</label><input type="number" min="0" name="acquisition_cost" value="<?= $g('acquisition_cost') ?>"></div>
<div class="field"><label>Status</label><?php if ($locked): ?><input value="<?= $g('status') ?>" disabled><small class="mute">Set automatically by orders.</small>
<?php else: ?><select name="status"><?php $opt(['Draft','Available','Archived'], 'status'); ?></select><?php endif; ?></div>
</div>
<div class="field"><label><input class="chk" type="checkbox" name="price_on_request" value="1"<?= !empty($v['price_on_request']) ? ' checked' : '' ?>> Price on request (cannot be added to cart)</label>
<label><input class="chk" type="checkbox" name="is_featured" value="1"<?= !empty($v['is_featured']) ? ' checked' : '' ?>> Featured on home page</label></div>
<div class="field"><label>Description</label><textarea name="description"><?= $g('description') ?></textarea></div>
<div class="field"><label>Inspection notes</label><textarea name="inspection_notes"><?= $g('inspection_notes') ?></textarea></div>
<div class="field"><label>Features (comma separated)</label><input name="features" value="<?= e($_POST['features'] ?? $feats) ?>"></div>
<div class="field"><label for="photos">Add photos (JPG, PNG or WebP, 10 per vehicle)</label><input id="photos" type="file" name="photos[]" multiple data-compress<?= array_filter(array_column($imgs, 'is_primary')) ? ' data-has-primary' : '' ?> accept="image/jpeg,image/png,image/webp">
<small id="photo-status" role="status" aria-live="polite">Photos are shrunk and saved as JPEG automatically.</small>
<div id="photo-previews" class="picks" role="radiogroup" aria-label="Choose the primary photo"></div></div>
<button class="btn">Save vehicle</button></form>
<?php if ($imgs): ?><h2>Photos</h2><div class="thumbrow"><?php foreach ($imgs as $im): ?><figure<?= $im['is_primary'] ? ' class="is-primary"' : '' ?>><img src="/uploads/<?= e($im['path']) ?>" alt="">
<?= $im['is_primary'] ? '<span class="pill ok">Primary</span>' : '' ?>
<form method="post" class="actions"><?= csrf_field() ?><input type="hidden" name="img" value="<?= (int)$im['id'] ?>">
<?php if (!$im['is_primary']): ?><button class="ghost" name="do" value="primary">Set as primary</button><?php endif; ?><button class="ghost" name="do" value="delimg" data-confirm="Delete this photo from the vehicle? This cannot be undone." data-confirm-title="Delete photo?" data-confirm-ok="Yes, delete" data-confirm-danger>Delete</button></form></figure><?php endforeach; ?></div><?php endif; ?>
<script src="/assets/photo-compress.js" defer></script>
<?php admin_footer();
