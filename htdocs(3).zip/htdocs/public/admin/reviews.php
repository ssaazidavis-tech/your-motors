<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$me = require_staff('reviews.manage');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $id = (int)($_POST['id'] ?? 0); $to = (string)($_POST['to'] ?? '');
    if (in_array($to, ['Approved', 'Hidden'], true) && q('UPDATE reviews SET status = ? WHERE id = ?', [$to, $id])->rowCount()) {
        audit('staff', (int)$me['id'], 'review_' . strtolower($to), 'review', $id); flash('Review ' . strtolower($to) . '.');
    }
    redirect('/admin/reviews.php');
}
$rows = q("SELECT r.*, c.full_name, o.reference, oi.title AS car FROM reviews r JOIN customers c ON c.id = r.customer_id JOIN orders o ON o.id = r.order_id
           JOIN order_items oi ON oi.order_id = r.order_id AND oi.vehicle_id = r.vehicle_id ORDER BY FIELD(r.status,'Pending','Approved','Hidden'), r.created_at DESC LIMIT 200")->fetchAll();
admin_header('Reviews'); ?>
<h1 class="h1s">Reviews</h1>
<?php if (!$rows) echo '<div class="panel"><p>No reviews yet.</p></div>'; foreach ($rows as $r): ?>
<div class="panel"><p><strong><?= e(stars((int)$r['rating'])) ?></strong> <?= pill($r['status'], $r['status'] === 'Approved' ? 'ok' : ($r['status'] === 'Pending' ? 'warn' : 'bad')) ?>
 <?= $r['title'] ? '<strong>' . e($r['title']) . '</strong>' : '' ?></p>
<?= $r['body'] ? '<p>' . nl2br(e($r['body'])) . '</p>' : '' ?>
<p class="mute"><?= e($r['full_name']) ?> · <?= e($r['car']) ?> · <a href="/admin/order.php?ref=<?= urlencode($r['reference']) ?>"><?= e($r['reference']) ?></a></p>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
<?php if ($r['status'] !== 'Approved'): ?><button class="btn small" name="to" value="Approved">Approve</button><?php endif; ?>
<?php if ($r['status'] !== 'Hidden'): ?><button class="ghost" name="to" value="Hidden">Hide</button><?php endif; ?></form></div>
<?php endforeach; admin_footer();
