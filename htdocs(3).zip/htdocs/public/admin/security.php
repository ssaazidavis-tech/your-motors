<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$me = current_staff(); if (!$me) redirect('/admin/login.php');
$u = q('SELECT id, email, password_hash, totp_secret_enc, totp_enabled FROM users WHERE id = ?', [$me['id']])->fetch();
$newCodes = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $do = (string)($_POST['do'] ?? '');
    try {
        if ($do === 'start' && !$u['totp_enabled']) {
            $_SESSION['totp_pending'] = totp_new_secret();
        } elseif ($do === 'enable' && !$u['totp_enabled']) {
            $sec = (string)($_SESSION['totp_pending'] ?? '');
            if (rate_limited('totp_setup:' . $u['id'], 8, 600)) throw new UserError('Too many tries. Wait a few minutes.');
            $step = totp_verify($sec, (string)($_POST['code'] ?? ''));
            if ($sec === '' || $step === null) throw new UserError('That code did not match. Check the code in your app and try again.');
            q('UPDATE users SET totp_secret_enc = ?, totp_enabled = 1, totp_last_step = ? WHERE id = ?', [secret_encrypt($sec), $step, $u['id']]);
            unset($_SESSION['totp_pending']);
            $newCodes = backup_codes_create((int)$u['id']);
            audit('staff', (int)$u['id'], 'two_factor_enabled', 'user', (int)$u['id']);
            $u['totp_enabled'] = 1;
        } elseif ($do === 'disable' && $u['totp_enabled']) {
            if (!password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) throw new UserError('Password is incorrect.');
            q('UPDATE users SET totp_secret_enc = NULL, totp_enabled = 0, totp_last_step = 0 WHERE id = ?', [$u['id']]);
            q('DELETE FROM staff_backup_codes WHERE user_id = ?', [$u['id']]);
            audit('staff', (int)$u['id'], 'two_factor_disabled', 'user', (int)$u['id']);
            flash('Two-factor sign-in turned off.'); redirect('/admin/security.php');
        } elseif ($do === 'newcodes' && $u['totp_enabled']) {
            if (!password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) throw new UserError('Password is incorrect.');
            $newCodes = backup_codes_create((int)$u['id']);
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
}
$pending = !$u['totp_enabled'] ? (string)($_SESSION['totp_pending'] ?? '') : '';
$left = $u['totp_enabled'] ? (int)q('SELECT COUNT(*) FROM staff_backup_codes WHERE user_id = ? AND used_at IS NULL', [$u['id']])->fetchColumn() : 0;
admin_header('Security'); ?>
<h1 class="h1s">Account security</h1>
<div class="panel"><h3>Two-factor sign-in <?= $u['totp_enabled'] ? pill('On', 'ok') : pill('Off', 'warn') ?></h3>
<?php if ($newCodes): ?>
  <div class="notice"><strong>Save these backup codes now.</strong> Each works once if you lose your phone. They are not shown again.</div>
  <pre><?= e(implode("\n", $newCodes)) ?></pre>
<?php elseif ($u['totp_enabled']): ?>
  <p>Logging in needs your password and a 6-digit code from your authenticator app. Unused backup codes: <strong><?= $left ?></strong>.</p>
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="do" value="newcodes"><div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div><button class="ghost">Make new backup codes</button></form>
  <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="do" value="disable"><div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div>
    <button class="ghost" data-confirm="Anyone with your password will be able to log in." data-confirm-title="Turn off two-factor?" data-confirm-ok="Yes, turn off" data-confirm-danger>Turn off</button></form>
<?php elseif ($pending): ?>
  <p>1. Scan this code with Google Authenticator, Microsoft Authenticator or Authy, or type the key by hand.</p>
  <div id="qrbox" data-uri="<?= e(totp_uri($pending, $u['email'])) ?>" class="qrbox"></div>
  <p><code><?= e(trim(chunk_split($pending, 4, ' '))) ?></code></p>
  <p>2. Enter the 6-digit code it shows.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="enable"><div class="field"><label>Code</label><input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" required></div><button class="btn">Turn on</button></form>
  <script src="/assets/qr.js"></script><script src="/assets/qr-show.js"></script>
<?php else: ?>
  <p>Add a second step to staff login so a stolen password alone is not enough.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="start"><button class="btn">Set up two-factor</button></form>
<?php endif; ?></div>
<?php admin_footer();
