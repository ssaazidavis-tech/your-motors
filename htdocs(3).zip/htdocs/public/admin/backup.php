<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$me = require_staff('backup.run');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    if (rate_limited('backup:' . $me['id'], 5, 3600)) { flash('Too many backups. Try again later.', 'warn'); redirect('/admin/backup.php'); }
    audit('staff', (int)$me['id'], 'backup_downloaded', 'database', null);
    @set_time_limit(300);
    $name = env('DB_NAME', 'car_etailer') . '-' . date('Y-m-d-His') . '.sql';
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    $pdo = db();
    echo "-- Backup of " . env('DB_NAME', 'car_etailer') . " made " . date('c') . "\nSET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n";
    foreach ($pdo->query('SHOW FULL TABLES WHERE Table_type = "BASE TABLE"')->fetchAll(PDO::FETCH_NUM) as [$t]) {
        $create = $pdo->query('SHOW CREATE TABLE `' . str_replace('`', '', $t) . '`')->fetch(PDO::FETCH_NUM)[1];
        echo "DROP TABLE IF EXISTS `$t`;\n$create;\n\n";
        $st = $pdo->query('SELECT * FROM `' . str_replace('`', '', $t) . '`', PDO::FETCH_NUM);
        $batch = [];
        while ($row = $st->fetch(PDO::FETCH_NUM)) {
            $batch[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $row)) . ')';
            if (count($batch) >= 200) { echo "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n"; $batch = []; }
        }
        if ($batch) echo "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n";
        echo "\n";
    }
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    exit;
}
admin_header('Backup'); ?>
<h1 class="h1s">Database backup</h1>
<div class="panel"><p>Download a full copy of the database (customers, orders, payments, settings) as a .sql file. Store it somewhere safe and private: it contains personal data and password hashes.</p>
<p class="mute">Vehicle photos are not in the file. Copy the <code>public/uploads</code> folder separately. Restore with <code>mysql -u root -p car_etailer &lt; backup.sql</code>.</p>
<form method="post"><?= csrf_field() ?><button class="btn">Download backup</button></form></div>
<?php admin_footer();
