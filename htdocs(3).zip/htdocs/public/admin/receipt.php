<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
require_staff('orders.view');
$p = q("SELECT p.*, o.reference AS oref, o.total_amount, o.amount_paid, o.contact_name, u.full_name AS vname FROM payments p JOIN orders o ON o.id = p.order_id LEFT JOIN users u ON u.id = p.verified_by WHERE p.id = ? AND p.status = 'Verified'", [(int)($_GET['id'] ?? 0)])->fetch();
if (!$p) { http_response_code(404); exit('Receipt not found'); }
$items = q('SELECT title, stock_ref FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.reference = ?', [$p['oref']])->fetchAll();
admin_header('Receipt'); ?>
<div class="panel narrow"><h1 class="h1s"><?= e(setting('business_name')) ?></h1><p class="mute"><?= e(setting('address')) ?> | <?= e(setting('phone')) ?></p>
<h2>Payment receipt R-<?= str_pad((string)$p['id'], 6, '0', STR_PAD_LEFT) ?></h2>
<p>Order <?= e($p['oref']) ?><br>Received from <?= e($p['contact_name']) ?><br>Date <?= e(date('j M Y, H:i', strtotime($p['verified_at']))) ?><br>Method <?= e($p['method']) ?>, reference <?= e((string)$p['provider_txn_id']) ?></p>
<?php foreach ($items as $it) echo '<p>' . e($it['title']) . ' (' . e($it['stock_ref']) . ')</p>'; ?>
<div class="line grand"><span>Amount received</span><span><?= money($p['amount']) ?></span></div>
<div class="line"><span>Order total</span><span><?= money($p['total_amount']) ?></span></div>
<div class="line"><span>Total verified to date</span><span><?= money($p['amount_paid']) ?></span></div>
<p class="mute">Verified by <?= e($p['vname'] ?? '') ?>. <button class="ghost" onclick="window.print()">Print</button></p></div>
<?php admin_footer();
