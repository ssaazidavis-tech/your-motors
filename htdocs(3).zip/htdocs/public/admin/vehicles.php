<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('inventory.manage');
$st = (string)($_GET['status'] ?? '');
$qv = trim((string)($_GET['q'] ?? ''));
$w = []; $p = [];
if (in_array($st, ['Draft','Available','Reserved','Sold','Archived'], true)) { $w[] = 'v.status = ?'; $p[] = $st; }
if ($qv !== '') { $w[] = "CONCAT_WS(' ', v.stock_ref, v.make, v.model, v.year) LIKE ?"; $p[] = '%' . addcslashes($qv, '%_\\') . '%'; }
$rows = q(VEHICLE_SELECT . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY v.id DESC LIMIT 200', $p)->fetchAll();
admin_header('Inventory'); ?>
<h1 class="h1s">Inventory</h1>
<form class="actions" method="get"><input name="q" placeholder="Search stock, make, model" value="<?= e($qv) ?>">
<select name="status"><option value="">All statuses</option><?php foreach (['Draft','Available','Reserved','Sold','Archived'] as $o) echo '<option' . ($st === $o ? ' selected' : '') . '>' . $o . '</option>'; ?></select>
<button class="btn small">Filter</button> <a class="btn small alt" href="/admin/vehicle_edit.php">Add vehicle</a></form><br>
<div class="scroll"><table class="t"><thead><tr><th>Stock</th><th>Vehicle</th><th>Status</th><th class="right">Price</th><th></th></tr></thead><tbody>
<?php foreach ($rows as $v): ?><tr><td><?= e($v['stock_ref']) ?></td><td><?= e(vehicle_title($v)) ?></td><td><?= e($v['status']) ?></td><td class="right"><?= money($v['price']) ?></td>
<td><a href="/admin/vehicle_edit.php?id=<?= (int)$v['id'] ?>">Edit</a></td></tr><?php endforeach; ?>
<?php if (!$rows) echo '<tr><td colspan="5">No vehicles found.</td></tr>'; ?></tbody></table></div>
<?php admin_footer();
