<?php
declare(strict_types=1);
require_once __DIR__ . '/../../app/admin.php';
$s = require_staff('orders.view');
$o = q('SELECT o.*, c.full_name, c.email AS cemail, c.phone AS cphone FROM orders o JOIN customers c ON c.id = o.customer_id WHERE o.reference = ?', [(string)($_GET['ref'] ?? '')])->fetch();
if (!$o) { http_response_code(404); exit('Order not found'); }
$oid = (int)$o['id']; $self = '/admin/order.php?ref=' . urlencode($o['reference']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    try {
        $do = (string)($_POST['do'] ?? '');
        if ($do === 'status' || $do === 'cancel') {
            require_staff('orders.manage');
            $to = $do === 'cancel' ? 'Cancelled' : (string)($_POST['to'] ?? '');
            order_transition($oid, $to, trim((string)($_POST['note'] ?? '')) ?: null, $s);
            flash("Order moved to $to.");
        } elseif ($do === 'refund') {
            require_staff('payments.verify');
            record_refund($oid, (int)($_POST['payment_id'] ?? 0), (float)str_replace(',', '', (string)($_POST['amount'] ?? '0')), trim((string)($_POST['reason'] ?? '')), $s);
            flash('Refund recorded.');
        } elseif ($do === 'payment') {
            require_staff('payments.verify');
            record_verified_payment($oid, (float)str_replace(',', '', (string)($_POST['amount'] ?? '0')), trim((string)($_POST['ref'] ?? '')), $s);
            flash('Payment recorded and verified.');
        }
    } catch (UserError $ex) { flash($ex->getMessage(), 'warn'); }
    redirect($self);
}
$items = q('SELECT * FROM order_items WHERE order_id = ?', [$oid])->fetchAll();
$pays = q('SELECT p.*, u.full_name AS vname, p.amount - COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.payment_id = p.id),0) AS refundable FROM payments p LEFT JOIN users u ON u.id = p.verified_by WHERE p.order_id = ? ORDER BY p.id', [$oid])->fetchAll();
$hist = q("SELECT h.*, COALESCE(u.full_name, h.actor_type) AS who FROM order_status_history h LEFT JOIN users u ON h.actor_type='staff' AND u.id = h.actor_id WHERE h.order_id = ? ORDER BY h.id DESC", [$oid])->fetchAll();
$next = ORDER_FLOW[$o['status']] ?? [];
$outstanding = (float)$o['total_amount'] - (float)$o['amount_paid'];
back_to('/admin/orders.php', 'Back to orders'); admin_header('Order ' . $o['reference']); ?>
<h1 class="h1s">Order <?= e($o['reference']) ?></h1>
<div class="detail"><section>
<table class="t"><thead><tr><th>Vehicle</th><th class="right">Price</th></tr></thead><tbody>
<?php foreach ($items as $it) echo '<tr><td>' . e($it['title']) . '<br><span class="mute">' . e($it['stock_ref']) . '</span></td><td class="right">' . money($it['price']) . '</td></tr>'; ?></tbody></table>
<h2>Payments</h2><div class="scroll"><table class="t"><thead><tr><th>Date</th><th>Method</th><th>Reference</th><th>Status</th><th class="right">Amount</th><th></th></tr></thead><tbody>
<?php foreach ($pays as $p): ?><tr><td><?= e(date('j M Y', strtotime($p['created_at']))) ?></td><td><?= e($p['method']) ?></td><td><?= e($p['provider_txn_id'] ?: $p['reference']) ?></td>
<td><?= e($p['status']) ?><?= $p['vname'] ? '<br><span class="mute">by ' . e($p['vname']) . '</span>' : '' ?></td><td class="right"><?= money($p['amount']) ?></td>
<td><?= $p['status'] === 'Verified' ? '<a href="/admin/receipt.php?id=' . (int)$p['id'] . '" target="_blank" rel="noopener">Receipt</a>' : '' ?></td></tr><?php endforeach; ?></tbody></table></div>
<h2>History</h2>
<?php foreach ($hist as $h) echo '<p><strong>' . e($h['to_status']) . '</strong> <span class="mute">' . e(date('j M Y, H:i', strtotime($h['created_at']))) . ' by ' . e($h['who']) . '</span>' . ($h['note'] ? '<br>' . e($h['note']) : '') . '</p>'; ?>
</section><aside>
<div class="panel"><h3>Customer</h3><p><?= e($o['contact_name']) ?><br><?= e($o['contact_phone']) ?><br><?= e($o['contact_email']) ?></p>
<p class="mute"><?= e($o['handover_type']) ?>: <?= e($o['handover_location']) ?><?= $o['instructions'] ? '<br>Note: ' . e($o['instructions']) : '' ?></p></div>
<div class="panel"><h3>Money</h3>
<div class="line"><span>Total</span><strong><?= money($o['total_amount']) ?></strong></div>
<div class="line"><span>Due now (<?= e($o['payment_plan']) ?>)</span><span><?= money($o['amount_due_now']) ?></span></div>
<div class="line"><span>Verified paid</span><span><?= money($o['amount_paid']) ?></span></div>
<div class="line"><span>Outstanding</span><strong><?= money($outstanding) ?></strong></div>
<p>Order: <span class="pill"><?= e($o['status']) ?></span> Payment: <span class="pill"><?= e($o['payment_status']) ?></span></p></div>
<?php if ($next && staff_can('orders.manage')): ?><div class="panel"><h3>Update order</h3>
<?php foreach ($next as $n): if ($n === 'Cancelled') continue; ?>
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="status"><input type="hidden" name="to" value="<?= e($n) ?>">
<div class="field"><input name="note" placeholder="Note (optional)" maxlength="255"></div><button class="btn block" data-confirm="<?= e($n === 'Awaiting Payment' ? 'Confirm the vehicle is available and ask the customer to pay? They will be emailed.' : 'Move this order to ' . $n . '? The customer will be emailed.') ?>" data-confirm-ok="Yes, update"><?= $n === 'Awaiting Payment' ? 'Confirm availability and request payment' : 'Mark ' . e($n) ?></button></form><br><?php endforeach; ?>
<?php if (in_array('Cancelled', $next, true)): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="cancel">
<div class="field"><input name="note" required placeholder="Reason for cancelling or rejecting" maxlength="255"></div><button class="btn block alt" data-confirm="Cancel this order and put the vehicle back on sale? The customer will be emailed. This cannot be undone." data-confirm-title="Cancel this order?" data-confirm-ok="Yes, cancel order" data-confirm-danger>Cancel order and release vehicle</button></form><?php endif; ?></div><?php endif; ?>
<?php if (staff_can('payments.verify') && !in_array($o['status'], ['Awaiting Confirmation','Cancelled','Completed'], true) && $outstanding > 0): ?><div class="panel"><h3>Record verified payment</h3>
<p class="mute">Enter money you have confirmed in the bank statement, cash receipt book or mobile money statement.</p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="payment">
<div class="field"><label>Amount received (UGX)</label><input name="amount" required inputmode="numeric" value="<?= e((string)(int)min($outstanding, max(0, (float)$o['amount_due_now'] - (float)$o['amount_paid']) ?: $outstanding)) ?>"></div>
<div class="field"><label>Bank / receipt / mobile money reference</label><input name="ref" required maxlength="60"></div><button class="btn block" data-confirm="Only verify if the money is really in your account. The order will move forward and the customer will be emailed." data-confirm-title="Verify this payment?" data-confirm-ok="Yes, money received">Verify payment</button></form></div><?php endif; ?>
<?php $rf = array_filter($pays, fn($p) => $p['status'] === 'Verified' && (float)$p['refundable'] > 0);
if (staff_can('payments.verify') && $rf && $o['status'] !== 'Completed'): ?><div class="panel"><h3>Record refund</h3>
<p class="mute">Use after money has actually been returned to the customer.</p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="refund">
<div class="field"><label>Payment</label><select name="payment_id"><?php foreach ($rf as $p) echo '<option value="' . (int)$p['id'] . '">' . e(($p['provider_txn_id'] ?: $p['reference']) . ' (refundable ' . money($p['refundable']) . ')') . '</option>'; ?></select></div>
<div class="field"><label>Amount (UGX)</label><input name="amount" required inputmode="numeric"></div>
<div class="field"><label>Reason</label><input name="reason" required maxlength="255"></div><button class="btn block alt" data-confirm="This records money returned to the customer and cannot be undone." data-confirm-title="Record this refund?" data-confirm-ok="Yes, record refund" data-confirm-danger>Record refund</button></form></div><?php endif; ?>
<?php $oret = q('SELECT status FROM order_returns WHERE order_id = ?', [$oid])->fetchAll(PDO::FETCH_COLUMN); if ($oret): ?><div class="panel"><h3>Returns</h3><p><?= e(implode(', ', $oret)) ?> · <a href="/admin/returns.php?order=<?= urlencode($o['reference']) ?>">Open in Returns</a></p></div><?php endif; ?>
</aside></div><?php admin_footer();
