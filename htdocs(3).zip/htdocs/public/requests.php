<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/dash_layout.php';
$c = require_customer();
$drive = ($_GET['type'] ?? '') === 'drive';
$rows = q('SELECT i.type, i.message, i.preferred_date, i.status, i.created_at, v.id AS vid, v.year, v.make, v.model, v.grade
    FROM inquiries i LEFT JOIN vehicles v ON v.id = i.vehicle_id
    WHERE i.customer_id = ? AND ' . ($drive ? "i.type = 'Test Drive'" : "i.type <> 'Test Drive'") . ' ORDER BY i.id DESC LIMIT 100', [$c['id']])->fetchAll();
dash_header($drive ? 'Test drives' : 'Enquiries', $drive ? 'drives' : 'enquiries');
dash_head($drive ? 'Test drive requests' : 'My enquiries',
    $drive ? 'Test drives you asked for. We call you to confirm the time.' : 'Questions and price requests you sent about cars.');
if (!$rows): ?>
<div class="panel"><p class="empty">Nothing here yet. Open any car and use the form on its page to <?= $drive ? 'request a test drive' : 'send an enquiry' ?>.</p>
<a class="btn" href="/vehicles.php">Browse cars</a></div>
<?php else: ?>
<div class="panel flush"><div class="scroll"><table class="dt"><thead><tr><th>Sent</th><th>Car</th><th><?= $drive ? 'Preferred date' : 'Type' ?></th><th>Message</th><th>Status</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
  <tr><td class="num-cell"><?= e(date('j M Y', strtotime($r['created_at']))) ?></td>
    <td><?= $r['vid'] ? '<a href="/vehicle.php?id=' . (int)$r['vid'] . '">' . e(vehicle_title($r)) . '</a>' : 'General enquiry' ?></td>
    <td class="num-cell"><?= $drive ? e($r['preferred_date'] ? date('D j M Y', strtotime($r['preferred_date'])) : 'Any day') : e($r['type']) ?></td>
    <td><?= e(mb_strimwidth((string)$r['message'], 0, 90, '...')) ?></td>
    <td><?= request_pill($r['status']) ?></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<?php endif; dash_footer();
