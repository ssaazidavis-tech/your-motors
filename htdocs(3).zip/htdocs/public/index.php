<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
release_expired_reservations();

$wish = customer_wishlist_ids();
$makes = q("SELECT DISTINCT make FROM vehicles WHERE status IN ('Available','Reserved') ORDER BY make")->fetchAll(PDO::FETCH_COLUMN);
$vis = "v.status IN ('Available','Reserved')";
$featured = q(VEHICLE_SELECT . " WHERE $vis AND v.is_featured = 1 ORDER BY v.created_at DESC LIMIT 8")->fetchAll();
$recent   = q(VEHICLE_SELECT . " WHERE $vis ORDER BY v.created_at DESC, v.id DESC LIMIT 8")->fetchAll();
$offers   = q(VEHICLE_SELECT . " WHERE $vis AND v.original_price > v.price ORDER BY (v.original_price - v.price) DESC LIMIT 4")->fetchAll();
$cats     = q("SELECT c.name, c.id, COUNT(v.id) n FROM categories c JOIN vehicles v ON v.category_id = c.id AND $vis WHERE c.is_active = 1 GROUP BY c.id ORDER BY c.sort_order")->fetchAll();

page_header('Your dream car awaits', 'Browse inspected vehicles, reserve online and arrange handover in Uganda.');
?>
<?php $heroImg = setting('hero_image'); $heroVid = setting('hero_video'); ?>
<section class="hero<?= ($heroImg || $heroVid) ? ' has-img' : '' ?>">
  <?php if ($heroVid): ?>
  <video class="hero-img hero-video" id="hero-video" autoplay muted loop playsinline disablepictureinpicture preload="metadata"<?= $heroImg ? ' poster="/uploads/' . e($heroImg) . '"' : '' ?> aria-hidden="true" tabindex="-1">
    <source src="/uploads/<?= e($heroVid) ?>" type="video/<?= str_ends_with($heroVid, '.webm') ? 'webm' : 'mp4' ?>"></video>
  <script src="/assets/hero-video.js" defer></script>
  <?php elseif ($heroImg): ?><img class="hero-img" src="/uploads/<?= e($heroImg) ?>" alt="" fetchpriority="high"><?php endif; ?>
  <div class="wrap">
    <h1>Your Dream Car Awaits.</h1>
    <p class="lead">Browse our stock, reserve the car you want online, and track your purchase until handover.</p>
    <form class="finder" method="get" action="/vehicles.php">
      <div><label for="hm">Make</label>
        <select id="hm" name="make"><option value="">Any make</option>
          <?php foreach ($makes as $m): ?><option><?= e($m) ?></option><?php endforeach; ?></select></div>
      <div><label for="hmo">Model</label><select id="hmo" name="model" data-models-for="hm"><option value="">Any model</option></select></div>
      <div><label for="hy">Year from</label><input id="hy" type="number" name="min_year" min="1990" max="<?= (int)date('Y') + 1 ?>" placeholder="2015"></div>
      <div><label for="hp">Max price (UGX)</label><input id="hp" type="number" name="max_price" min="0" step="1000000" placeholder="60000000"></div>
      <button class="btn">Search cars</button>
    </form>
    <div class="stripe"></div>
  </div>
</section>

<?php if ($featured): ?><h2>Featured vehicles</h2><div class="grid"><?php foreach ($featured as $v) vehicle_card($v, $wish); ?></div><?php endif; ?>
<?php if ($offers): ?><h2>Special offers</h2><div class="grid"><?php foreach ($offers as $v) vehicle_card($v, $wish); ?></div><?php endif; ?>
<h2>Recently added</h2>
<?php if ($recent): ?><div class="grid"><?php foreach ($recent as $v) vehicle_card($v, $wish); ?></div>
<?php else: ?><p class="mute">No vehicles are listed yet. Check back soon.</p><?php endif; ?>

<?php if ($cats): ?><h2>Browse by category</h2>
<div class="cats"><?php foreach ($cats as $c): ?><a href="/vehicles.php?category=<?= (int)$c['id'] ?>"><?= e($c['name']) ?> (<?= (int)$c['n'] ?>)</a><?php endforeach; ?></div><?php endif; ?>

<h2>How buying works</h2>
<ol class="steps">
  <li><strong>Pick a vehicle</strong><br>Add it to your cart. Each car is one of a kind, so it can only be in one order.</li>
  <li><strong>Place your order</strong><br>Your car is held for <?= (int)setting('reservation_hours', '48') ?> hours while we confirm it.</li>
  <li><strong>Pay and get verified</strong><br>We confirm your payment before the sale is final.</li>
  <li><strong>Collect or get delivery</strong><br>We tell you when your car is ready for handover.</li>
</ol>
<script src="/assets/app.js"></script>
<?php page_footer();
