<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    if (!rate_limited('forgot:' . client_ip(), 5, 3600) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $c = q('SELECT id, full_name FROM customers WHERE email = ? AND is_active = 1', [$email])->fetch();
        if ($c) {
            $token = bin2hex(random_bytes(32));
            q('INSERT INTO password_resets (customer_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))', [$c['id'], hash('sha256', $token)]);
            queue_mail($email, 'Reset your password', "Hello {$c['full_name']},\n\nClick the button within 1 hour to choose a new password." . mail_button('Reset my password', app_url('/reset.php?token=' . $token)) . "If you did not ask for this, ignore this email.", true);
            audit('customer', (int)$c['id'], 'password_reset_requested', 'customer', (int)$c['id']);
        }
    }
    $sent = true; // same answer whether or not the email exists, so accounts cannot be probed
}
back_to('/login.php', 'Back to log in'); page_header('Reset password'); ?>
<div class="narrow panel"><h1 class="h1s">Reset your password</h1>
<?php if ($sent): ?><div class="flash">If that email has an account, a reset link is on its way. It works for 1 hour.</div>
<?php else: ?><form method="post"><?= csrf_field() ?><div class="field"><label for="em">Email</label><input id="em" type="email" name="email" required></div><button class="btn block">Send reset link</button></form><?php endif; ?></div>
<?php page_footer();
