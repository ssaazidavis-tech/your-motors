<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$c = require_customer();
release_expired_reservations();
$o = q('SELECT * FROM orders WHERE reference = ? AND customer_id = ?', [(string)($_GET['ref'] ?? ''), $c['id']])->fetch();
if (!$o) { http_response_code(404); page_header('Order not found'); echo '<div class="panel"><h1>Order not found</h1><p><a href="/orders.php">Back to my orders</a></p></div>'; page_footer(); exit; }
$items = q('SELECT * FROM order_items WHERE order_id = ?', [$o['id']])->fetchAll();
$pays = q('SELECT method, reference, amount, status, created_at FROM payments WHERE order_id = ? ORDER BY id', [$o['id']])->fetchAll();
$hist = q('SELECT to_status, note, created_at FROM order_status_history WHERE order_id = ? ORDER BY id DESC', [$o['id']])->fetchAll();
$res = q("SELECT MIN(expires_at) FROM reservations WHERE order_id = ? AND status = 'Active'", [$o['id']])->fetchColumn();
$steps = ['Order Submitted', 'Awaiting Confirmation', 'Awaiting Payment', 'Payment Verified', 'Order Processing', 'Ready for Handover', 'Completed'];
$cur = array_search($o['status'], $steps, true);
$methodLabel = q('SELECT label FROM payment_methods WHERE code = ?', [$o['payment_method']])->fetchColumn() ?: $o['payment_method'];
$balance = (float)$o['total_amount'] - (float)$o['amount_paid'];
back_to('/orders.php', 'Back to my orders'); page_header('Order ' . $o['reference']);
?>
<h1 class="h1s">Order <?= e($o['reference']) ?></h1>
<div class="detail">
<section>
  <?php if ($o['status'] === 'Cancelled'): ?><div class="flash bad">This order was cancelled<?= $o['cancel_reason'] ? ': ' . e($o['cancel_reason']) : '' ?>.</div>
  <?php else: ?><ol class="timeline">
    <?php foreach ($steps as $i => $s): $cls = $i < $cur ? 'done' : ($i === $cur ? 'now' : ''); ?><li class="<?= $cls ?>"><?= e($s) ?></li><?php endforeach; ?></ol><?php endif; ?>
  <table class="t"><thead><tr><th>Vehicle</th><th class="right">Price</th></tr></thead><tbody>
  <?php foreach ($items as $it): ?><tr><td><a href="/vehicle.php?id=<?= (int)$it['vehicle_id'] ?>"><?= e($it['title']) ?></a><br><span class="mute"><?= e($it['stock_ref']) ?></span></td><td class="right"><?= money($it['price']) ?></td></tr><?php endforeach; ?>
  </tbody></table>
  <?php
  $rets = q('SELECT r.*, oi.title FROM order_returns r JOIN order_items oi ON oi.order_id = r.order_id AND oi.vehicle_id = r.vehicle_id WHERE r.order_id = ? ORDER BY r.id', [$o['id']])->fetchAll();
  $rdl = return_deadline($o);
  $canReturn = $rdl !== null && strtotime($rdl) >= time() && count($rets) < count($items);
  if ($rets || $canReturn || ($o['status'] === 'Completed' && return_days() > 0)): ?>
  <h2>Returns</h2>
  <?php foreach ($rets as $r): $tone = ['Requested' => 'warn', 'Approved' => 'ok', 'Received' => 'ok', 'Completed' => 'ok', 'Rejected' => 'bad'][$r['status']] ?? ''; ?>
    <div class="panel"><p><strong><?= e($r['title']) ?></strong> <?= pill($r['status'] === 'Requested' ? 'Waiting for review' : $r['status'], $tone) ?></p>
    <p class="mute">Reason: <?= e($r['reason']) ?>. Requested <?= e(date('j M Y', strtotime($r['created_at']))) ?>.</p>
    <?php if ($r['status'] === 'Approved'): ?><p>Approved. Please bring the vehicle back to our showroom or contact us to arrange collection.<?= $r['decision_note'] ? ' Note: ' . e($r['decision_note']) : '' ?></p><?php endif; ?>
    <?php if ($r['status'] === 'Rejected'): ?><p>We could not approve this return: <?= e((string)$r['decision_note']) ?>. <a href="/contact.php?ref=<?= urlencode($o['reference']) ?>">Contact us</a> if you disagree.</p><?php endif; ?>
    <?php if ($r['status'] === 'Received'): ?><p>We have your vehicle back. We are finishing the refund (if any).</p><?php endif; ?>
    <?php if ($r['status'] === 'Completed'): ?><p>Completed. Refund: <strong><?= money($r['refund_amount']) ?></strong>. <?= e((string)$r['outcome_note']) ?></p><?php endif; ?></div>
  <?php endforeach; ?>
  <?php if ($canReturn): ?><p><a class="btn" href="/return.php?ref=<?= urlencode($o['reference']) ?>">Request a return</a> <span class="mute">until <?= e(date('j M Y', strtotime($rdl))) ?></span></p>
  <?php elseif ($o['status'] === 'Completed' && !$rets): ?><p class="mute">The return period for this order has ended. <a href="/contact.php?ref=<?= urlencode($o['reference']) ?>">Contact us</a> if something is wrong.</p><?php endif; ?>
  <?php endif; ?>
  <?php if ($o['status'] === 'Completed'):
    $rv = q('SELECT status FROM reviews WHERE order_id = ?', [$o['id']])->fetchColumn(); ?>
    <p><?php if ($rv): ?><span class="mute">Thanks for your review<?= $rv === 'Pending' ? ' (waiting for approval)' : '' ?>.</span>
    <?php else: ?><a class="btn" href="/review.php?ref=<?= urlencode($o['reference']) ?>">Rate your purchase</a><?php endif; ?></p>
  <?php endif; ?>
  <h2>Updates</h2>
  <?php foreach ($hist as $h): ?><p><strong><?= e($h['to_status']) ?></strong> <span class="mute"><?= e(date('j M Y, H:i', strtotime($h['created_at']))) ?></span><?= $h['note'] ? '<br>' . e($h['note']) : '' ?></p><?php endforeach; ?>
</section>
<aside>
  <div class="panel"><h3>Payment</h3>
    <p>Status: <span class="pill <?= $o['payment_status'] === 'Paid' ? 'ok' : 'warn' ?>"><?= e($o['payment_status']) ?></span></p>
    <?php if ((float)$o['discount_amount'] > 0): ?><div class="line"><span>Discount<?= $o['coupon_code'] ? ' (' . e($o['coupon_code']) . ')' : '' ?></span><span>-<?= money($o['discount_amount']) ?></span></div><?php endif; ?>
    <div class="line"><span>Total</span><strong><?= money($o['total_amount']) ?></strong></div>
    <div class="line"><span>Due now (<?= e($o['payment_plan']) ?>)</span><strong><?= money($o['amount_due_now']) ?></strong></div>
    <div class="line"><span>Verified paid</span><span><?= money($o['amount_paid']) ?></span></div>
    <div class="line"><span>Outstanding</span><strong><?= money($balance) ?></strong></div>
    <p class="mute">Method: <?= e($methodLabel) ?></p>
    <?php if (in_array($o['payment_method'], ['card_test', 'momo_test'], true) && $o['status'] === 'Awaiting Payment' && $balance > 0.001): ?>
      <a class="btn block" href="/pay_test.php?ref=<?= urlencode($o['reference']) ?>">Pay now (test mode)</a>
      <p class="mute"><small>Sandbox payment: no real money moves.</small></p>
    <?php elseif (in_array($o['payment_method'], ['card_test', 'momo_test'], true) && $o['status'] === 'Awaiting Confirmation'): ?>
      <div class="notice">We are confirming your vehicle. The <strong>Pay now</strong> button appears here once confirmed.</div>
    <?php endif; ?>
    <?php if ($o['payment_method'] === 'bank_transfer' && $o['status'] !== 'Cancelled'): ?>
      <div class="notice"><strong>Pay by bank transfer</strong><br><?= nl2br(e(setting('bank_details'))) ?><br>Reference to quote: <strong><?= e($o['reference']) ?></strong><br>
      <small>Confirm account details with us before sending large amounts. Your payment is marked verified only after our finance team checks it.</small></div>
    <?php endif; ?>
    <?php if ($res && $o['payment_status'] !== 'Paid'): ?><p class="mute">Reserved until <?= e(date('j M Y, H:i', strtotime($res))) ?></p><?php endif; ?>
  </div>
  <div class="panel"><h3>Handover</h3><p><?= e($o['handover_type']) ?>: <?= e($o['handover_location']) ?></p>
    <p class="mute">Questions? <a href="/contact.php?ref=<?= urlencode($o['reference']) ?>">Ask about this order</a> or <a href="https://wa.me/<?= e(setting('whatsapp')) ?>?text=<?= rawurlencode('Order ' . $o['reference']) ?>">message us on WhatsApp</a></p></div>
</aside></div>
<?php page_footer();
