<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$c = require_customer();
$ref = (string)($_GET['ref'] ?? $_POST['ref'] ?? '');
$o = q('SELECT * FROM orders WHERE reference = ? AND customer_id = ?', [$ref, $c['id']])->fetch();
if (!$o) { flash('Order not found.', 'warn'); redirect('/orders.php'); }
$back = '/order.php?ref=' . urlencode($ref);
$deadline = return_deadline($o);
if ($deadline === null || strtotime($deadline) < time()) {
    flash(return_days() <= 0 ? 'Returns are not available at the moment. Please contact us.' : 'The return period for this order has ended or the order is not completed. Please contact us.', 'warn');
    redirect($back);
}
$items = array_values(array_filter(q('SELECT * FROM order_items WHERE order_id = ?', [$o['id']])->fetchAll(), fn($it) => !return_for_item((int)$o['id'], (int)$it['vehicle_id'])));
if (!$items) { flash('A return has already been requested for every vehicle on this order.'); redirect($back); }
$errors = []; $v = ['vehicle_id' => (string)$items[0]['vehicle_id'], 'reason' => '', 'details' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($v as $k => $_) $v[$k] = trim((string)($_POST[$k] ?? ''));
    if (rate_limited('return:' . $c['id'], 5, 3600)) $errors[] = 'Too many requests. Please wait a while.';
    else try {
        request_return($c, $o, (int)$v['vehicle_id'], $v['reason'], $v['details']);
        flash('Return request sent. We will reply within one working day.');
        redirect($back);
    } catch (UserError $ex) { $errors[] = $ex->getMessage(); }
}
back_to($back, 'Back to order');
page_header('Request a return');
?>
<h1 class="h1s">Request a return</h1>
<p class="mute">Order <?= e($o['reference']) ?>. You can ask for a return until <?= e(date('j M Y, H:i', strtotime($deadline))) ?>. Read our <a href="/info.php?p=refunds" target="_blank" rel="noopener">returns and refunds policy</a>.</p>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<div class="panel w480">
<form method="post"><?= csrf_field() ?><input type="hidden" name="ref" value="<?= e($ref) ?>">
  <div class="field"><label for="vid">Vehicle</label><select id="vid" name="vehicle_id"><?php foreach ($items as $it) echo '<option value="' . (int)$it['vehicle_id'] . '"' . ((string)$it['vehicle_id'] === $v['vehicle_id'] ? ' selected' : '') . '>' . e($it['title'] . ' (' . $it['stock_ref'] . ')') . '</option>'; ?></select></div>
  <div class="field"><label for="reason">Reason</label><select id="reason" name="reason" required><option value="">Choose a reason</option><?php foreach (RETURN_REASONS as $r) echo '<option' . ($v['reason'] === $r ? ' selected' : '') . '>' . e($r) . '</option>'; ?></select></div>
  <div class="field"><label for="details">What is wrong? (10 to 1500 characters)</label><textarea id="details" name="details" rows="5" required minlength="10" maxlength="1500"><?= e($v['details']) ?></textarea></div>
  <button class="btn block" data-confirm="Send this return request to our team? Do not stop using safe driving practices: if the vehicle is unsafe, do not drive it." data-confirm-title="Send return request?" data-confirm-ok="Yes, send request">Send return request</button>
</form></div>
<?php page_footer();
