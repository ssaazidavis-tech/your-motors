<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $id = (int)($_POST['id'] ?? 0); $do = (string)($_POST['do'] ?? '');
    $list = $_SESSION['compare'] ?? [];
    if ($do === 'add' && q('SELECT 1 FROM vehicles WHERE id = ?', [$id])->fetchColumn()) {
        if (count($list) >= 4 && !in_array($id, $list, true)) flash('You can compare up to 4 vehicles.', 'warn');
        elseif (!in_array($id, $list, true)) $list[] = $id;
    } elseif ($do === 'remove') $list = array_values(array_diff($list, [$id]));
    elseif ($do === 'clear') $list = [];
    $_SESSION['compare'] = $list;
    redirect(safe_return($_POST['return'] ?? null, '/compare.php'));
}
$ids = array_map('intval', $_SESSION['compare'] ?? []);
$rows = [];
if ($ids) { $in = implode(',', array_fill(0, count($ids), '?')); $rows = q(VEHICLE_SELECT . " WHERE v.id IN ($in)", $ids)->fetchAll(); }
back_to('/vehicles.php', 'Back to cars'); page_header('Compare vehicles');
echo '<h1 class="h1s">Compare vehicles</h1>';
if (count($rows) < 1) { echo '<div class="panel"><p>Choose vehicles with the Compare button to see them side by side.</p><a class="btn" href="/vehicles.php">Browse cars</a></div>'; page_footer(); exit; }
$fields = ['Price' => fn($v) => $v['price_on_request'] ? 'Ask for price' : money($v['price']), 'Year' => fn($v) => $v['year'],
  'Mileage' => fn($v) => $v['mileage_km'] !== null ? number_format((int)$v['mileage_km']) . ' km' : '-', 'Engine' => fn($v) => $v['engine_cc'] ? number_format((int)$v['engine_cc']) . ' cc' : '-',
  'Fuel' => fn($v) => $v['fuel_type'], 'Transmission' => fn($v) => $v['transmission'], 'Drivetrain' => fn($v) => $v['drivetrain'] ?? '-',
  'Seats' => fn($v) => $v['seats'] ?? '-', 'Condition' => fn($v) => $v['vehicle_condition'], 'Category' => fn($v) => $v['category_name'], 'Availability' => fn($v) => $v['status']];
?>
<div class="scroll"><table class="t"><thead><tr><th></th>
<?php foreach ($rows as $v): ?><th><a href="/vehicle.php?id=<?= (int)$v['id'] ?>"><?= e(vehicle_title($v)) ?></a>
 <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="do" value="remove"><button class="ghost">Remove</button></form></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach ($fields as $label => $fn): ?><tr><th><?= e($label) ?></th><?php foreach ($rows as $v): ?><td><?= e((string)$fn($v)) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div>
<form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="clear"><button class="ghost">Clear comparison</button></form>
<?php page_footer();
