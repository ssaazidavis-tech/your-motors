<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$c = require_customer();
require_verified_customer($c);
release_expired_reservations();

$items = cart_vehicles();
if (!$items) { flash('Your cart is empty.', 'warn'); redirect('/cart.php'); }
foreach ($items as $it) if ($it['status'] !== 'Available') { flash(vehicle_title($it) . ' is no longer available. Remove it to continue.', 'warn'); redirect('/cart.php'); }

// Stage 1 offers only methods that need no external provider. Provider-backed methods
// (mobile money, card) are added only after a real, verified integration exists.
$methods = q('SELECT code, label, instructions FROM payment_methods WHERE enabled = 1 AND requires_provider = 0 ORDER BY sort_order')->fetchAll();
$methodCodes = array_column($methods, 'code');
$depPct = max(0, min(90, (int)setting('deposit_percent', '0')));
$deliveryFee = (float)setting('delivery_fee', '0');
$subtotal = array_sum(array_map(fn($v) => (float)$v['price'], $items));
$couponShow = coupon_applied($subtotal); $discountShow = $couponShow ? coupon_discount($couponShow, $subtotal) : 0.0;

$errors = [];
$f = ['name' => $c['full_name'], 'phone' => $c['phone'], 'email' => $c['email'], 'handover_type' => 'Pickup',
      'handover_location' => '', 'method' => $methodCodes[0] ?? '', 'plan' => 'Full', 'instructions' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    foreach ($f as $k => $_) $f[$k] = trim((string)($_POST[$k] ?? ''));
    if (rate_limited('order:' . $c['id'], 5, 600)) $errors[] = 'Too many order attempts. Wait a few minutes.';
    if ($f['name'] === '' || mb_strlen($f['name']) > 120) $errors[] = 'Enter your name.';
    if (!preg_match('/^\+?[0-9 ]{9,15}$/', $f['phone'])) $errors[] = 'Enter a valid phone number.';
    if (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!in_array($f['handover_type'], ['Pickup', 'Delivery'], true)) $errors[] = 'Choose pickup or delivery.';
    if ($f['handover_location'] === '' || mb_strlen($f['handover_location']) > 255) $errors[] = 'Enter the pickup branch or delivery location.';
    if (!in_array($f['method'], $methodCodes, true)) $errors[] = 'Choose a payment method.';
    if (!in_array($f['plan'], ['Full', 'Deposit'], true) || ($f['plan'] === 'Deposit' && $depPct <= 0)) $errors[] = 'Choose a payment plan.';
    if (mb_strlen($f['instructions']) > 1000) $errors[] = 'Instructions are too long.';
    if (empty($_POST['accept'])) $errors[] = 'Accept the terms to place your order.';

    if (!$errors) {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            $ids = array_map('intval', array_column($items, 'id')); sort($ids);
            $in = implode(',', array_fill(0, count($ids), '?'));
            // Row locks serialise concurrent buyers: the second one sees status 'Reserved' and fails.
            $locked = q("SELECT id, stock_ref, year, make, model, grade, price, status FROM vehicles WHERE id IN ($in) ORDER BY id FOR UPDATE", $ids)->fetchAll();
            if (count($locked) !== count($ids)) throw new UserError('A vehicle in your cart no longer exists.');
            $sub = 0.0;
            foreach ($locked as $lv) {
                if ($lv['status'] !== 'Available') throw new UserError(vehicle_title($lv) . ' was just taken by another customer.');
                $sub += (float)$lv['price'];
            }
            $coupon = coupon_applied($sub); $disc = 0.0;
            if ($coupon) {
                if (!coupon_consume($coupon['code'])) throw new UserError('That coupon was just used up. Remove it from your cart and try again.');
                $disc = coupon_discount($coupon, $sub);
            }
            $fee = $f['handover_type'] === 'Delivery' ? $deliveryFee : 0.0;
            $total = $sub - $disc + $fee;
            $due = $f['plan'] === 'Deposit' ? round($total * $depPct / 100) : $total;
            $ref = 'ORD-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
            q('INSERT INTO orders (reference, customer_id, status, payment_status, payment_method, payment_plan, contact_name, contact_phone, contact_email,
                 handover_type, handover_location, instructions, subtotal, delivery_fee, discount_amount, coupon_code, total_amount, amount_due_now)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
              [$ref, $c['id'], 'Awaiting Confirmation', 'Unpaid', $f['method'], $f['plan'], $f['name'], $f['phone'], $f['email'],
               $f['handover_type'], $f['handover_location'], $f['instructions'] ?: null, $sub, $fee, $disc, $coupon['code'] ?? null, $total, $due]);
            $oid = (int)$pdo->lastInsertId();
            $hours = max(1, (int)setting('reservation_hours', '48'));
            foreach ($locked as $lv) {
                q('INSERT INTO order_items (order_id, vehicle_id, stock_ref, title, price) VALUES (?,?,?,?,?)',
                  [$oid, $lv['id'], $lv['stock_ref'], vehicle_title($lv), $lv['price']]);
                q('INSERT INTO reservations (vehicle_id, order_id, expires_at) VALUES (?,?, DATE_ADD(NOW(), INTERVAL ? HOUR))', [$lv['id'], $oid, $hours]);
                q("UPDATE vehicles SET status='Reserved' WHERE id = ? AND status='Available'", [$lv['id']]);
            }
            q("INSERT INTO payments (order_id, method, reference, amount, status) VALUES (?,?,?,?, 'Pending')", [$oid, $f['method'], $ref, $due]);
            q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?,?,?,?, 'customer', ?)",
              [$oid, null, 'Awaiting Confirmation', 'Order placed by customer', $c['id']]);
            q('DELETE ci FROM cart_items ci JOIN carts ct ON ct.id = ci.cart_id WHERE ct.customer_id = ?', [$c['id']]);
            audit('customer', (int)$c['id'], 'order_placed', 'order', $oid, $ref . ' total ' . $total);
            $pdo->commit();
            coupon_remove();
            ga_queue('purchase', ['transaction_id' => $ref, 'value' => $total, 'shipping' => $fee, 'items' => array_map('ga_item', $locked)]);
            order_notify(['contact_email' => $f['email'], 'contact_name' => $f['name'], 'reference' => $ref], 'Awaiting Confirmation');
            notify_staff('New order ' . $ref, 'A customer placed order ' . $ref . "\nName: " . $f['name'] . "\nEmail: " . $f['email'] . "\nPhone: " . ($f['phone'] ?? '') . "\nTotal: " . money($total) . "\n\nConfirm it within the reservation window.");
            flash('Order placed. Your vehicle is reserved while we confirm it.');
            redirect('/order.php?ref=' . urlencode($ref));
        } catch (UserError $ex) {
            $pdo->rollBack();
            flash($ex->getMessage(), 'warn');
            redirect('/cart.php');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('checkout: ' . $ex->getMessage());
            $errors[] = 'We could not place your order. Nothing was charged. Please try again.';
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') ga_queue('begin_checkout', ['value' => $subtotal, 'items' => array_map('ga_item', $items)]);
$feeNow = $f['handover_type'] === 'Delivery' ? $deliveryFee : 0.0;
back_to('/cart.php', 'Back to cart'); page_header('Checkout');
?>
<h1 class="h1s">Checkout</h1>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<div class="notice">Placing an order is a purchase <strong>request</strong>. The sale is confirmed only after our team confirms the vehicle and your payment is verified.</div>
<form method="post" class="checkout"><?= csrf_field() ?>
<div>
  <div class="panel"><h3>1. Your contact details</h3>
    <div class="row">
      <div class="field"><label for="name">Full name</label><input id="name" name="name" required value="<?= e($f['name']) ?>"></div>
      <div class="field"><label for="phone">Phone</label><input id="phone" name="phone" required value="<?= e($f['phone']) ?>"></div>
    </div><div class="field"><label for="email">Email</label><input id="email" type="email" name="email" required value="<?= e($f['email']) ?>"></div></div><br>
  <div class="panel"><h3>2. Handover</h3>
    <div class="opt"><input type="radio" id="h1" name="handover_type" value="Pickup"<?= $f['handover_type'] === 'Pickup' ? ' checked' : '' ?>><label for="h1">Pick up from the showroom</label></div>
    <div class="opt"><input type="radio" id="h2" name="handover_type" value="Delivery"<?= $f['handover_type'] === 'Delivery' ? ' checked' : '' ?>><label for="h2">Delivery<?= $deliveryFee > 0 ? ' (' . money($deliveryFee) . ')' : '' ?></label></div>
    <div class="field"><label for="loc">Pickup branch or delivery address</label><input id="loc" name="handover_location" required maxlength="255" value="<?= e($f['handover_location']) ?>"></div>
    <div class="field"><label for="ins">Additional instructions (optional)</label><textarea id="ins" name="instructions" maxlength="1000"><?= e($f['instructions']) ?></textarea></div></div><br>
  <div class="panel"><h3>3. Payment method and plan</h3>
    <?php foreach ($methods as $i => $m): ?><div class="opt"><input type="radio" id="m<?= $i ?>" name="method" value="<?= e($m['code']) ?>"<?= $f['method'] === $m['code'] ? ' checked' : '' ?>>
      <label for="m<?= $i ?>"><?= e($m['label']) ?><small><?= e($m['instructions']) ?></small></label></div><?php endforeach; ?>
    <div class="opt"><input type="radio" id="p1" name="plan" value="Full"<?= $f['plan'] === 'Full' ? ' checked' : '' ?>><label for="p1">Pay in full<small>Full amount before handover.</small></label></div>
    <?php if ($depPct > 0): ?><div class="opt"><input type="radio" id="p2" name="plan" value="Deposit"<?= $f['plan'] === 'Deposit' ? ' checked' : '' ?>><label for="p2">Reservation deposit (<?= $depPct ?>%)<small>Balance due before handover.</small></label></div><?php endif; ?></div>
</div>
<aside><div class="panel"><h3>Your order</h3>
  <?php foreach ($items as $v): ?><div class="line"><span><?= e(vehicle_title($v)) ?></span><strong><?= money($v['price']) ?></strong></div><?php endforeach; ?>
  <div class="totals">
    <div class="line"><span>Subtotal</span><span><?= money($subtotal) ?></span></div>
    <?php if ($couponShow): ?><div class="line"><span>Coupon <?= e($couponShow['code']) ?></span><span>-<?= money($discountShow) ?></span></div><?php endif; ?>
    <div class="line"><span>Delivery (if selected)</span><span><?= money($deliveryFee) ?></span></div>
    <div class="line grand"><span>Total</span><span><?= money($subtotal - $discountShow + $feeNow) ?></span></div>
  </div>
  <p class="mute">Your vehicle is held for <?= (int)setting('reservation_hours', '48') ?> hours after you place the order. Unpaid orders then release the vehicle automatically.</p>
  <div class="field"><label><input type="checkbox" name="accept" value="1" class="chk"> I accept the <a href="/info.php?p=terms" target="_blank" rel="noopener">terms of sale</a>, <a href="/info.php?p=refunds" target="_blank" rel="noopener">returns &amp; refunds policy</a> and <a href="/info.php?p=privacy" target="_blank" rel="noopener">privacy policy</a>, and understand this is a purchase request until confirmed.</label></div>
  <button class="btn block" data-confirm="<?= e('Your vehicle will be reserved for ' . setting('reservation_hours', '48') . ' hours while we confirm it. You can pay after we confirm.') ?>" data-confirm-title="Place this order?" data-confirm-ok="Yes, place order">Place order</button></div></aside>
</form>
<?php page_footer();
