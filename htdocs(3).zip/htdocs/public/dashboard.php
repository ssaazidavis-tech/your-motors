<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/dash_layout.php';
$c = require_customer();
release_expired_reservations();
$cid = (int)$c['id'];
$n = fn(string $sql, array $p = []): int => (int)q($sql, $p)->fetchColumn();

$total   = $n('SELECT COUNT(*) FROM orders WHERE customer_id = ?', [$cid]);
$wish    = $n('SELECT COUNT(*) FROM wishlists WHERE customer_id = ?', [$cid]);
$enq     = $n("SELECT COUNT(*) FROM inquiries WHERE customer_id = ? AND type <> 'Test Drive'", [$cid]);
$drives  = $n("SELECT COUNT(*) FROM inquiries WHERE customer_id = ? AND type = 'Test Drive'", [$cid]);

$orders = q('SELECT o.reference, o.status, o.payment_status, o.total_amount, o.amount_paid, o.created_at,
    (SELECT title FROM order_items WHERE order_id = o.id ORDER BY id LIMIT 1) AS title,
    (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS items,
    (SELECT i.path FROM order_items oi JOIN vehicle_images i ON i.vehicle_id = oi.vehicle_id WHERE oi.order_id = o.id ORDER BY oi.id, i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS img
    FROM orders o WHERE o.customer_id = ? ORDER BY o.id DESC LIMIT 5', [$cid])->fetchAll();

// A car being held for this customer, if any: the most useful thing to say first.
$hold = q("SELECT r.expires_at, o.reference, o.status,
    (SELECT title FROM order_items WHERE order_id = o.id ORDER BY id LIMIT 1) AS title
    FROM reservations r JOIN orders o ON o.id = r.order_id
    WHERE r.status = 'Active' AND o.customer_id = ? AND r.expires_at > NOW() ORDER BY r.expires_at LIMIT 1", [$cid])->fetch();

$saved = q(VEHICLE_SELECT . ' JOIN wishlists w ON w.vehicle_id = v.id WHERE w.customer_id = ? ORDER BY w.created_at DESC LIMIT 3', [$cid])->fetchAll();

$feed = q('SELECT h.from_status, h.to_status, h.note, h.created_at, o.reference
    FROM order_status_history h JOIN orders o ON o.id = h.order_id WHERE o.customer_id = ? ORDER BY h.id DESC LIMIT 5', [$cid])->fetchAll();
$say = function (array $h): array {   // [tone, icon, text]
    $r = $h['reference'];
    if ($h['from_status'] === $h['to_status'] && $h['note']) return ['', 'info', 'Order ' . $r . ': ' . $h['note']];
    return match ($h['to_status']) {
        'Completed'          => ['ok', 'check', "Order $r is complete."],
        'Cancelled'          => ['bad', 'alert', "Order $r was cancelled."],
        'Payment Verified'   => ['ok', 'check', "We received your payment for order $r."],
        'Awaiting Payment'   => ['sig', 'info', "Order $r is confirmed. Payment is now due."],
        'Order Processing'   => ['sig', 'info', "We are preparing order $r."],
        'Ready for Handover' => ['ok', 'check', "Order $r is ready for handover."],
        default              => ['', 'clock', "We received order $r and will confirm it shortly."],
    };
};

$first = explode(' ', trim($c['full_name']))[0];
$hours = max(1, (int)setting('reservation_hours', '48'));
$wa = preg_replace('/\D+/', '', setting('whatsapp'));

dash_header('Dashboard', 'dashboard');
dash_head('Welcome back, ' . $first, 'Here is what is happening with your account.');
?>
<div class="dgrid">
<div class="dcol">

  <div class="kpis">
    <?= kpi('clipboard', 'y', 'Orders', (string)$total, '', '/orders.php', 'View orders') ?>
    <?= kpi('heart', 'k', 'Saved cars', (string)$wish, '', '/wishlist.php', 'View wishlist') ?>
    <?= kpi('chat', 'g', 'Enquiries', (string)$enq, '', '/requests.php', 'View enquiries') ?>
    <?= kpi('calendar', 'w', 'Test drives', (string)$drives, '', '/requests.php?type=drive', 'View requests') ?>
  </div>

  <section class="dhero" aria-labelledby="hero-h">
  <?php if ($hold): ?>
    <h2 id="hero-h">Your <?= e((string)$hold['title']) ?> is on hold</h2>
    <p>Reserved until <?= e(date('D j M, H:i', strtotime($hold['expires_at']))) ?>. Finish payment before then, or the car goes back on sale.</p>
    <div class="hold"><a class="btn" href="/order.php?ref=<?= urlencode($hold['reference']) ?>">View order <?= e($hold['reference']) ?></a>
      <a class="btn alt" href="/vehicles.php">Keep browsing</a></div>
  <?php else: ?>
    <h2 id="hero-h">Find your next car</h2>
    <p>Reserve any available car online. We hold it for <?= $hours ?> hours while you arrange payment.</p>
    <form class="dfinder" action="/vehicles.php" method="get"><input type="search" name="q" placeholder="Make, model or stock no." aria-label="Search cars"><button class="btn">Browse cars</button></form>
  <?php endif; ?>
    <div class="stripe" aria-hidden="true"></div>
  </section>

  <section class="panel flush" aria-labelledby="ro-h">
    <div class="phead"><h2 id="ro-h">Recent orders</h2><?php if ($orders): ?><a href="/orders.php">View all orders</a><?php endif; ?></div>
    <?php if (!$orders): ?><p class="empty">No orders yet. When you reserve a car it will show up here.</p>
    <?php else: ?><div class="scroll"><table class="dt"><thead><tr><th>Vehicle</th><th>Order</th><th>Status</th><th class="right">Total</th><th><span class="sr">Open</span></th></tr></thead><tbody>
    <?php foreach ($orders as $o): $bal = (float)$o['total_amount'] - (float)$o['amount_paid'];
          $open = !in_array($o['status'], ['Completed', 'Cancelled'], true); ?>
      <tr><td><div class="vcell"><?= vthumb($o['img'], (string)$o['title']) ?><span><b><?= e((string)$o['title']) ?></b>
            <small><?= (int)$o['items'] > 1 ? '+' . ((int)$o['items'] - 1) . ' more car' . ((int)$o['items'] > 2 ? 's' : '') : e(date('j M Y', strtotime($o['created_at']))) ?></small></span></div></td>
        <td class="num-cell"><a href="/order.php?ref=<?= urlencode($o['reference']) ?>"><?= e($o['reference']) ?></a></td>
        <td><?= order_pill($o['status']) ?></td>
        <td class="right num-cell"><?= money($o['total_amount']) ?><?php if ($open && $bal > 0.5 && (float)$o['amount_paid'] > 0): ?><div class="sub">Balance <?= money($bal) ?></div><?php endif; ?></td>
        <td class="go"><a href="/order.php?ref=<?= urlencode($o['reference']) ?>" aria-label="Open order <?= e($o['reference']) ?>"><?= icon('chevron', 18) ?></a></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </section>

  <?php if ($saved): ?>
  <section class="panel" aria-labelledby="sv-h">
    <div class="phead"><h2 id="sv-h">Saved cars</h2><a href="/wishlist.php">View wishlist</a></div>
    <?php foreach ($saved as $v): ?>
      <div class="vrow"><a class="vcell" href="/vehicle.php?id=<?= (int)$v['id'] ?>"><?= vthumb($v['img'], (string)$v['make']) ?><span><b><?= e(vehicle_title($v)) ?></b><small><?= e($v['fuel_type']) ?>, <?= e($v['transmission']) ?></small></span></a>
        <p class="price"><?= $v['price_on_request'] ? 'Ask for price' : money($v['price']) ?></p><?= vehicle_pill($v['status']) ?></div>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

</div>
<aside class="rail" aria-label="Account shortcuts">

  <section class="panel">
    <div class="profile"><span class="avatar"><?= e(initials($c['full_name'])) ?></span>
      <div><strong><?= e($c['full_name']) ?></strong><span><?= e($c['email']) ?></span><br><span><?= e($c['phone']) ?></span></div></div>
    <a class="btn alt block" href="/account.php">Edit profile</a>
  </section>

  <section class="panel">
    <div class="phead"><h2>Quick actions</h2></div>
    <nav class="qa" aria-label="Quick actions">
      <a href="/vehicles.php"><span class="ico"><?= icon('car', 18) ?></span>Browse cars<?= icon('chevron', 16) ?></a>
      <a href="/compare.php"><span class="ico"><?= icon('columns', 18) ?></span>Compare cars<?= icon('chevron', 16) ?></a>
      <a href="/vehicles.php"><span class="ico"><?= icon('calendar', 18) ?></span>Book a test drive<?= icon('chevron', 16) ?></a>
      <a href="/cart.php"><span class="ico"><?= icon('cart', 18) ?></span>Go to cart<?= icon('chevron', 16) ?></a>
    </nav>
  </section>

  <?php if ($wa): ?>
  <section class="panel help">
    <h2>Need help?</h2><p>Questions about a car or an order? Message us on WhatsApp.</p>
    <a class="btn" href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener">Message support</a>
  </section>
  <?php endif; ?>

  <section class="panel" aria-labelledby="ac-h">
    <div class="phead"><h2 id="ac-h">Latest updates</h2></div>
    <?php if (!$feed): ?><p class="empty">Updates on your orders will appear here.</p>
    <?php else: ?><ul class="feed"><?php foreach ($feed as $h): [$tone, $ic, $text] = $say($h); ?>
      <li><span class="dot <?= e($tone) ?>"><?= icon($ic, 16) ?></span><div><a href="/order.php?ref=<?= urlencode($h['reference']) ?>"><?= e($text) ?></a><small><?= e(time_ago($h['created_at'])) ?></small></div></li>
    <?php endforeach; ?></ul><?php endif; ?>
  </section>

</aside>
</div>
<?php dash_footer();
