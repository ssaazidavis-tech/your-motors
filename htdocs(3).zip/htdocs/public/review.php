<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$c = require_customer();
$o = q("SELECT o.id, o.reference FROM orders o WHERE o.reference = ? AND o.customer_id = ? AND o.status = 'Completed'", [(string)($_GET['ref'] ?? $_POST['ref'] ?? ''), $c['id']])->fetch();
if (!$o) { flash('You can review an order after it is completed.', 'warn'); redirect('/orders.php'); }
if (q('SELECT 1 FROM reviews WHERE order_id = ?', [$o['id']])->fetchColumn()) { flash('You already reviewed this order.'); redirect('/order.php?ref=' . urlencode($o['reference'])); }
$item = q('SELECT vehicle_id, title FROM order_items WHERE order_id = ? ORDER BY id LIMIT 1', [$o['id']])->fetch();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $rating = (int)($_POST['rating'] ?? 0); $title = trim((string)($_POST['title'] ?? '')); $body = trim((string)($_POST['body'] ?? ''));
    if ($rating < 1 || $rating > 5) $errors[] = 'Choose a rating from 1 to 5 stars.';
    if (mb_strlen($title) > 100) $errors[] = 'Title is too long.';
    if (mb_strlen($body) > 2000) $errors[] = 'Review is too long.';
    if (!$errors) {
        q('INSERT IGNORE INTO reviews (order_id, customer_id, vehicle_id, rating, title, body) VALUES (?,?,?,?,?,?)', [$o['id'], $c['id'], $item['vehicle_id'], $rating, $title ?: null, $body ?: null]);
        notify_staff('New review to approve', 'Order ' . $o['reference'] . ' received a ' . $rating . '-star review.');
        flash('Thank you! Your review will appear after our team approves it.');
        redirect('/order.php?ref=' . urlencode($o['reference']));
    }
}
back_to('/order.php?ref=' . urlencode($o['reference']), 'Back to order'); page_header('Rate your purchase');
foreach ($errors as $er) echo '<div class="flash err">' . e($er) . '</div>';
?>
<div class="narrow panel"><h1 class="h1s">Rate your purchase</h1><p class="mute"><?= e($item['title']) ?> (order <?= e($o['reference']) ?>)</p>
<form method="post"><?= csrf_field() ?><input type="hidden" name="ref" value="<?= e($o['reference']) ?>">
<div class="field"><label for="rt">Rating</label><select id="rt" name="rating" required><option value="">Choose...</option>
<?php for ($i = 5; $i >= 1; $i--) echo '<option value="' . $i . '">' . $i . ' - ' . e(stars($i)) . '</option>'; ?></select></div>
<div class="field"><label for="t">Headline (optional)</label><input id="t" name="title" maxlength="100"></div>
<div class="field"><label for="b">Your review (optional)</label><textarea id="b" name="body" maxlength="2000"></textarea></div>
<button class="btn block">Submit review</button></form></div>
<?php page_footer();
