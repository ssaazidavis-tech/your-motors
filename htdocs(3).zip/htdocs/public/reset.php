<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/layout.php';
$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$hash = hash('sha256', $token);
$row = preg_match('/^[a-f0-9]{64}$/', $token)
  ? q('SELECT id, customer_id FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW()', [$hash])->fetch() : false;
$error = '';
if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post();
    $pw = (string)($_POST['password'] ?? '');
    if (strlen($pw) < 8) $error = 'Use a password of at least 8 characters.';
    elseif ($pw !== (string)($_POST['password2'] ?? '')) $error = 'The two passwords do not match.';
    else {
        $pdo = db(); $pdo->beginTransaction();
        $ok = q('UPDATE password_resets SET used_at = NOW() WHERE id = ? AND used_at IS NULL', [$row['id']])->rowCount(); // single use, race safe
        if ($ok) {
            q('UPDATE customers SET password_hash = ? WHERE id = ?', [password_hash($pw, PASSWORD_DEFAULT), $row['customer_id']]);
            q('UPDATE password_resets SET used_at = NOW() WHERE customer_id = ? AND used_at IS NULL', [$row['customer_id']]);
            q('UPDATE customers SET email_verified_at = COALESCE(email_verified_at, NOW()) WHERE id = ?', [$row['customer_id']]); // the reset link reached their inbox
            audit('customer', (int)$row['customer_id'], 'password_reset_done', 'customer', (int)$row['customer_id']);
            $cu = q('SELECT full_name, email FROM customers WHERE id = ?', [$row['customer_id']])->fetch();
            if ($cu) queue_mail((string)$cu['email'], 'Your password was changed', "Hello {$cu['full_name']},\n\nYour password was just changed. If this was not you, reset it again now." . mail_button('Reset my password', app_url('/forgot.php')) . "You can also contact us if you need help.");
        }
        $pdo->commit();
        flash($ok ? 'Password changed. Log in with your new password.' : 'That link was already used.', $ok ? 'ok' : 'warn');
        redirect('/login.php');
    }
}
back_to('/login.php', 'Back to log in'); page_header('Choose a new password'); ?>
<div class="narrow panel"><h1 class="h1s">Choose a new password</h1>
<?php if (!$row): ?><div class="flash warn">This link is invalid or has expired. <a href="/forgot.php">Request a new one</a>.</div>
<?php else: if ($error) echo '<div class="flash err">' . e($error) . '</div>'; ?>
<form method="post"><?= csrf_field() ?><input type="hidden" name="token" value="<?= e($token) ?>">
<div class="field"><label for="pw">New password (8+ characters)</label><input id="pw" type="password" name="password" required minlength="8" autocomplete="new-password"></div>
<div class="field"><label for="pw2">Confirm</label><input id="pw2" type="password" name="password2" required minlength="8" autocomplete="new-password"></div>
<button class="btn block">Save password</button></form><?php endif; ?></div>
<?php page_footer();
