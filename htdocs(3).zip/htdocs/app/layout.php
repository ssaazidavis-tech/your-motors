<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

function page_header(string $title, string $desc = ''): void {
    $cust = current_customer();
    $cartCount = count(cart_ids());
    $cmp = count($_SESSION['compare'] ?? []);
    $biz = setting('business_name', 'Car Dealer');
    // Log in / Sign up links remember the page the visitor is on, so they come back to it afterwards.
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $skipNext = ['login.php', 'register.php', 'logout.php', 'verify.php', 'forgot.php', 'reset.php'];
    $nextQs = (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && !in_array(basename((string)parse_url($uri, PHP_URL_PATH)), $skipNext, true))
        ? '?next=' . urlencode($uri) : '';
    ?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e($biz) ?></title>
<meta name="description" content="<?= e($desc ?: 'Browse inspected vehicles and buy online in Uganda.') ?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..125,400..800&display=swap">
<link rel="stylesheet" href="/assets/style.css"><link rel="stylesheet" href="/assets/features.css">
<meta name="csrf" content="<?= e(csrf_token()) ?>"><meta name="base" content="<?= e(BASE_PATH) ?>">
<?php $gaId = (string)env('GA_MEASUREMENT_ID', ''); if (preg_match('/^G-[A-Z0-9]{6,}$/', $gaId)): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($gaId) ?>"></script>
<script src="/assets/ga-init.js" data-id="<?= e($gaId) ?>"></script>
<?php endif; ?>
<script src="/assets/confirm.js" defer></script>
</head><body>
<header class="top">
  <div class="wrap bar">
    <a class="brand" href="/"><?= e($biz) ?></a>
    <input type="checkbox" id="navtoggle" class="navtoggle" aria-label="Menu">
    <label for="navtoggle" class="burger" aria-hidden="true">Menu</label>
    <nav class="nav">
      <a href="/">Home</a>
      <a href="/vehicles.php">Cars</a>
      <a href="/wishlist.php">Wishlist</a>
      <a href="/contact.php">Help</a>
      <a href="/cart.php" class="cartlink">Cart<?= $cartCount ? ' <b>' . $cartCount . '</b>' : '' ?></a>
      <?php if ($cust): ?>
        <a href="/dashboard.php">Dashboard</a>
        <form method="post" action="/logout.php" class="inline"><?= csrf_field() ?><button class="linkbtn" data-confirm="You will need to log in again to see your orders." data-confirm-title="Log out?" data-confirm-ok="Yes, log out">Log out</button></form>
      <?php else: ?>
        <a href="/login.php<?= e($nextQs) ?>">Log in</a><a class="btn small" href="/register.php<?= e($nextQs) ?>">Sign up</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="wrap"><?= back_html() ?>
<?php if (($vc = current_customer()) && empty($vc['email_verified_at']) && basename($_SERVER['SCRIPT_NAME']) !== 'verify.php'): ?>
  <div class="flash warn" role="status">Please verify your email to place orders.
    <form method="post" action="/verify.php" class="inline"><?= csrf_field() ?><button class="btn small">Resend verification email</button></form></div>
<?php endif; ?>
<?php foreach (flash() ?? [] as [$type, $msg]): ?>
  <div class="flash <?= e($type) ?>" role="status"><?= e($msg) ?></div>
<?php endforeach;
}

function page_footer(): void { ?>
</main>
<?php $cmpN = count($_SESSION['compare'] ?? []); if ($cmpN > 0 && basename((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH)) !== 'compare.php'): ?>
<a class="compare-fab" href="/compare.php">Compare (<?= $cmpN ?>)</a>
<?php endif; ?>
<?= ga_events_html() ?>
<script src="/assets/features.js" defer></script>
<?php if ((string)env('ANTHROPIC_API_KEY', '') !== '' && env('CHAT_ENABLED', '1') !== '0'): ?><script src="/assets/chat.js" defer></script><?php endif; ?>
<footer class="foot"><div class="wrap footgrid">
  <div><strong><?= e(setting('business_name')) ?></strong><p><?= e(setting('address')) ?></p></div>
  <div><p><a href="tel:<?= e(preg_replace('/\s+/', '', setting('phone'))) ?>"><?= e(setting('phone')) ?></a></p>
       <p><a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></p></div>
  <div><a class="btn" href="https://wa.me/<?= e(setting('whatsapp')) ?>">Chat on WhatsApp</a>
       <p class="stafflink"><a href="/admin/login.php">Staff login</a></p></div>
</div>
  <div class="wrap"><p class="mute footlinks">
    <a href="/info.php?p=about">About</a> · <a href="/info.php?p=delivery">Delivery</a> · <a href="/info.php?p=faq">FAQ</a> · <a href="/contact.php">Contact</a> ·
    <a href="/info.php?p=terms">Terms of sale</a> · <a href="/info.php?p=refunds">Returns &amp; refunds</a> · <a href="/info.php?p=privacy">Privacy</a> ·
    <a href="/info.php?p=cookies">Cookies</a> · <a href="/info.php?p=sustainability">Ethics &amp; sustainability</a></p></div></footer>
</body></html>
<?php }

function return_field(): string {
    return '<input type="hidden" name="return" value="' . e($_SERVER['REQUEST_URI'] ?? '/') . '">';
}

function status_badge(string $s): string {
    $cls = ['Available' => 'ok', 'Reserved' => 'warn', 'Sold' => 'bad'][$s] ?? '';
    return '<span class="badge ' . $cls . '">' . e($s) . '</span>';
}

function vehicle_card(array $v, array $wish = []): void {
    $title = vehicle_title($v);
    $pct = discount_pct($v);
    $wished = in_array((int)$v['id'], $wish, true);
    $cmp = in_array((int)$v['id'], $_SESSION['compare'] ?? [], true);
    ?>
<article class="card">
  <a class="photo" href="/vehicle.php?id=<?= (int)$v['id'] ?>" aria-label="<?= e($title) ?>">
    <?php if ($v['img']): ?><img src="/uploads/<?= e($v['img']) ?>" alt="<?= e($title) ?>" loading="lazy">
    <?php else: ?><span class="noimg"><?= e($v['make']) ?></span><?php endif; ?>
    <?= status_badge($v['status']) ?>
    <?php if ($pct): ?><span class="off"><?= $pct ?>% off</span><?php endif; ?>
  </a>
  <div class="cbody">
    <h3><a href="/vehicle.php?id=<?= (int)$v['id'] ?>"><?= e($title) ?></a></h3>
    <p class="price">
      <?php if ($v['price_on_request']): ?>Ask for price
      <?php else: ?><?= money($v['price']) ?><?php if ($pct): ?> <s><?= money($v['original_price']) ?></s><?php endif; ?><?php endif; ?>
    </p>
    <ul class="chips">
      <li><?= e($v['transmission']) ?></li>
      <?php if ($v['drivetrain']): ?><li><?= e($v['drivetrain']) ?></li><?php endif; ?>
      <li><?= e($v['fuel_type']) ?></li>
      <?php if ($v['seats']): ?><li><?= (int)$v['seats'] ?> seats</li><?php endif; ?>
      <?php if ($v['engine_cc']): ?><li><?= number_format((int)$v['engine_cc']) ?> cc</li><?php endif; ?>
      <?php if ($v['mileage_km'] !== null): ?><li><?= number_format((int)$v['mileage_km']) ?> km</li><?php endif; ?>
    </ul>
    <div class="actions">
      <button type="button" class="ghost" data-quick="<?= (int)$v['id'] ?>">Quick view</button>
      <form method="post" action="/wishlist.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= (int)$v['id'] ?>">
        <button class="ghost" aria-pressed="<?= $wished ? 'true' : 'false' ?>"><?= $wished ? 'Saved' : 'Save' ?></button></form>
      <form method="post" action="/compare.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="do" value="<?= $cmp ? 'remove' : 'add' ?>">
        <button class="ghost"><?= $cmp ? 'Remove compare' : 'Compare' ?></button></form>
      <?php if ($v['status'] === 'Available' && !$v['price_on_request']): ?>
      <form method="post" action="/cart.php"><?= csrf_field() . return_field() ?><input type="hidden" name="id" value="<?= (int)$v['id'] ?>"><input type="hidden" name="do" value="add">
        <button class="btn small">Add to cart</button></form>
      <?php else: ?><a class="btn small alt" href="/vehicle.php?id=<?= (int)$v['id'] ?>#inquiry">Send inquiry</a><?php endif; ?>
    </div>
  </div>
</article>
<?php }

function customer_wishlist_ids(): array {
    $c = current_customer();
    return $c ? array_map('intval', q('SELECT vehicle_id FROM wishlists WHERE customer_id = ?', [$c['id']])->fetchAll(PDO::FETCH_COLUMN)) : [];
}
