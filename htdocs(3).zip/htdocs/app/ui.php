<?php
declare(strict_types=1);
// Small view helpers shared by the customer and staff dashboards. No colours live here: the
// tone names (y, k, g, w, ok, warn, bad, sig) map to the existing tokens in assets/dashboard.css.
require_once __DIR__ . '/bootstrap.php';

/** Inline SVG icon (stroke style, takes the surrounding text colour). */
function icon(string $name, int $size = 20): string {
    static $p = [
        'grid'     => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
        'user'     => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'users'    => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'heart'    => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
        'cart'     => '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
        'clipboard'=> '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/>',
        'car'      => '<path d="M5 11l1.5-4.5A2 2 0 0 1 8.4 5h7.2a2 2 0 0 1 1.9 1.5L19 11"/><rect x="3" y="11" width="18" height="6" rx="2"/><path d="M6 17v2M18 17v2"/><circle cx="7.5" cy="14" r=".6"/><circle cx="16.5" cy="14" r=".6"/>',
        'tag'      => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
        'chat'     => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'chart'    => '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
        'shield'   => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'cog'      => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
        'columns'  => '<rect x="3" y="3" width="7" height="18" rx="1"/><rect x="14" y="3" width="7" height="18" rx="1"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'headset'  => '<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',
        'plus'     => '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
        'chevron'  => '<polyline points="9 18 15 12 9 6"/>',
        'search'   => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'check'    => '<polyline points="20 6 9 17 4 12"/>',
        'clock'    => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'card'     => '<rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/>',
        'up'       => '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
        'down'     => '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
        'alert'    => '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
        'info'     => '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
        'home'     => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    ];
    return '<svg class="ic" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
         . ($p[$name] ?? '') . '</svg>';
}

function pill(string $label, string $tone = ''): string {
    return '<span class="pill' . ($tone !== '' ? ' ' . $tone : '') . '">' . e($label) . '</span>';
}
function order_pill(string $s): string {
    $m = ['Completed' => 'ok', 'Cancelled' => 'bad', 'Awaiting Confirmation' => 'warn', 'Awaiting Payment' => 'warn',
          'Payment Verified' => 'sig', 'Order Processing' => 'sig', 'Ready for Handover' => 'sig'];
    return pill($s, $m[$s] ?? '');
}
function pay_pill(string $s): string {
    $m = ['Paid' => 'ok', 'Partially Paid' => 'sig', 'Pending Verification' => 'warn', 'Refunded' => 'bad'];
    return pill($s, $m[$s] ?? '');
}
function vehicle_pill(string $s): string {
    return pill($s, ['Available' => 'ok', 'Reserved' => 'warn', 'Sold' => 'bad'][$s] ?? '');
}
function request_pill(string $s): string {
    $m = ['New' => ['Received', 'warn'], 'Contacted' => ['We contacted you', 'sig'], 'Closed' => ['Closed', '']];
    [$label, $tone] = $m[$s] ?? [$s, ''];
    return pill($label, $tone);
}

function time_ago(string $dt): string {
    $t = strtotime($dt);
    $d = max(0, time() - (int)$t);
    if ($d < 60) return 'just now';
    if ($d < 3600) return intdiv($d, 60) . ' min ago';
    if ($d < 86400) return intdiv($d, 3600) . ' h ago';
    if ($d < 86400 * 7) { $n = intdiv($d, 86400); return $n . ($n === 1 ? ' day ago' : ' days ago'); }
    return date('j M Y', (int)$t);
}
function initials(string $name): string {
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $out = '';
    foreach (array_slice(array_filter($parts), 0, 2) as $p) $out .= mb_strtoupper(mb_substr($p, 0, 1));
    return $out !== '' ? $out : '?';
}
function short_num(float $v): string {
    $fmt = fn(float $x, string $u): string => rtrim(rtrim(number_format($x, 1, '.', ''), '0'), '.') . $u;
    if ($v >= 1e9) return $fmt($v / 1e9, 'B');
    if ($v >= 1e6) return $fmt($v / 1e6, 'M');
    if ($v >= 1e3) return $fmt($v / 1e3, 'K');
    return (string)(int)round($v);
}
function money_short($n): string { return 'UGX ' . short_num((float)$n); }

/** Vehicle photo thumbnail, or a hatched placeholder that shows the make (same look as the catalogue). */
function vthumb(?string $img, string $fallback): string {
    return $img
        ? '<img class="vthumb" src="/uploads/' . e($img) . '" alt="" loading="lazy">'
        : '<span class="vthumb none" aria-hidden="true">' . e(mb_strtoupper(mb_substr($fallback, 0, 3))) . '</span>';
}

/** Percentage change against the previous period, as trusted HTML. */
function delta(float $now, float $prev, string $vs): string {
    $tail = ' <span class="vs">' . e($vs) . '</span>';
    if ($prev <= 0) return $now > 0 ? '<span class="delta up">' . icon('up', 14) . 'New</span>' . $tail : '<span class="vs">No activity ' . e($vs) . '</span>';
    $p = (int)round(($now - $prev) / $prev * 100);
    if ($p === 0) return '<span class="delta flat">No change</span>' . $tail;
    return '<span class="delta ' . ($p > 0 ? 'up' : 'down') . '">' . icon($p > 0 ? 'up' : 'down', 14) . abs($p) . '%</span>' . $tail;
}

/** One stat tile. $subHtml must already be escaped / trusted. The whole tile is the link target. */
function kpi(string $icon, string $tone, string $label, string $value, string $subHtml = '', string $href = '', string $linkText = ''): string {
    return '<div class="kpi"><span class="chip ' . e($tone) . '">' . icon($icon, 22) . '</span>'
         . '<span class="lbl">' . e($label) . '</span><strong class="num">' . e($value) . '</strong>'
         . ($subHtml !== '' ? '<span class="sub">' . $subHtml . '</span>' : '')
         . ($href !== '' ? '<a class="more" href="' . e($href) . '">' . e($linkText) . '</a>' : '') . '</div>';
}

/** Page title row used at the top of every dashboard screen. */
function dash_head(string $h1, string $sub = '', string $rightHtml = ''): void {
    echo '<div class="dhead"><div><h1>' . e($h1) . '</h1>' . ($sub !== '' ? '<p>' . e($sub) . '</p>' : '') . '</div>' . $rightHtml . '</div>';
}
