<?php
declare(strict_types=1);
// Returns after handover. Flow: customer requests -> staff approve or reject -> vehicle received back -> refund recorded and case closed.
// The order stays "Completed"; the return is tracked separately and every step is written to the order history.
const RETURN_REASONS = ['Not as described', 'Mechanical fault found', 'Undisclosed damage', 'Wrong mileage or documents', 'Changed my mind', 'Other'];

function return_days(): int { return max(0, (int)setting('return_days', '7')); }
// Last moment a return may be requested, or null if returns are off / the order is not completed.
function return_deadline(array $o): ?string {
    if (return_days() <= 0 || ($o['status'] ?? '') !== 'Completed') return null;
    $done = q("SELECT MAX(created_at) FROM order_status_history WHERE order_id = ? AND to_status = 'Completed'", [$o['id']])->fetchColumn();
    return $done ? date('Y-m-d H:i:s', strtotime($done . ' +' . return_days() . ' days')) : null;
}
function return_for_item(int $oid, int $vid): ?array {
    return q('SELECT * FROM order_returns WHERE order_id = ? AND vehicle_id = ?', [$oid, $vid])->fetch() ?: null;
}
function return_log(int $oid, string $note, string $actorType, ?int $actorId): void {
    q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?, 'Completed', 'Completed', ?, ?, ?)", [$oid, mb_substr($note, 0, 255), $actorType, $actorId]);
}
function return_customer_mail(array $r, string $subject, string $text): void {
    $o = q('SELECT reference, contact_name, contact_email FROM orders WHERE id = ?', [$r['order_id']])->fetch();
    if (!$o) return;
    queue_mail((string)$o['contact_email'], $subject . ' (order ' . $o['reference'] . ')',
        'Hello ' . $o['contact_name'] . ",\n\n" . $text . mail_button('View my order', app_url('/order.php?ref=' . urlencode((string)$o['reference']))) . setting('business_name'));
}

// ---------- Customer ----------
function request_return(array $c, array $o, int $vid, string $reason, string $details): void {
    if ((int)$o['customer_id'] !== (int)$c['id']) throw new UserError('Order not found.');
    $deadline = return_deadline($o);
    if ($deadline === null) throw new UserError(return_days() <= 0 ? 'Returns are not available at the moment. Please contact us.' : 'Returns can only be requested on completed orders.');
    if (strtotime($deadline) < time()) throw new UserError('The ' . return_days() . '-day return period for this order has ended. Please contact us and we will look at your case.');
    $item = q('SELECT * FROM order_items WHERE order_id = ? AND vehicle_id = ?', [$o['id'], $vid])->fetch();
    if (!$item) throw new UserError('That vehicle is not part of this order.');
    if (!in_array($reason, RETURN_REASONS, true)) throw new UserError('Choose a reason.');
    $details = trim($details);
    if (mb_strlen($details) < 10 || mb_strlen($details) > 1500) throw new UserError('Tell us what is wrong (10 to 1500 characters).');
    if (return_for_item((int)$o['id'], $vid)) throw new UserError('A return was already requested for this vehicle.');
    q('INSERT INTO order_returns (order_id, vehicle_id, customer_id, reason, details) VALUES (?,?,?,?,?)', [$o['id'], $vid, $c['id'], $reason, $details]);
    $rid = (int)db()->lastInsertId();
    return_log((int)$o['id'], 'Return requested for ' . $item['stock_ref'] . ': ' . $reason, 'customer', (int)$c['id']);
    audit('customer', (int)$c['id'], 'return_requested', 'order', (int)$o['id'], $item['stock_ref'] . ' ' . $reason);
    return_customer_mail(['order_id' => $o['id']], 'We received your return request', 'We received your request to return ' . $item['title'] . ". A member of our team will review it and reply within one working day.\n");
    notify_staff('Return requested: ' . $o['reference'], 'Order ' . $o['reference'] . ' (' . $o['contact_name'] . ', ' . $o['contact_phone'] . ")\nVehicle: " . $item['title'] . "\nReason: $reason\n\n$details");
}

// ---------- Staff ----------
function decide_return(int $rid, string $decision, string $note, array $staff): void {
    if (!in_array($decision, ['Approved', 'Rejected'], true)) throw new UserError('Invalid decision.');
    $note = trim($note);
    if ($decision === 'Rejected' && mb_strlen($note) < 5) throw new UserError('Give the customer a reason for rejecting (at least 5 characters).');
    $pdo = db(); $pdo->beginTransaction();
    try {
        $r = q('SELECT * FROM order_returns WHERE id = ? FOR UPDATE', [$rid])->fetch();
        if (!$r || $r['status'] !== 'Requested') throw new UserError('This request has already been handled.');
        q('UPDATE order_returns SET status = ?, decision_note = ?, decided_by = ?, decided_at = NOW() WHERE id = ?', [$decision, $note ?: null, $staff['id'], $rid]);
        return_log((int)$r['order_id'], 'Return ' . strtolower($decision) . ($note ? ': ' . $note : ''), 'staff', (int)$staff['id']);
        audit('staff', (int)$staff['id'], 'return_' . strtolower($decision), 'order', (int)$r['order_id'], $note ?: null);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return_customer_mail($r, 'Your return request was ' . strtolower($decision),
        $decision === 'Approved'
            ? "Your return request was approved. Please bring the vehicle back to our showroom (or contact us to arrange collection)." . ($note ? "\n\nNote from our team: $note" : '') . "\n"
            : "We reviewed your return request and could not approve it.\n\nReason: $note\n\nIf you disagree, please contact us and we will look again.\n");
}
// The vehicle is physically back. It leaves "Sold" and goes to Draft so it is inspected before it can be listed again.
function receive_return(int $rid, array $staff): void {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $r = q('SELECT * FROM order_returns WHERE id = ? FOR UPDATE', [$rid])->fetch();
        if (!$r || $r['status'] !== 'Approved') throw new UserError('Only approved returns can be marked as received.');
        q("UPDATE order_returns SET status = 'Received', received_at = NOW() WHERE id = ?", [$rid]);
        q("UPDATE vehicles SET status = 'Draft' WHERE id = ? AND status = 'Sold'", [$r['vehicle_id']]);
        return_log((int)$r['order_id'], 'Vehicle returned and received. It is now off sale pending inspection.', 'staff', (int)$staff['id']);
        audit('staff', (int)$staff['id'], 'return_received', 'order', (int)$r['order_id'], null);
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
// Refund (may be 0, e.g. a repair or exchange), then close the case. The refund is spread over the order's verified payments.
function complete_return(int $rid, float $refund, string $note, array $staff): void {
    $note = trim($note);
    if (mb_strlen($note) < 5 || mb_strlen($note) > 255) throw new UserError('Write a short outcome note (5 to 255 characters).');
    $r = q('SELECT * FROM order_returns WHERE id = ?', [$rid])->fetch();
    if (!$r || $r['status'] !== 'Received') throw new UserError('Mark the vehicle as received before completing the return.');
    $item = q('SELECT price FROM order_items WHERE order_id = ? AND vehicle_id = ?', [$r['order_id'], $r['vehicle_id']])->fetch();
    $o = q('SELECT amount_paid FROM orders WHERE id = ?', [$r['order_id']])->fetch();
    if ($refund < 0 || $refund > (float)$item['price'] + 0.001) throw new UserError('The refund cannot be more than the vehicle price (' . money($item['price']) . ').');
    if ($refund > (float)$o['amount_paid'] + 0.001) throw new UserError('The refund is more than the customer has paid (' . money($o['amount_paid']) . ').');
    $left = $refund;
    if ($refund > 0) {
        $pays = q("SELECT p.id, p.amount - COALESCE((SELECT SUM(x.amount) FROM refunds x WHERE x.payment_id = p.id),0) AS refundable FROM payments p WHERE p.order_id = ? AND p.status = 'Verified' ORDER BY p.id DESC", [$r['order_id']])->fetchAll();
        if (array_sum(array_column($pays, 'refundable')) + 0.001 < $refund) throw new UserError('Not enough refundable payments on this order.');
        foreach ($pays as $p) {
            if ($left <= 0.001) break;
            $part = min($left, (float)$p['refundable']);
            if ($part > 0.001) { record_refund((int)$r['order_id'], (int)$p['id'], $part, 'Return: ' . $note, $staff, true); $left -= $part; }
        }
    }
    $pdo = db(); $pdo->beginTransaction();
    try {
        $r2 = q('SELECT status FROM order_returns WHERE id = ? FOR UPDATE', [$rid])->fetch();
        if (!$r2 || $r2['status'] !== 'Received') throw new UserError('This return was already completed.');
        q("UPDATE order_returns SET status = 'Completed', refund_amount = ?, outcome_note = ?, completed_at = NOW() WHERE id = ?", [$refund, $note, $rid]);
        return_log((int)$r['order_id'], 'Return completed. Refund ' . money($refund) . '. ' . $note, 'staff', (int)$staff['id']);
        audit('staff', (int)$staff['id'], 'return_completed', 'order', (int)$r['order_id'], money($refund));
        $pdo->commit();
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    return_customer_mail($r, 'Your return is complete', 'Your return is complete. ' . ($refund > 0 ? 'A refund of ' . money($refund) . " has been recorded.\n\n" : "No refund was due.\n\n") . "Outcome: $note\n");
}
