<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/ui.php';
require_once __DIR__ . '/charts.php';
require_once __DIR__ . '/images.php';
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store');

function current_staff(): ?array {
    static $s = false;
    if ($s === false) {
        $s = null;
        if (!empty($_SESSION['uid'])) {
            $s = q('SELECT u.id, u.full_name, u.email, u.role_id, r.code AS role, r.label AS role_label
                    FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ? AND u.is_active = 1', [$_SESSION['uid']])->fetch() ?: null;
            if ($s) $s['perms'] = q('SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?', [$s['role_id']])->fetchAll(PDO::FETCH_COLUMN);
            else unset($_SESSION['uid']);
        }
    }
    return $s;
}
function staff_can(string $perm): bool { $s = current_staff(); return $s && in_array($perm, $s['perms'], true); }
// Server-side authorisation: every admin page and action calls this.
function require_staff(string $perm): array {
    $s = current_staff();
    if (!$s) redirect('/admin/login.php');
    if (!in_array($perm, $s['perms'], true)) { http_response_code(403); admin_header('Not allowed'); echo '<div class="panel"><h1 class="h1s">Not allowed</h1><p>Your role does not include this function.</p></div>'; admin_footer(); exit; }
    return $s;
}
/** Staff area: dark sidebar + hazard-striped top bar. The logged-out login page keeps a plain bar. */
function admin_header(string $title): void {
    $s = current_staff();
    $biz = setting('business_name', 'Car Dealer');
    ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex"><title><?= e($title) ?> | Admin</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..125,400..800&display=swap">
<link rel="stylesheet" href="/assets/style.css"><link rel="stylesheet" href="/assets/dashboard.css"><script src="/assets/confirm.js" defer></script><script src="/assets/print.js" defer></script></head>
<?php if (!$s): ?><body>
<header class="top"><div class="wrap bar"><a class="brand" href="/admin/">Staff area</a></div></header>
<main class="wrap"><?= back_html() ?><?php foreach (flash() ?? [] as [$t, $m]) echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>'; return; endif;

    // [href, label, permission, icon, scripts that belong to this section]
    $nav = [
        ['/admin/',                 'Dashboard',  'dashboard.view',   'grid',   ['index.php']],
        ['/admin/vehicles.php',     'Inventory',  'inventory.manage', 'car',    ['vehicles.php', 'vehicle_edit.php']],
        ['/admin/categories.php',   'Categories', 'inventory.manage', 'tag',    ['categories.php']],
        ['/admin/orders.php',       'Orders',     'orders.view',      'cart',   ['orders.php', 'order.php', 'receipt.php']],
        ['/admin/returns.php',      'Returns',    'orders.view',      'clipboard', ['returns.php']],
        ['/admin/inquiries.php',    'Inquiries',  'inquiries.manage', 'chat',   ['inquiries.php']],
        ['/admin/customers.php',    'Customers',  'customers.view',   'users',  ['customers.php']],
        ['/admin/email.php',        'Email',      'customers.view',   'chat',   ['email.php']],
        ['/admin/offers.php',       'Offers',     'offers.manage',    'tag',    ['offers.php']],
        ['/admin/reviews.php',      'Reviews',    'reviews.manage',   'chat',   ['reviews.php']],
        ['/admin/reports.php',      'Reports',    'reports.view',     'chart',  ['reports.php']],
        ['/admin/staff.php',        'Staff',      'staff.manage',     'shield', ['staff.php']],
        ['/admin/settings.php',     'Settings',   'settings.manage',  'cog',    ['settings.php']],
        ['/admin/security.php',     'Security',   'dashboard.view',   'shield', ['security.php']],
        ['/admin/backup.php',       'Backup',     'backup.run',       'clipboard', ['backup.php']],
    ];
    $breakBefore = ['/admin/vehicles.php', '/admin/customers.php', '/admin/staff.php'];
    $badge = [];
    if (staff_can('orders.view')) $badge['/admin/orders.php'] = (int)q("SELECT COUNT(*) FROM orders WHERE status = 'Awaiting Confirmation'")->fetchColumn();
    if (staff_can('orders.view')) $badge['/admin/returns.php'] = (int)q("SELECT COUNT(*) FROM order_returns WHERE status = 'Requested'")->fetchColumn();
    if (staff_can('reviews.manage')) $badge['/admin/reviews.php'] = (int)q("SELECT COUNT(*) FROM reviews WHERE status = 'Pending'")->fetchColumn();
    if (staff_can('inquiries.manage')) $badge['/admin/inquiries.php'] = (int)q("SELECT COUNT(*) FROM inquiries WHERE status = 'New'")->fetchColumn();
    $script = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $searchTo = staff_can('orders.view') ? ['/admin/orders.php', 'Search orders by reference or customer'] : (staff_can('inventory.manage') ? ['/admin/vehicles.php', 'Search stock by make, model or stock no.'] : null);
    ?><body class="dash staff">
<header class="top"><div class="dbar">
  <a class="brand" href="/admin/"><?= e($biz) ?><span class="tag">Staff</span></a>
  <?php if ($searchTo): ?><form class="dsearch" action="<?= e($searchTo[0]) ?>" method="get" role="search"><?= icon('search', 18) ?>
    <input type="search" name="q" placeholder="<?= e($searchTo[1]) ?>" aria-label="Search"></form><?php endif; ?>
  <nav class="dnav" aria-label="Account">
    <a href="/">View site</a>
    <span class="duser"><span class="avatar sm"><?= e(initials($s['full_name'])) ?></span><span class="who"><strong><?= e($s['full_name']) ?></strong><small><?= e($s['role_label']) ?></small></span></span>
  </nav>
</div></header>
<div class="dshell">
<aside class="dside" aria-label="Staff menu">
<?php foreach ($nav as [$href, $label, $perm, $ic, $scripts]): if (!staff_can($perm)) continue;
      if (in_array($href, $breakBefore, true)) echo '<span class="sep"></span>'; ?>
  <a href="<?= e($href) ?>"<?= in_array($script, $scripts, true) ? ' aria-current="page"' : '' ?>><?= icon($ic) ?><span><?= e($label) ?></span><?= !empty($badge[$href]) ? '<b class="count">' . (int)$badge[$href] . '</b>' : '' ?></a>
<?php endforeach; ?>
  <span class="gap"></span><hr>
  <form method="post" action="/admin/logout.php"><?= csrf_field() ?><button type="submit" data-confirm="You will need to log in again to continue." data-confirm-title="Log out?" data-confirm-ok="Yes, log out"><?= icon('logout') ?><span>Log out</span></button></form>
</aside>
<main class="dmain"><?php foreach (flash() ?? [] as [$t, $m]) echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>';
}
function admin_footer(): void { echo current_staff() ? '</main></div></body></html>' : '</main></body></html>'; }

// ---------- Order workflow (all rules enforced here, never in the browser) ----------
const ORDER_FLOW = [
    'Awaiting Confirmation' => ['Awaiting Payment', 'Cancelled'],
    'Awaiting Payment'      => ['Cancelled'],            // moves to Payment Verified only when finance verifies money
    'Payment Verified'      => ['Order Processing'],
    'Order Processing'      => ['Ready for Handover'],
    'Ready for Handover'    => ['Completed'],
];
function order_transition(int $oid, string $to, ?string $note, array $staff): void {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $o = q('SELECT * FROM orders WHERE id = ? FOR UPDATE', [$oid])->fetch();
        if (!$o) throw new UserError('Order not found.');
        if (!in_array($to, ORDER_FLOW[$o['status']] ?? [], true)) throw new UserError("An order that is \"{$o['status']}\" cannot move to \"$to\".");
        if ($to === 'Cancelled') {
            if (!$note) throw new UserError('Enter a reason for cancelling.');
            if ((float)$o['amount_paid'] > 0) throw new UserError('This order has verified payments. Record a refund first.');
            q("UPDATE vehicles v JOIN order_items oi ON oi.vehicle_id = v.id SET v.status='Available' WHERE oi.order_id = ? AND v.status='Reserved'", [$oid]);
            q("UPDATE reservations SET status='Released' WHERE order_id = ? AND status='Active'", [$oid]);
            q('UPDATE orders SET cancel_reason = ? WHERE id = ?', [$note, $oid]);
        } elseif ($to === 'Awaiting Payment') {
            q("UPDATE reservations SET expires_at = DATE_ADD(NOW(), INTERVAL ? HOUR) WHERE order_id = ? AND status='Active'", [max(1, (int)setting('reservation_hours', '48')), $oid]);
        } elseif ($to === 'Completed') {
            if ($o['payment_status'] !== 'Paid') throw new UserError('Handover cannot be completed until the full amount is verified as paid.');
            q("UPDATE vehicles v JOIN order_items oi ON oi.vehicle_id = v.id SET v.status='Sold' WHERE oi.order_id = ?", [$oid]);
            q("UPDATE reservations SET status='Converted' WHERE order_id = ? AND status='Active'", [$oid]);
        }
        q('UPDATE orders SET status = ? WHERE id = ?', [$to, $oid]);
        q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?,?,?,?,'staff',?)", [$oid, $o['status'], $to, $note, $staff['id']]);
        audit('staff', (int)$staff['id'], 'order_status', 'order', $oid, $o['status'] . ' -> ' . $to);
        $pdo->commit();
        order_notify($o, $to, $note);
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
// Finance records money actually received. Converts the customer's Pending row, or adds a new verified row for balances.
function record_verified_payment(int $oid, float $amount, string $ref, array $staff): void {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $o = q('SELECT * FROM orders WHERE id = ? FOR UPDATE', [$oid])->fetch();
        if (!$o) throw new UserError('Order not found.');
        if (in_array($o['status'], ['Awaiting Confirmation', 'Cancelled', 'Completed'], true)) throw new UserError('Payments can be recorded only after the order is confirmed and before it is completed or cancelled.');
        $outstanding = (float)$o['total_amount'] - (float)$o['amount_paid'];
        if ($amount <= 0 || $amount > $outstanding + 0.001) throw new UserError('Amount must be above zero and not more than the outstanding ' . money($outstanding) . '.');
        if (strlen($ref) < 3 || strlen($ref) > 60) throw new UserError('Enter the bank, cash receipt or mobile money reference (3 to 60 characters).');
        $dup = q('SELECT 1 FROM payments WHERE provider_txn_id = ?', [$ref])->fetchColumn();
        if ($dup) throw new UserError('That reference has already been recorded.');
        $pend = q("SELECT id FROM payments WHERE order_id = ? AND status = 'Pending' ORDER BY id LIMIT 1 FOR UPDATE", [$oid])->fetchColumn();
        if ($pend) q("UPDATE payments SET status='Verified', amount=?, provider_txn_id=?, verified_by=?, verified_at=NOW() WHERE id = ?", [$amount, $ref, $staff['id'], $pend]);
        else q("INSERT INTO payments (order_id, method, reference, provider_txn_id, amount, status, verified_by, verified_at) VALUES (?,?,?,?,?, 'Verified', ?, NOW())",
               [$oid, $o['payment_method'], $o['reference'], $ref, $amount, $staff['id']]);
        $paid = order_net_paid($oid);
        $ps = $paid + 0.001 >= (float)$o['total_amount'] ? 'Paid' : 'Partially Paid';
        q('UPDATE orders SET amount_paid = ?, payment_status = ? WHERE id = ?', [$paid, $ps, $oid]);
        if ($o['status'] === 'Awaiting Payment' && $paid + 0.001 >= (float)$o['amount_due_now']) {
            q("UPDATE orders SET status='Payment Verified' WHERE id = ?", [$oid]);
            q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?,?,?,?,'staff',?)", [$oid, 'Awaiting Payment', 'Payment Verified', 'Payment verified by finance', $staff['id']]);
        }
        audit('staff', (int)$staff['id'], 'payment_verified', 'order', $oid, money($amount) . ' ref ' . $ref);
        $pdo->commit();
        queue_mail((string)$o['contact_email'], 'Payment received for order ' . $o['reference'], "Hello " . $o['contact_name'] . ",\n\nWe verified your payment of " . money($amount) . "." . mail_button('View my order', app_url('/order.php?ref=' . urlencode((string)$o['reference']))) . setting('business_name'));
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}

// Verified payments minus refunds. Single source of truth for orders.amount_paid.
function order_net_paid(int $oid): float {
    return (float)q("SELECT COALESCE((SELECT SUM(amount) FROM payments WHERE order_id = ? AND status = 'Verified'),0)
        - COALESCE((SELECT SUM(r.amount) FROM refunds r JOIN payments p ON p.id = r.payment_id WHERE p.order_id = ?),0)", [$oid, $oid])->fetchColumn();
}
function record_refund(int $oid, int $paymentId, float $amount, string $reason, array $staff, bool $allowCompleted = false): void {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $o = q('SELECT * FROM orders WHERE id = ? FOR UPDATE', [$oid])->fetch();
        if (!$o) throw new UserError('Order not found.');
        if ($o['status'] === 'Completed' && !$allowCompleted) throw new UserError('Refunds on completed sales go through the Returns page.');
        $p = q("SELECT amount FROM payments WHERE id = ? AND order_id = ? AND status = 'Verified' FOR UPDATE", [$paymentId, $oid])->fetch();
        if (!$p) throw new UserError('Choose a verified payment on this order.');
        $done = (float)q('SELECT COALESCE(SUM(amount),0) FROM refunds WHERE payment_id = ?', [$paymentId])->fetchColumn();
        $left = (float)$p['amount'] - $done;
        if ($amount <= 0 || $amount > $left + 0.001) throw new UserError('Refund must be above zero and at most ' . money($left) . '.');
        if (strlen($reason) < 5 || strlen($reason) > 255) throw new UserError('Enter a reason (5 to 255 characters).');
        q('INSERT INTO refunds (payment_id, amount, reason, approved_by) VALUES (?,?,?,?)', [$paymentId, $amount, $reason, $staff['id']]);
        $paid = order_net_paid($oid);
        $ps = $paid <= 0.001 ? 'Refunded' : ($paid + 0.001 >= (float)$o['total_amount'] ? 'Paid' : 'Partially Paid');
        q('UPDATE orders SET amount_paid = ?, payment_status = ? WHERE id = ?', [max(0, $paid), $ps, $oid]);
        q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type, actor_id) VALUES (?,?,?,?,'staff',?)",
          [$oid, $o['status'], $o['status'], 'Refund of ' . money($amount) . ': ' . $reason, $staff['id']]);
        audit('staff', (int)$staff['id'], 'refund_recorded', 'order', $oid, money($amount) . ' on payment ' . $paymentId);
        $pdo->commit();
        queue_mail((string)$o['contact_email'], 'Refund recorded for order ' . $o['reference'], 'Hello ' . $o['contact_name'] . ",\n\nA refund of " . money($amount) . ' has been recorded for your order. Contact us if it does not reach you within the time we agreed.');
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
