<?php
declare(strict_types=1);
// Email goes through an outbox table so a slow or failing mail server never blocks a customer's order.
function app_url(string $path = ''): string { return rtrim((string)env('APP_URL', 'http://localhost:8000'), '/') . $path; }

// ---------- Message building ----------
// A button is written in a message body as {{button Label|https://url}} (see mail_button()).
function mail_button(string $label, string $url): string { return "\n\n{{button " . str_replace(['|', '}'], ' ', $label) . '|' . $url . "}}\n\n"; }
function mail_plain(string $body): string { return preg_replace('/\{\{button (.+?)\|(https?:\/\/[^\s}]+)\}\}/', '$1: $2', $body); }
function mail_html(string $body, string $subject): string {
    $name = e(setting('business_name', 'Our dealership'));
    $text = e($body);
    $buttons = [];
    $text = preg_replace_callback('/\{\{button (.+?)\|(https?:\/\/[^\s}]+)\}\}/', function ($m) use (&$buttons) {
        $buttons[] = '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:18px 0"><tr><td style="background:#b45309;border-radius:6px">'
            . '<a href="' . $m[2] . '" style="display:inline-block;padding:13px 28px;color:#ffffff;font-size:16px;font-weight:bold;text-decoration:none">' . $m[1] . '</a></td></tr></table>';
        return "\x01" . (count($buttons) - 1) . "\x02";
    }, $text);
    $text = preg_replace('~(https?://[^\s<&]+(?:&amp;[^\s<&]+)*)~', '<a href="$1" style="color:#b45309">$1</a>', $text);
    $text = nl2br($text, false);
    $text = preg_replace_callback('/\x01(\d+)\x02/', fn($m) => $buttons[(int)$m[1]], $text);
    return '<!doctype html><html><body style="margin:0;background:#f4f3ef;font-family:Arial,Helvetica,sans-serif;color:#1c232b">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border-radius:8px;overflow:hidden">'
        . '<tr><td style="background:#10151b;color:#ffffff;padding:16px 24px;font-size:18px;font-weight:bold">' . $name . '</td></tr>'
        . '<tr><td style="padding:24px;font-size:15px;line-height:1.55">' . $text . '</td></tr>'
        . '<tr><td style="padding:14px 24px;background:#f4f3ef;color:#6b7280;font-size:12px">' . $name . ' · ' . e(setting('phone')) . ' · ' . e(setting('email')) . '</td></tr>'
        . '</table></td></tr></table></body></html>';
}
function mail_build(string $to, string $from, string $fromName, string $subject, string $text): array {
    $b = 'b' . bin2hex(random_bytes(8));
    $enc = fn(string $v) => '=?UTF-8?B?' . base64_encode($v) . '?=';
    $domain = substr(strrchr($from, '@') ?: '@localhost', 1);
    $headers = "Date: " . date('r') . "\r\nFrom: " . $enc($fromName) . " <$from>\r\nTo: <$to>\r\nSubject: " . $enc($subject)
        . "\r\nMessage-ID: <" . bin2hex(random_bytes(12)) . "@$domain>\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"$b\"";
    $body = "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode(mail_plain($text)))
          . "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode(mail_html($text, $subject)))
          . "--$b--\r\n";
    return [$headers, $body];
}

// ---------- SMTP (no Composer needed). Set MAIL_HOST in .env; otherwise PHP mail() is used. ----------
function smtp_read($fp): array {
    $text = ''; $code = 0;
    while (($line = fgets($fp, 515)) !== false) {
        $text .= $line; $code = (int)substr($line, 0, 3);
        if (strlen($line) < 4 || $line[3] === ' ') break;
    }
    return [$code, trim($text)];
}
function smtp_cmd($fp, string $cmd, array $ok): bool {
    if ($cmd !== '') fwrite($fp, $cmd . "\r\n");
    [$code, $text] = smtp_read($fp);
    if (!in_array($code, $ok, true)) { $GLOBALS['mail_last_error'] = trim(($cmd === '' ? 'connect' : strtok($cmd, ' ')) . ' -> ' . $text); return false; }
    return true;
}
function smtp_send(string $to, string $from, string $headers, string $body): bool {
    $host = (string)env('MAIL_HOST', ''); $port = (int)env('MAIL_PORT', '465'); $enc = strtolower((string)env('MAIL_ENCRYPTION', 'ssl'));
    // Same as the boutique: Gmail App passwords are shown with spaces ("abcd efgh ijkl mnop"); the spaces are not part of the password.
    $user = (string)env('MAIL_USERNAME', ''); $pass = str_replace(' ', '', (string)env('MAIL_PASSWORD', ''));
    $fp = @stream_socket_client(($enc === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 10);
    if (!$fp) { $GLOBALS['mail_last_error'] = "cannot connect to $host:$port ($es) - the host may block this port; use MAIL_PORT=465 and MAIL_ENCRYPTION=ssl"; return false; }
    stream_set_timeout($fp, 10);
    try {
        $helo = parse_url(app_url(), PHP_URL_HOST) ?: 'localhost';
        if (!smtp_cmd($fp, '', [220]) || !smtp_cmd($fp, "EHLO $helo", [250])) return false;
        if ($enc === 'tls') {
            if (!smtp_cmd($fp, 'STARTTLS', [220])) return false;
            $tlsOk = defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT') ? STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT : STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (!@stream_socket_enable_crypto($fp, true, $tlsOk)) { $GLOBALS['mail_last_error'] = 'STARTTLS failed'; return false; }
            if (!smtp_cmd($fp, "EHLO $helo", [250])) return false;
        }
        if ($user !== '') {
            if (!smtp_cmd($fp, 'AUTH LOGIN', [334]) || !smtp_cmd($fp, base64_encode($user), [334]) || !smtp_cmd($fp, base64_encode($pass), [235])) return false;
        }
        if (!smtp_cmd($fp, "MAIL FROM:<$from>", [250]) || !smtp_cmd($fp, "RCPT TO:<$to>", [250, 251]) || !smtp_cmd($fp, 'DATA', [354])) return false;
        $msg = preg_replace('/^\./m', '..', str_replace(["\r\n", "\r"], "\n", $headers . "\r\n\r\n" . $body));
        fwrite($fp, str_replace("\n", "\r\n", $msg) . "\r\n.\r\n");
        [$code, $text] = smtp_read($fp);
        if ($code !== 250) { $GLOBALS['mail_last_error'] = 'DATA -> ' . $text; return false; }
        smtp_cmd($fp, 'QUIT', [221]);
        return true;
    } finally { fclose($fp); }
}

function deliver_mail(string $to, string $subject, string $body): bool {
    $from = (string)env('MAIL_FROM', 'noreply@localhost');
    if (str_ends_with(strtolower((string)env('MAIL_HOST', '')), 'gmail.com') && (string)env('MAIL_USERNAME', '') !== '') {
        $from = (string)env('MAIL_USERNAME'); // Gmail rewrites any other From address anyway, and can flag it as spoofed
    }
    $subject = str_replace(["\r", "\n"], ' ', $subject); // block header injection
    if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) { $GLOBALS['mail_last_error'] = 'invalid address'; return false; }
    $fromName = str_replace(["\r", "\n"], ' ', (string)env('MAIL_FROM_NAME', setting('business_name', 'Sales')));
    [$headers, $msg] = mail_build($to, $from, $fromName, $subject, $body);
    try {
        $ok = false;
        if ((string)env('MAIL_HOST', '') !== '') {
            $ok = smtp_send($to, $from, $headers, $msg);
            if (!$ok) error_log('deliver_mail: SMTP failed (' . ($GLOBALS['mail_last_error'] ?? 'unknown') . '), trying PHP mail()');
        }
        if (!$ok) {
            $h = preg_replace('/^(To|Subject): .*\r\n/m', '', $headers . "\r\n"); // mail() adds To and Subject itself
            $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $msg, rtrim($h));
            if (!$ok) $GLOBALS['mail_last_error'] = ($GLOBALS['mail_last_error'] ?? '') . ($GLOBALS['mail_last_error'] ?? '' ? ' | ' : '') . 'PHP mail() failed';
        }
    } catch (Throwable $e) { $GLOBALS['mail_last_error'] = $e->getMessage(); $ok = false; }
    if (!$ok) error_log('deliver_mail to ' . $to . ': ' . ($GLOBALS['mail_last_error'] ?? 'unknown'));
    return $ok;
}
function queue_mail(string $to, string $subject, string $body, ?bool $sendNow = null): void {
    $sendNow ??= (string)env('MAIL_SEND_INLINE', '1') !== '0'; // send straight away; failures stay queued for the cron retry
    try {
        q('INSERT INTO outbox (to_email, subject, body) VALUES (?,?,?)', [$to, mb_substr($subject, 0, 200), $body]);
        $id = (int)db()->lastInsertId();
        if ($sendNow) {
            $ok = deliver_mail($to, $subject, $body);
            q('UPDATE outbox SET status = ?, attempts = attempts + 1, sent_at = IF(?, NOW(), NULL) WHERE id = ?', [$ok ? 'Sent' : 'Pending', $ok ? 1 : 0, $id]);
        }
    } catch (Throwable $e) { error_log('queue_mail: ' . $e->getMessage()); } // a mail problem must never break an order
}
// Alert the sales team (STAFF_NOTIFY_EMAIL, else the shop email in Admin > Settings).
function notify_staff(string $subject, string $body): void {
    $to = (string)env('STAFF_NOTIFY_EMAIL', '') ?: setting('email');
    if ($to !== '') queue_mail($to, '[Staff] ' . $subject, $body . mail_button('Open the admin', app_url('/admin/')));
}
function welcome_mail(string $name, string $email): void {
    queue_mail($email, 'Welcome to ' . setting('business_name', 'our dealership'),
        "Hello $name,\n\nYour account is ready. You can save vehicles, reserve one, and track your orders any time." . mail_button('Browse vehicles', app_url('/vehicles.php')) . setting('business_name'));
}
function order_notify(array $o, string $status, ?string $note = null): void {
    $msgs = [
      'Awaiting Confirmation' => 'We received your order and are checking the vehicle. Your car is reserved for you meanwhile.',
      'Awaiting Payment' => 'Your order is confirmed. Please pay using the method you chose. Payment instructions are on your order page.',
      'Payment Verified' => 'We have verified your payment. Thank you.',
      'Order Processing' => 'We are preparing your vehicle and paperwork.',
      'Ready for Handover' => 'Your vehicle is ready for handover. Please contact us to arrange it.',
      'Completed' => 'Your purchase is complete. Thank you for buying from us.',
      'Cancelled' => 'Your order was cancelled.' . ($note ? ' Reason: ' . $note : ''),
    ];
    if (!isset($msgs[$status])) return;
    queue_mail((string)$o['contact_email'], 'Order ' . $o['reference'] . ': ' . $status,
        "Hello " . $o['contact_name'] . ",\n\n" . $msgs[$status] . "" . mail_button('View my order', app_url('/order.php?ref=' . urlencode((string)$o['reference']))) . setting('business_name'));
}

// Marketing messages are sent only to customers who explicitly opted in.
function new_arrival_mail(string $name, string $email, array $vehicle): void {
    $title = trim((string)($vehicle['year'] ?? '') . ' ' . (string)($vehicle['make'] ?? '') . ' ' . (string)($vehicle['model'] ?? ''));
    queue_mail($email, 'New arrival: ' . $title,
        "Hello $name,\n\nA new vehicle has arrived at " . setting('business_name', 'our dealership') . ": $title."
        . (!empty($vehicle['price']) ? "\nPrice: " . money((float)$vehicle['price']) : '')
        . (!empty($vehicle['description']) ? "\n\n" . (string)$vehicle['description'] : '')
        . mail_button('View this vehicle', (int)($vehicle['id'] ?? 0) > 0 ? app_url('/vehicle.php?id=' . (int)$vehicle['id']) : app_url('/vehicles.php'))
        . "Reply to this email if you would like to arrange a viewing.");
}

function promotion_mail(string $email, string $name, string $subject, string $message): void {
    queue_mail($email, '[Promotion] ' . $subject,
        "Hello $name,\n\n$message" . mail_button('Browse current offers', app_url('/vehicles.php'))
        . setting('business_name', 'Our dealership'));
}

// ---------- Email verification ----------
function send_verification(int $cid, string $name, string $email): void {
    $token = bin2hex(random_bytes(32));
    q('UPDATE email_verifications SET used_at = NOW() WHERE customer_id = ? AND used_at IS NULL', [$cid]); // older links stop working
    q('INSERT INTO email_verifications (customer_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))', [$cid, hash('sha256', $token)]);
    queue_mail($email, 'Confirm your email for ' . setting('business_name', 'our dealership'),
        "Hello $name,\n\nWelcome! Please confirm your email address. The button works for 24 hours." . mail_button('Verify my email', app_url('/verify.php?token=' . $token))
        . "You need a verified email to place an order. If you did not create this account, ignore this message.\n\n" . setting('business_name'));
}
function require_verified_customer(array $c): void {
    if (empty($c['email_verified_at'])) { flash('Please verify your email before placing an order. We sent you a link.', 'warn'); redirect('/verify.php'); }
}
