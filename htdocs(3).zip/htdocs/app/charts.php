<?php
declare(strict_types=1);
// Server-rendered SVG charts. No JavaScript, no CDN: they work offline, print, and take their colours
// from CSS classes (see "Charts" in assets/dashboard.css), so dark mode follows automatically.
require_once __DIR__ . '/ui.php';

function chart_f(float $v): string { return number_format($v, 1, '.', ''); }

function nice_max(float $v): float {
    if ($v <= 0) return 1.0;
    $p = 10 ** floor(log10($v));
    foreach ([1, 1.5, 2, 2.5, 3, 4, 5, 10] as $m) if ($m * $p >= $v) return (float)($m * $p);
    return 10.0 * $p;
}

/**
 * Daily trend. $labels are 'Y-m-d'. $orders is a count per day. $revenue (optional) is UGX per day:
 * revenue is drawn as a line over a soft area, orders as bars along the bottom (own scale).
 * Without $revenue (roles that cannot see money) orders use the whole chart.
 */
function svg_trend(array $labels, array $orders, ?array $revenue = null): string {
    $n = count($labels);
    if ($n === 0) return '';
    $W = 640; $H = 250; $L = 54; $R = 12; $T = 12; $B = 28;
    $pw = $W - $L - $R; $ph = $H - $T - $B;
    $col = $pw / $n;
    $x = fn(int $i): float => $L + $col * ($i + 0.5);
    $oMax = max(1, (int)max($orders));
    if ($revenue !== null) { $steps = 5; $yMax = nice_max((float)max($revenue)); }
    else { $steps = 4; $yMax = max(4, (int)ceil($oMax / 4) * 4); }
    $y = fn(float $v): float => $T + $ph - ($v / $yMax) * $ph;
    $base = $T + $ph;

    $svg = '<svg class="chart" viewBox="0 0 ' . $W . ' ' . $H . '" role="img" aria-label="'
         . e($revenue !== null ? 'Daily revenue and orders' : 'Daily orders') . '">';
    for ($k = 0; $k <= $steps; $k++) {
        $gy = $T + $ph - $ph * $k / $steps;
        $val = $yMax * $k / $steps;
        $svg .= '<line class="gl" x1="' . $L . '" x2="' . ($W - $R) . '" y1="' . chart_f($gy) . '" y2="' . chart_f($gy) . '"/>'
              . '<text x="' . ($L - 8) . '" y="' . chart_f($gy + 4) . '" text-anchor="end">' . e($revenue !== null ? short_num($val) : (string)(int)$val) . '</text>';
    }
    $bw = min(16.0, $col * 0.55);
    for ($i = 0; $i < $n; $i++) {
        $o = (int)($orders[$i] ?? 0);
        $h = $revenue !== null ? ($o / $oMax) * $ph * 0.3 : ($o / $yMax) * $ph;
        if ($o > 0) $svg .= '<rect class="bar" x="' . chart_f($x($i) - $bw / 2) . '" y="' . chart_f($base - $h) . '" width="' . chart_f($bw) . '" height="' . chart_f($h) . '" rx="2"/>';
    }
    if ($revenue !== null) {
        $pts = [];
        for ($i = 0; $i < $n; $i++) $pts[] = chart_f($x($i)) . ',' . chart_f($y((float)($revenue[$i] ?? 0)));
        $svg .= '<path class="area" d="M' . implode(' L', $pts) . ' L' . chart_f($x($n - 1)) . ',' . chart_f($base) . ' L' . chart_f($x(0)) . ',' . chart_f($base) . ' Z"/>'
              . '<path class="line" d="M' . implode(' L', $pts) . '"/>';
        if ($n <= 14) for ($i = 0; $i < $n; $i++) $svg .= '<circle class="dot" cx="' . chart_f($x($i)) . '" cy="' . chart_f($y((float)($revenue[$i] ?? 0))) . '" r="3.5"/>';
    }
    $every = max(1, (int)ceil($n / 7));
    for ($i = 0; $i < $n; $i += $every) {
        $svg .= '<text x="' . chart_f($x($i)) . '" y="' . ($H - 8) . '" text-anchor="middle">' . e(date('j M', strtotime($labels[$i]))) . '</text>';
    }
    for ($i = 0; $i < $n; $i++) {   // invisible hit areas so each day has a native tooltip
        $tip = date('j M', strtotime($labels[$i])) . ': ' . (int)($orders[$i] ?? 0) . ' orders'
             . ($revenue !== null ? ', ' . money($revenue[$i] ?? 0) : '');
        $svg .= '<rect class="hit" x="' . chart_f($L + $col * $i) . '" y="' . $T . '" width="' . chart_f($col) . '" height="' . $ph . '"><title>' . e($tip) . '</title></rect>';
    }
    return $svg . '</svg>';
}

/** Donut of [['label'=>..., 'n'=>int], ...]; slot colours come from .c0 to .c5 in CSS. */
function svg_donut(array $items, string $centerTop, string $centerBottom): string {
    $total = (float)array_sum(array_column($items, 'n'));
    $svg = '<svg class="donut-svg" viewBox="0 0 42 42" role="img" aria-label="' . e($centerBottom) . ' by type">'
         . '<circle class="ring" cx="21" cy="21" r="15.9155"/>';
    $cum = 0.0;
    foreach (array_values($items) as $i => $it) {
        $p = $total > 0 ? $it['n'] / $total * 100 : 0;
        $len = max(0.0, $p - (count($items) > 1 ? 0.8 : 0.0));
        $svg .= '<circle class="seg c' . min($i, 5) . '" cx="21" cy="21" r="15.9155" stroke-dasharray="' . chart_f($len) . ' ' . chart_f(100 - $len)
              . '" stroke-dashoffset="' . chart_f(25 - $cum) . '"><title>' . e($it['label'] . ': ' . $it['n']) . '</title></circle>';
        $cum += $p;
    }
    return $svg . '<text class="dn" x="21" y="22" text-anchor="middle">' . e($centerTop) . '</text>'
         . '<text class="dl" x="21" y="27" text-anchor="middle">' . e($centerBottom) . '</text></svg>';
}
