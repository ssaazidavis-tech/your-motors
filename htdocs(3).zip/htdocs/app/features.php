<?php
declare(strict_types=1);
/**
 * app/features.php - features ported from the Mumie D Boutique site, rewritten for single-unit vehicle stock:
 * coupons, welcome offer, staff two-factor (TOTP), reviews, price/availability alerts, cart reminders.
 * Loaded from bootstrap.php. Needs database/008_boutique_features.sql.
 */

// =====================================================================
// Coupons (one code at a time, kept in the session, re-checked on every page and again inside the checkout transaction)
// =====================================================================
function coupon_find(string $code): ?array {
    $code = strtoupper(trim($code));
    if ($code === '' || strlen($code) > 40) return null;
    return q('SELECT * FROM coupons WHERE code = ?', [$code])->fetch() ?: null;
}
/** [ok, message]: is this coupon usable now for a cart of this subtotal? */
function coupon_check(?array $c, float $subtotal): array {
    if (!$c) return [false, 'We could not find that coupon code.'];
    if (!$c['is_active']) return [false, 'That coupon is no longer active.'];
    if ($c['expires_at'] !== null && $c['expires_at'] < date('Y-m-d')) return [false, 'That coupon has expired.'];
    if ($c['max_uses'] !== null && (int)$c['used_count'] >= (int)$c['max_uses']) return [false, 'That coupon has already been used up.'];
    if ($subtotal + 0.001 < (float)$c['min_subtotal']) return [false, 'Your cart must be at least ' . money($c['min_subtotal']) . ' to use this coupon.'];
    return [true, ''];
}
function coupon_discount(array $c, float $subtotal): float {
    $d = $c['type'] === 'percent' ? round($subtotal * (float)$c['value'] / 100) : (float)$c['value'];
    return max(0.0, min($d, $subtotal));
}
function coupon_apply(string $code, float $subtotal): array {
    $c = coupon_find($code);
    [$ok, $why] = coupon_check($c, $subtotal);
    if (!$ok) return [false, $why];
    $_SESSION['coupon_code'] = $c['code'];
    return [true, 'Coupon ' . $c['code'] . ' applied.'];
}
function coupon_remove(): void { unset($_SESSION['coupon_code']); }
/** The coupon in this session if it still works for this subtotal; otherwise it is dropped quietly. */
function coupon_applied(float $subtotal): ?array {
    $code = (string)($_SESSION['coupon_code'] ?? '');
    if ($code === '') return null;
    $c = coupon_find($code);
    [$ok] = coupon_check($c, $subtotal);
    if (!$ok) { coupon_remove(); return null; }
    return $c;
}
/** Atomically use one redemption. Call inside the checkout transaction: false means someone else used the last one. */
function coupon_consume(string $code): bool {
    return q('UPDATE coupons SET used_count = used_count + 1
              WHERE code = ? AND is_active = 1 AND (max_uses IS NULL OR used_count < max_uses) AND (expires_at IS NULL OR expires_at >= CURDATE())', [$code])->rowCount() === 1;
}

// =====================================================================
// Welcome offer: one single-use coupon per email address, ever
// =====================================================================
function welcome_enabled(): bool { return setting('welcome_enabled', '1') === '1'; }
function welcome_grant(string $email, string $source = 'signup'): ?array {
    $email = strtolower(trim($email));
    if (!welcome_enabled() || !filter_var($email, FILTER_VALIDATE_EMAIL)) return null;
    try {
        $pct = max(1, min(50, (int)setting('welcome_percent', '2')));
        $days = max(1, min(90, (int)setting('welcome_days', '14')));
        $ip = client_ip();
        if ((int)q('SELECT COUNT(*) FROM welcome_offers WHERE ip = ? AND created_at > NOW() - INTERVAL 1 DAY', [$ip])->fetchColumn() >= 3) return null;
        if (!q('INSERT IGNORE INTO welcome_offers (email, source, ip) VALUES (?,?,?)', [$email, $source, $ip])->rowCount()) return null; // already had one
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code = 'WELCOME-'; for ($i = 0; $i < 6; $i++) $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        $expires = date('Y-m-d', strtotime("+$days days"));
        q("INSERT INTO coupons (code, type, value, min_subtotal, max_uses, expires_at) VALUES (?, 'percent', ?, 0, 1, ?)", [$code, $pct, $expires]);
        q('UPDATE welcome_offers SET coupon_code = ? WHERE email = ?', [$code, $email]);
        queue_mail($email, 'Your welcome offer: ' . $pct . '% off your first car',
            "Welcome to " . setting('business_name', 'our showroom') . "!\n\nUse code $code at checkout for $pct% off. It works once and expires on " . date('j M Y', strtotime($expires)) . "." . mail_button('Browse cars', app_url('/vehicles.php')));
        return ['code' => $code, 'percent' => $pct, 'expires' => $expires];
    } catch (Throwable $e) { error_log('welcome_grant: ' . $e->getMessage()); return null; }
}

// =====================================================================
// Staff two-factor sign-in (authenticator app codes, RFC 6238) + one-time backup codes
// =====================================================================
function app_key(): string {
    static $k = null;
    if ($k !== null) return $k;
    $env = (string)env('APP_SECRET', '');
    if ($env !== '') return $k = hash('sha256', $env, true);
    $f = ROOT . '/app/app.key';   // app/.htaccess denies web access; keep a private copy: without it 2FA secrets cannot be read
    if (!is_file($f) && @file_put_contents($f, bin2hex(random_bytes(32))) === false) throw new RuntimeException('Cannot create app/app.key. Make app/ writable or set APP_SECRET in .env.');
    @chmod($f, 0600);
    return $k = hash('sha256', trim((string)file_get_contents($f)), true);
}
function secret_encrypt(string $plain): string {
    $iv = random_bytes(12); $tag = '';
    $ct = openssl_encrypt($plain, 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, $iv, $tag);
    return base64_encode($iv . $tag . $ct);
}
function secret_decrypt(string $blob): ?string {
    $raw = base64_decode($blob, true);
    if ($raw === false || strlen($raw) < 29) return null;
    $p = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $p === false ? null : $p;
}
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32_encode(string $bytes): string {
    $bits = ''; foreach (str_split($bytes) as $ch) $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
    $out = ''; foreach (str_split($bits, 5) as $chunk) $out .= B32[bindec(str_pad($chunk, 5, '0'))];
    return $out;
}
function b32_decode(string $text): string {
    $text = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $text) ?? '');
    $bits = ''; for ($i = 0, $n = strlen($text); $i < $n; $i++) $bits .= str_pad(decbin(strpos(B32, $text[$i])), 5, '0', STR_PAD_LEFT);
    $out = ''; foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $out .= chr(bindec($b));
    return $out;
}
function totp_new_secret(): string { return b32_encode(random_bytes(20)); }
function totp_code_at(string $key, int $step): string {
    $h = hash_hmac('sha1', pack('N2', 0, $step), $key, true);
    $o = ord($h[19]) & 0x0F;
    $v = ((ord($h[$o]) & 0x7F) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
    return str_pad((string)($v % 1000000), 6, '0', STR_PAD_LEFT);
}
/** Returns the matching 30-second step (store it as "last used"), or null. Steps <= $lastStep are refused so a code works once. */
function totp_verify(string $secret, string $code, int $lastStep = 0): ?int {
    $code = preg_replace('/\D+/', '', $code) ?? '';
    if (strlen($code) !== 6 || $secret === '') return null;
    $key = b32_decode($secret); $now = (int)floor(time() / 30); $hit = null;
    for ($i = -1; $i <= 1; $i++) { $s = $now + $i; if ($s > $lastStep && hash_equals(totp_code_at($key, $s), $code)) $hit = $s; }
    return $hit;
}
function totp_uri(string $secret, string $email): string {
    $issuer = setting('business_name', 'Car Dealer');
    return 'otpauth://totp/' . rawurlencode($issuer . ':' . $email) . '?secret=' . $secret . '&issuer=' . rawurlencode($issuer) . '&algorithm=SHA1&digits=6&period=30';
}
function backup_codes_create(int $uid): array {
    q('DELETE FROM staff_backup_codes WHERE user_id = ?', [$uid]);
    $codes = [];
    for ($i = 0; $i < 8; $i++) {
        $c = strtoupper(bin2hex(random_bytes(4))); $c = substr($c, 0, 4) . '-' . substr($c, 4);
        $codes[] = $c; q('INSERT INTO staff_backup_codes (user_id, code_hash) VALUES (?,?)', [$uid, hash('sha256', $c)]);
    }
    return $codes;
}
function backup_code_use(int $uid, string $code): bool {
    $code = strtoupper(trim($code));
    return q('UPDATE staff_backup_codes SET used_at = NOW() WHERE user_id = ? AND code_hash = ? AND used_at IS NULL', [$uid, hash('sha256', $code)])->rowCount() === 1;
}

// =====================================================================
// Reviews (one per completed order, shown after staff approve it)
// =====================================================================
function review_summary(): array {
    $r = q("SELECT COUNT(*) n, COALESCE(AVG(rating),0) avg FROM reviews WHERE status = 'Approved'")->fetch();
    return ['count' => (int)$r['n'], 'avg' => round((float)$r['avg'], 1)];
}
function stars(int $n): string { return str_repeat('★', $n) . str_repeat('☆', 5 - $n); }

// =====================================================================
// Alerts: "tell me if the price drops" / "tell me if it becomes available"
// =====================================================================
function alert_has(int $cid, int $vid, string $kind): bool {
    return (bool)q('SELECT 1 FROM vehicle_alerts WHERE customer_id = ? AND vehicle_id = ? AND kind = ? AND notified_at IS NULL', [$cid, $vid, $kind])->fetchColumn();
}
/** Emails every customer whose alert is now true. Run from bin/send_alerts.php every 10 minutes. Returns the number sent. */
function alerts_dispatch(): int {
    $n = 0;
    $rows = q("SELECT a.id, a.kind, a.price_at_signup, c.full_name, c.email, v.id vid, v.price, v.status, v.year, v.make, v.model, v.grade
               FROM vehicle_alerts a JOIN customers c ON c.id = a.customer_id AND c.is_active = 1 AND c.email_verified_at IS NOT NULL
               JOIN vehicles v ON v.id = a.vehicle_id WHERE a.notified_at IS NULL")->fetchAll();
    foreach ($rows as $r) {
        $title = vehicle_title($r); $url = app_url('/vehicle.php?id=' . (int)$r['vid']);
        if ($r['kind'] === 'price_drop' && (float)$r['price'] < (float)$r['price_at_signup'] && $r['status'] !== 'Sold') {
            queue_mail($r['email'], 'Price drop: ' . $title, 'Hello ' . $r['full_name'] . ",\n\nThe price of $title dropped from " . money($r['price_at_signup']) . ' to ' . money($r['price']) . '.' . mail_button('View the car', $url));
        } elseif ($r['kind'] === 'available' && $r['status'] === 'Available') {
            queue_mail($r['email'], 'Back in stock: ' . $title, 'Hello ' . $r['full_name'] . ",\n\n$title is available again. Cars sell fast, so reserve it soon." . mail_button('View the car', $url));
        } else continue;
        q('UPDATE vehicle_alerts SET notified_at = NOW() WHERE id = ?', [$r['id']]); $n++;
    }
    return $n;
}

// =====================================================================
// Scheduled jobs: used by bin/send_alerts.php (real cron) and public/cron.php (hosts without cron, e.g. InfinityFree)
// =====================================================================
function run_scheduled_jobs(): string {
    release_expired_reservations();
    $a = alerts_dispatch();
    $hours = max(1, (int)setting('cart_reminder_hours', '24'));
    $n = 0;
    $carts = q("SELECT ct.id, c.full_name, c.email FROM carts ct
                JOIN customers c ON c.id = ct.customer_id AND c.is_active = 1 AND c.email_verified_at IS NOT NULL
                LEFT JOIN cart_reminders r ON r.cart_id = ct.id
                WHERE r.cart_id IS NULL
                  AND EXISTS (SELECT 1 FROM cart_items ci JOIN vehicles v ON v.id = ci.vehicle_id
                              WHERE ci.cart_id = ct.id AND v.status = 'Available' AND ci.added_at < NOW() - INTERVAL $hours HOUR)")->fetchAll();
    foreach ($carts as $ct) {
        $cars = q("SELECT v.year, v.make, v.model, v.grade FROM cart_items ci JOIN vehicles v ON v.id = ci.vehicle_id WHERE ci.cart_id = ? AND v.status = 'Available'", [$ct['id']])->fetchAll();
        $list = implode("\n", array_map(fn($x) => '- ' . vehicle_title($x), $cars));
        queue_mail($ct['email'], 'Still thinking about these cars?', 'Hello ' . $ct['full_name'] . ",\n\nYou left these in your cart:\n$list\n\nA car is held for you only after you place an order, so someone else may buy it first." . mail_button('Back to my cart', app_url('/cart.php')));
        q('INSERT IGNORE INTO cart_reminders (cart_id) VALUES (?)', [$ct['id']]);
        $n++;
    }
    return "alerts sent: $a, cart reminders: $n";
}
