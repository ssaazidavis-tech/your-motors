<?php
declare(strict_types=1);
require_once __DIR__ . '/layout.php';
require_once __DIR__ . '/ui.php';

/** Signed-in customer area: topbar + sidebar. $active is the sidebar key of the current page. */
function dash_header(string $title, string $active = 'dashboard'): void {
    $c = current_customer();
    $cartCount = count(cart_ids());
    $cmp = count($_SESSION['compare'] ?? []);
    $biz = setting('business_name', 'Car Dealer');
    $wa = preg_replace('/\D+/', '', setting('whatsapp'));
    $nav = [
        ['dashboard', '/dashboard.php',              'Dashboard',    'grid',      0],
        ['account',   '/account.php',                'My profile',   'user',      0],
        ['orders',    '/orders.php',                 'My orders',    'clipboard', 0],
        ['wishlist',  '/wishlist.php',               'Wishlist',     'heart',     0],
        ['compare',   '/compare.php',                'Compare cars', 'columns',   $cmp],
        ['enquiries', '/requests.php',               'Enquiries',    'chat',      0],
        ['drives',    '/requests.php?type=drive',    'Test drives',  'calendar',  0],
    ];
    ?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title><?= e($title) ?> | <?= e($biz) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..125,400..800&display=swap">
<link rel="stylesheet" href="/assets/style.css">
<link rel="stylesheet" href="/assets/dashboard.css">
<script src="/assets/confirm.js" defer></script>
</head><body class="dash">
<header class="top"><div class="dbar">
  <a class="brand" href="/"><?= e($biz) ?></a>
  <form class="dsearch" action="/vehicles.php" method="get" role="search"><?= icon('search', 18) ?>
    <input type="search" name="q" placeholder="Search cars by make, model or stock no." aria-label="Search cars"></form>
  <nav class="dnav" aria-label="Shop">
    <a href="/vehicles.php">Browse cars</a>
    <a href="/cart.php" class="cartlink">Cart<?= $cartCount ? ' <b>' . $cartCount . '</b>' : '' ?></a>
    <?php if ($c): ?><a class="duser" href="/account.php"><span class="avatar sm"><?= e(initials($c['full_name'])) ?></span>
      <span class="who"><strong><?= e($c['full_name']) ?></strong><small>Customer</small></span></a><?php endif; ?>
  </nav>
</div></header>
<div class="dshell">
<aside class="dside" aria-label="My account">
<?php foreach ($nav as [$key, $href, $label, $ic, $count]): ?>
  <a href="<?= e($href) ?>"<?= $key === $active ? ' aria-current="page"' : '' ?>><?= icon($ic) ?><span><?= e($label) ?></span><?= $count ? '<b class="count">' . (int)$count . '</b>' : '' ?></a>
<?php endforeach; ?>
  <?php if ($wa): ?><a href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener"><?= icon('headset') ?><span>Message support</span></a><?php endif; ?>
  <span class="gap"></span><hr>
  <form method="post" action="/logout.php"><?= csrf_field() ?><button type="submit" data-confirm="You will need to log in again to see your orders." data-confirm-title="Log out?" data-confirm-ok="Yes, log out"><?= icon('logout') ?><span>Log out</span></button></form>
</aside>
<main class="dmain">
<?php foreach (flash() ?? [] as [$type, $msg]): ?>
  <div class="flash <?= e($type) ?>" role="status"><?= e($msg) ?></div>
<?php endforeach;
}

function dash_footer(): void { echo '</main></div></body></html>'; }
