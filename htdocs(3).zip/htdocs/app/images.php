<?php
declare(strict_types=1);

/** Re-encode an uploaded image as a JPEG (longest side $max px by default 1600, quality 82, upright, white background). Needs PHP's GD. */
function save_as_jpeg(string $tmp, string $mime, string $dest, int $max = 1600): bool {
    if (!function_exists('imagecreatetruecolor')) return false;
    $load = ['image/jpeg' => 'imagecreatefromjpeg', 'image/png' => 'imagecreatefrompng', 'image/webp' => 'imagecreatefromwebp'][$mime] ?? null;
    if (!$load || !function_exists($load)) return false;
    $src = @$load($tmp);
    if (!$src) return false;
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {          // phone photos: honour the rotation flag
        $o = (int)(@exif_read_data($tmp)['Orientation'] ?? 1);
        $rot = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
        if ($rot && ($r = imagerotate($src, $rot, 0))) { imagedestroy($src); $src = $r; }
    }
    $w = imagesx($src); $h = imagesy($src);
    $k = min(1.0, $max / max($w, $h));
    $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
    $dst = imagecreatetruecolor($nw, $nh);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imageinterlace($dst, true);
    $ok = imagejpeg($dst, $dest, 82);
    imagedestroy($src); imagedestroy($dst);
    return $ok;
}
