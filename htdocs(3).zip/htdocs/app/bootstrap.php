<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));

// ---------- Sub-folder support (e.g. XAMPP: http://localhost/car-etailer/public/) ----------
// Pages use root-style links like /vehicles.php. When the site is not at the web root,
// BASE_PATH is the folder prefix and every link in the HTML output is rewritten to include it.
(function (): void {
    $base = '';
    $pub = realpath(ROOT . '/public');
    $script = !empty($_SERVER['SCRIPT_FILENAME']) ? realpath($_SERVER['SCRIPT_FILENAME']) : false;
    if ($pub && $script && str_starts_with($script, $pub) && !empty($_SERVER['SCRIPT_NAME'])) {
        $rel = str_replace('\\', '/', substr($script, strlen($pub)));      // e.g. /admin/login.php
        $sn = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
        if ($rel !== '' && str_ends_with($sn, $rel)) $base = substr($sn, 0, strlen($sn) - strlen($rel));
    }
    define('BASE_PATH', rtrim($base, '/'));
})();
if (BASE_PATH !== '' && PHP_SAPI !== 'cli') {
    ob_start(function (string $html): string {
        foreach (headers_list() as $h) {
            if (stripos($h, 'content-type:') === 0 && stripos($h, 'text/html') === false) return $html; // leave CSV/JSON alone
        }
        return preg_replace_callback('~\b(href|src|action|data-thumb|poster)="/(?!/)~', fn($m) => $m[1] . '="' . BASE_PATH . '/', $html);
    });
}

/** Errors safe to show to the customer (unlike PDOException, which extends RuntimeException). */
class UserError extends RuntimeException {}

// ---------- Environment ----------
function load_env(string $file): void {
    if (!is_file($file)) return;
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $v = trim($v);
        if (strlen($v) >= 2 && ($v[0] === '"' || $v[0] === "'") && $v[-1] === $v[0]) $v = substr($v, 1, -1);
        $GLOBALS['__ENV'][trim($k)] = $v;   // putenv() is disabled on many shared hosts (e.g. InfinityFree)
    }
}
function env(string $k, ?string $default = null): ?string {
    if (isset($GLOBALS['__ENV'][$k])) return $GLOBALS['__ENV'][$k];
    $v = getenv($k);
    return $v === false ? $default : $v;
}
load_env(ROOT . '/.env');

date_default_timezone_set('Africa/Kampala');
error_reporting(E_ALL);
ini_set('display_errors', env('APP_DEBUG', '0') === '1' ? '1' : '0');
ini_set('log_errors', '1');

// ---------- Security headers and session ----------
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
$gaOn = (string)env('GA_MEASUREMENT_ID', '') !== '';
$csp = "default-src 'self'; img-src 'self' data:" . ($gaOn ? " https://*.google-analytics.com https://*.googletagmanager.com" : '')
     . "; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'" . ($gaOn ? " https://www.googletagmanager.com" : '')
     . ($gaOn ? "; connect-src 'self' https://*.google-analytics.com https://*.analytics.google.com https://*.googletagmanager.com" : '')
     . "; form-action 'self'; frame-ancestors 'none'";
header('Content-Security-Policy: ' . $csp);

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_name('CARSESS');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
session_start();

// ---------- Database ----------
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306'), env('DB_NAME', 'car_etailer'));
        $pdo = new PDO($dsn, env('DB_USER', 'root'), env('DB_PASS', ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
function q(string $sql, array $params = []): PDOStatement {
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

// ---------- Helpers ----------
function e(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function money($n): string { return 'UGX ' . number_format((float)$n, 0); }
function setting(string $key, string $default = ''): string {
    static $all = null;
    if ($all === null) $all = q('SELECT k, v FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR);
    return $all[$key] ?? $default;
}
function redirect(string $to): never {
    if (BASE_PATH !== '' && str_starts_with($to, '/') && !str_starts_with($to, '//') && !str_starts_with($to, BASE_PATH . '/') && $to !== BASE_PATH) $to = BASE_PATH . $to;
    header('Location: ' . $to); exit;
}
function safe_return(?string $p, string $fallback = '/'): string {
    return ($p && $p[0] === '/' && !str_starts_with($p, '//') && !str_contains($p, "\\")) ? $p : $fallback;
}
function flash(?string $msg = null, string $type = 'ok'): ?array {
    if ($msg !== null) { $_SESSION['flash'][] = [$type, $msg]; return null; }
    $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f;
}
// ---------- Google Analytics 4 events (rendered by page_footer, fired by assets/ga-init.js) ----------
function ga_enabled(): bool { return preg_match('/^G-[A-Z0-9]{6,}$/', (string)env('GA_MEASUREMENT_ID', '')) === 1; }
function ga_item(array $v): array {
    return ['item_id' => (string)($v['stock_ref'] ?? $v['id'] ?? ''), 'item_name' => vehicle_title($v), 'item_brand' => (string)($v['make'] ?? ''),
            'price' => (float)($v['price'] ?? 0), 'quantity' => 1];
}
function ga_queue(string $name, array $params): void {
    if (!ga_enabled()) return;
    $_SESSION['ga'][] = ['n' => $name, 'p' => $params + ['currency' => 'UGX']];
    $_SESSION['ga'] = array_slice($_SESSION['ga'], -10);
}
function ga_events_html(): string {
    $ev = $_SESSION['ga'] ?? []; unset($_SESSION['ga']);
    if (!$ev || !ga_enabled()) return '';
    return '<div id="ga-events" hidden data-events="' . e(json_encode($ev, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . '"></div>';
}
function client_ip(): string { return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45); }

function audit(string $actorType, ?int $actorId, string $action, string $entity, ?int $entityId, ?string $detail = null): void {
    q('INSERT INTO audit_log (actor_type, actor_id, action, entity, entity_id, detail, ip) VALUES (?,?,?,?,?,?,?)',
      [$actorType, $actorId, $action, $entity, $entityId, $detail, client_ip()]);
}

// ---------- CSRF ----------
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function require_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed'); }
    // PHP drops $_POST and $_FILES completely when a request is bigger than post_max_size, which would
    // otherwise look like an expired session. Say what really happened.
    if (!$_POST && !$_FILES && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        http_response_code(413);
        exit('The upload was too big for the server (limit ' . ini_get('post_max_size') . ' per request, ' . ini_get('upload_max_filesize') . ' per file). Choose fewer or smaller photos, or raise post_max_size and upload_max_filesize in php.ini.');
    }
    $t = $_POST['_csrf'] ?? '';
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) { http_response_code(419); exit('Session expired. Go back, refresh the page and try again.'); }
}

// ---------- Rate limiting ----------
function rate_limited(string $key, int $max, int $seconds): bool {
    $key = substr($key, 0, 120);
    $s = q('SELECT hits, TIMESTAMPDIFF(SECOND, window_start, NOW()) AS age FROM rate_limits WHERE k = ?', [$key])->fetch();
    if (!$s || (int)$s['age'] >= $seconds) {
        q('REPLACE INTO rate_limits (k, hits, window_start) VALUES (?, 1, NOW())', [$key]);
        return false;
    }
    q('UPDATE rate_limits SET hits = hits + 1 WHERE k = ?', [$key]);
    return ((int)$s['hits'] + 1) > $max;
}

// ---------- Customer auth ----------
function current_customer(): ?array {
    static $c = false;
    if ($c === false) {
        $c = null;
        if (!empty($_SESSION['cid'])) {
            $c = q('SELECT id, full_name, email, phone, email_verified_at FROM customers WHERE id = ? AND is_active = 1', [$_SESSION['cid']])->fetch() ?: null;
            if (!$c) unset($_SESSION['cid']);
        }
    }
    return $c;
}
function require_customer(): array {
    $c = current_customer();
    if (!$c) { flash('Log in to continue.', 'warn'); redirect('/login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? '/')); }
    return $c;
}
function customer_login(int $id): void {
    $guest = $_SESSION['cart'] ?? [];
    $compare = $_SESSION['compare'] ?? [];
    session_regenerate_id(true);
    $_SESSION['cid'] = $id;
    $_SESSION['cart'] = $guest;
    $_SESSION['compare'] = $compare;
    foreach ($guest as $vid) { try { cart_add((int)$vid, $id); } catch (Throwable $e) {} }
    $_SESSION['cart'] = [];
}

// ---------- Reservations ----------
// Releases vehicles whose reservation window has passed without a verified payment.
function release_expired_reservations(): int {
    $pdo = db();
    $n = 0;
    $rows = q("SELECT r.id, r.vehicle_id, r.order_id FROM reservations r
               JOIN orders o ON o.id = r.order_id
               WHERE r.status = 'Active' AND r.expires_at < NOW() AND o.payment_status NOT IN ('Paid','Partially Paid')")->fetchAll();
    foreach ($rows as $r) {
        $pdo->beginTransaction();
        try {
            q("UPDATE reservations SET status='Released' WHERE id = ? AND status='Active'", [$r['id']]);
            q("UPDATE vehicles SET status='Available' WHERE id = ? AND status='Reserved'", [$r['vehicle_id']]);
            $o = q('SELECT status FROM orders WHERE id = ? FOR UPDATE', [$r['order_id']])->fetch();
            if ($o && $o['status'] !== 'Cancelled' && $o['status'] !== 'Completed') {
                $left = q("SELECT COUNT(*) FROM reservations WHERE order_id = ? AND status='Active'", [$r['order_id']])->fetchColumn();
                if ((int)$left === 0) {
                    q("UPDATE orders SET status='Cancelled', cancel_reason='Reservation expired' WHERE id = ?", [$r['order_id']]);
                    q("INSERT INTO order_status_history (order_id, from_status, to_status, note, actor_type) VALUES (?,?,?,?,'system')",
                      [$r['order_id'], $o['status'], 'Cancelled', 'Reservation expired']);
                }
            }
            audit('system', null, 'reservation_expired', 'vehicle', (int)$r['vehicle_id'], 'order ' . $r['order_id']);
            $pdo->commit();
            $n++;
        } catch (Throwable $e) { $pdo->rollBack(); error_log('release_expired: ' . $e->getMessage()); }
    }
    return $n;
}

// ---------- Cart (session for guests, database for customers) ----------
function cart_ids(): array {
    if ($c = current_customer()) {
        return array_map('intval', q('SELECT ci.vehicle_id FROM cart_items ci JOIN carts c ON c.id = ci.cart_id
                                      WHERE c.customer_id = ? ORDER BY ci.added_at', [$c['id']])->fetchAll(PDO::FETCH_COLUMN));
    }
    return array_values(array_unique(array_map('intval', $_SESSION['cart'] ?? [])));
}
function cart_db_id(int $customerId): int {
    q('INSERT IGNORE INTO carts (customer_id) VALUES (?)', [$customerId]);
    return (int)q('SELECT id FROM carts WHERE customer_id = ?', [$customerId])->fetchColumn();
}
function cart_add(int $vid, ?int $customerId = null): void {
    $customerId ??= current_customer()['id'] ?? null;
    $v = q('SELECT status, price_on_request FROM vehicles WHERE id = ?', [$vid])->fetch();
    if (!$v || $v['status'] !== 'Available') throw new UserError('This vehicle is no longer available.');
    if ($v['price_on_request']) throw new UserError('This vehicle is price on request. Send an inquiry instead.');
    $limit = (int)setting('cart_limit', '3');
    if ($customerId) {
        $cid = cart_db_id($customerId);
        $count = (int)q('SELECT COUNT(*) FROM cart_items WHERE cart_id = ?', [$cid])->fetchColumn();
        $has = q('SELECT 1 FROM cart_items WHERE cart_id = ? AND vehicle_id = ?', [$cid, $vid])->fetchColumn();
        if (!$has && $count >= $limit) throw new UserError("Your cart can hold up to $limit vehicles.");
        q('INSERT IGNORE INTO cart_items (cart_id, vehicle_id) VALUES (?, ?)', [$cid, $vid]);
    } else {
        $cart = $_SESSION['cart'] ?? [];
        if (!in_array($vid, $cart, true)) {
            if (count($cart) >= $limit) throw new UserError("Your cart can hold up to $limit vehicles.");
            $cart[] = $vid;
        }
        $_SESSION['cart'] = $cart;
    }
}
function cart_remove(int $vid): void {
    if ($c = current_customer()) {
        q('DELETE ci FROM cart_items ci JOIN carts c ON c.id = ci.cart_id WHERE c.customer_id = ? AND ci.vehicle_id = ?', [$c['id'], $vid]);
    } else {
        $_SESSION['cart'] = array_values(array_diff($_SESSION['cart'] ?? [], [$vid]));
    }
}
function cart_vehicles(): array {
    $ids = cart_ids();
    if (!$ids) return [];
    $in = implode(',', array_fill(0, count($ids), '?'));
    return q(VEHICLE_SELECT . " WHERE v.id IN ($in)", $ids)->fetchAll();
}

// ---------- Vehicle helpers ----------
const VEHICLE_SELECT = "SELECT v.*, c.name AS category_name,
    (SELECT path FROM vehicle_images i WHERE i.vehicle_id = v.id ORDER BY i.is_primary DESC, i.sort_order, i.id LIMIT 1) AS img
    FROM vehicles v JOIN categories c ON c.id = v.category_id";

function vehicle_title(array $v): string {
    return trim($v['year'] . ' ' . $v['make'] . ' ' . $v['model'] . ($v['grade'] ? ' ' . $v['grade'] : ''));
}
function discount_pct(array $v): int {
    if (!empty($v['original_price']) && (float)$v['original_price'] > (float)$v['price'] && (float)$v['price'] > 0)
        return (int)round((1 - $v['price'] / $v['original_price']) * 100);
    return 0;
}

require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/returns.php';
require_once __DIR__ . '/features.php';

// ---------- "Back" link shown at the top of a page ----------
// back_to('/cart.php', 'Back to cart')  or  back_to('/vehicles.php', 'Back to cars', true) to return to the page the visitor came from
// (their filtered search results, wishlist, ...) when that page is one of ours.
function back_to(string $href, string $label, bool $useReferrer = false): void {
    if ($useReferrer && !empty($_SERVER['HTTP_REFERER'])) {
        $r = parse_url((string)$_SERVER['HTTP_REFERER']);
        $known = ['/vehicles.php' => 'Back to cars', '/' => 'Back to home', '/index.php' => 'Back to home', '/wishlist.php' => 'Back to wishlist', '/compare.php' => 'Back to compare'];
        $path = $r['path'] ?? '';
        if (($r['host'] ?? '') === ($_SERVER['HTTP_HOST'] ?? '') && isset($known[$path]) && $path !== parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH)) {
            $href = $path . (isset($r['query']) ? '?' . $r['query'] : ''); $label = $known[$path];
        }
    }
    $GLOBALS['back_link'] = [$href, $label];
}
function back_html(): string {
    if (empty($GLOBALS['back_link'])) return '';
    [$href, $label] = $GLOBALS['back_link'];
    return '<p class="backlink"><a href="' . e($href) . '">&larr; ' . e($label) . '</a></p>';
}
