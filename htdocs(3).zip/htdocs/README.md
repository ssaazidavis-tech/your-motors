# Car E-Tailer (Stages 1-2: storefront, checkout, staff admin)

PHP 8.1+ and MySQL 8 / MariaDB 10.4+. No framework or Composer packages.

## Install
1. `cp .env.example .env` and set the DB values.
2. `mysql -u root -p < database/schema.sql && mysql -u root -p < database/seed.sql && mysql -u root -p < database/seed_permissions.sql`
   Then run `database/002_stage4.sql`, `database/003_stage5.sql` (test-mode payment methods), `database/004_support.sql` (support replies), `database/005_verification.sql` (email verification), `database/006_returns.sql` (returns after handover), and `database/007_marketing.sql` the same way. Copy `.env.example` to `.env` and fill in your database login and, once your Google Analytics 4 property exists, `GA_MEASUREMENT_ID`.
   Then create the first staff account: `php bin/create_staff.php "Your Name" you@example.com admin` and log in at `/admin/login.php`.
3. Create a DB user for the app with rights on `car_etailer` only.
4. `php -S localhost:8000 -t public` (development), or point your web server's document root at `public/`.
5. Edit business details in the `settings` table (name, phone, WhatsApp, bank details) until the admin screen exists.
6. Cron: `*/10 * * * * php /path/to/bin/release_expired.php` and `* * * * * php /path/to/bin/send_outbox.php`
7. Set `APP_URL` (used in email links) and `MAIL_FROM` in `.env`. Email uses PHP `mail()`; on hosts without a mail server use your provider's SMTP relay or swap `deliver_mail()` in `app/mail.php`.

### Gmail SMTP
For Gmail delivery, enable 2-Step Verification on the Google account, create a Google App Password, and configure:
```
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_ENCRYPTION=tls
MAIL_USERNAME=your-address@gmail.com
MAIL_PASSWORD=your-16-character-app-password
MAIL_FROM=your-address@gmail.com
```
Run `php bin/test_mail.php your-address@example.com` to verify delivery. Gmail places verified opt-in campaigns in categories based on its own inbox rules; the system labels promotion messages and limits them to verified customers who selected marketing emails during registration.

The 12 seeded vehicles are **sample data** with no photos. Delete them before going live.

## Built in Stage 1
Home, catalogue (search, 12 filters, sorting, pagination, cascading make/model), vehicle detail with inquiry and test-drive form,
wishlist, compare (up to 4), cart (guest and logged-in, merged at login), registration and login with rate limiting,
checkout with a row-locked transaction, 48h reservation, order tracking, bank-transfer and cash payment records,
audit log entries, CSRF on every POST, prepared statements everywhere, bcrypt/argon password hashing.

## Not built yet (later stages)
Staff login, role permissions, admin dashboard, inventory CRUD and image upload, order and payment management screens,
payment verification, receipts, reports and CSV export, password reset, profile page, email/SMS notifications,
mobile money and card integration (hidden at checkout until a real provider is integrated).
Until the admin stage exists, staff must update orders and payments directly in the database.

## Manual test procedure
1. Register, log in, log out, wrong password 7 times (expect lockout message).
2. Filter the catalogue; check pagination and make -> model dropdown.
3. Add a car to the cart as a guest, log in, confirm it is still there.
4. Place an order; confirm vehicle shows Reserved, order appears under My orders, payment row is Pending.
5. Open the same car in two browsers, both check out: exactly one succeeds.
6. `UPDATE reservations SET expires_at = NOW() - INTERVAL 1 MINUTE WHERE order_id = X;` then reload: car is Available, order Cancelled.
7. Open another customer's `/order.php?ref=...`: expect "Order not found".
8. POST to any form without the `_csrf` field: expect HTTP 419.

## Stage 2 (staff area, /admin/)
Staff login (separate from customers, rate limited), role permissions enforced on the server for every page and action,
dashboard, inventory add/edit with validated photo upload (real image check, random file names, 10 photos max),
order list with filters, order detail with a server-enforced status flow, cancellation that releases the vehicle,
payment verification (finance only) with duplicate-reference and over-payment checks, printable receipts, inquiry inbox.
Roles: admin (all), inventory, sales, finance. Vehicles that are Reserved or Sold cannot be edited to another status by hand.
Photos are resized (max 1600 px on the longest side), compressed and always saved as JPG by `app/images.php` (needs the PHP `gd` extension; tune `IMG_MAX_SIDE` and `IMG_JPEG_QUALITY` there). Metadata such as GPS is stripped.
Uploads: `public/uploads/.htaccess` blocks script execution on Apache. On Nginx, deny PHP in `/uploads/` yourself.

### Stage 2 tests
9. Log in as `inventory`: Orders link is absent and `/admin/orders.php` returns 403. Repeat for `finance` on `/admin/vehicle_edit.php`.
10. Upload a `.php` file renamed `.jpg`: rejected. Upload a 6 MB image: rejected.
11. Place an order, confirm it (Awaiting Payment), verify part of the amount: payment status Partially Paid; verify the rest: Paid.
12. Try Completed before Paid, and Cancelled after a verified payment: both refused with a message.
13. Reuse the same payment reference twice: refused.
14. Cancel an order: vehicle returns to Available and reappears in the catalogue.

## Stage 3 (reports and admin tools)
Reports (inventory, reserved/sold, orders by date and status, completed sales, verified revenue, outstanding balances, payment methods,
popular categories, inquiries) with date filters and CSV download (formula-injection safe, Excel-friendly UTF-8). Customer list,
category management, business settings (including bank details and enabling bank/cash methods), staff accounts (add, deactivate,
reset password, always keeps one active admin).

### Stage 3 tests
15. As finance: Reports works, Settings and Staff return 403. As sales: Customers works, Reports returns 403.
16. Verify a payment, then open Reports > Revenue for today: the amount appears and the total row matches. Download the CSV and open it in Excel.
17. Register a customer named `=1+1`, place an order, export Orders: the name appears as text with a leading apostrophe.
18. Deactivate the only admin: refused. Deactivate yourself: refused.
19. Settings: set deposit percent to 0, reload checkout: the deposit option disappears.

## Stage 4 (refunds, email, accounts)
Refunds (finance/admin) against verified payments with over-refund protection; net revenue on the dashboard and a Refunds report.
Email outbox with retry (order placed, status changes, payment received, password reset). Password reset by one-hour, single-use,
hashed token with the same reply whether or not the email exists. Customer account page (profile, change password).

### Stage 4 tests
20. Verify a payment, refund part of it: order shows Partially Paid and outstanding rises; refund more than remains: refused.
21. Refund everything: payment status Refunded, then cancelling the order works and the car returns to Available.
22. Forgot password: link works once, not twice, not after 1 hour; unknown emails get the same message.
23. `SELECT * FROM outbox;` shows queued emails; with working `mail()` they flip to Sent.

## Deployment and smoke test
See `docs/DEPLOYMENT.md` (server settings, Nginx sketch, cron, backups, go-live checklist). After setup run `sh tests/smoke.sh http://localhost:8000`.

## Still to build
Mobile money and card payments (needs a chosen provider with signed webhooks), SMS notifications, automated unit tests.

## Troubleshooting: page looks unstyled or links break
- The site now works from a sub-folder (for example `http://localhost/car-etailer/public/` under XAMPP or WAMP): links, redirects, the stylesheet and the make/model dropdown all pick up the folder prefix automatically. Set `APP_URL` in `.env` to the same address so emailed links are correct.
- Quick check: open `<your-site>/assets/style.css` in the browser. If you see CSS text, the stylesheet is reachable. If you get "not found", the server is not pointed at the `public` folder.
- If a blank page appears, set `APP_DEBUG=1` in `.env` temporarily and reload to see the PHP error. PHP must be 8.1 or newer.
- Best practice for a real server is still to set the document root to `public/`.
