#!/bin/sh
# HTTP smoke test. Usage: sh tests/smoke.sh http://localhost:8000
# Checks status codes only. It does not replace the manual tests in README.md.
B="${1:-http://localhost:8000}"; fail=0
check() { code=$(curl -s -o /dev/null -w '%{http_code}' $3 "$B$2"); if [ "$code" = "$1" ]; then echo "ok   $1 $2"; else echo "FAIL want $1 got $code $2"; fail=1; fi; }
check 200 /
check 200 /vehicles.php
check 200 '/vehicles.php?make=Toyota&sort=price_asc'
check 200 /login.php
check 200 /register.php
check 200 /forgot.php
check 200 /cart.php
check 404 '/vehicle.php?id=99999999'
check 302 /checkout.php          # needs login
check 302 /orders.php
check 302 /admin/                # needs staff login
check 200 /admin/login.php
check 405 /logout.php            # POST only
check 419 /cart.php "-X POST -d id=1&do=add"   # no CSRF token
check 403 /uploads/x.php
[ $fail = 0 ] && echo "All smoke checks passed" || { echo "Some checks failed"; exit 1; }
