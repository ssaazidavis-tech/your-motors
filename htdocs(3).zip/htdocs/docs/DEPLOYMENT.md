# Deployment checklist

Nothing here has been run against a live server by the author. Treat it as a checklist to verify, not a guarantee.

## Server
- PHP 8.1+ with `pdo_mysql`, `fileinfo`, `mbstring`. MySQL 8 or MariaDB 10.4+.
- Document root must be `public/` only. `app/`, `database/`, `bin/`, `.env` must NOT be web-reachable.
- Serve over HTTPS only (free certificate from Let's Encrypt). Redirect HTTP to HTTPS. Set `APP_URL=https://yourdomain`.
- `.env`: `APP_DEBUG=0`, a strong `DB_PASS`, a real `MAIL_FROM` on your own domain. `chmod 600 .env`.
- Database user: privileges `SELECT, INSERT, UPDATE, DELETE` on `car_etailer.*` only. Not root.
- PHP: `expose_php=Off`, `display_errors=Off`, `session.cookie_secure=1`, `upload_max_filesize=6M`, `post_max_size=40M` (10 photos).

## Nginx sketch
```
server {
  server_name yourdomain; root /var/www/car-etailer/public; index index.php;
  location / { try_files $uri $uri/ =404; }
  location ~ ^/uploads/.*\.(php|phtml|phar)$ { return 403; }   # uploads can never execute
  location ~ \.php$ { include fastcgi_params; fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name; fastcgi_pass unix:/run/php/php-fpm.sock; }
  location ~ /\. { deny all; }
  add_header Strict-Transport-Security "max-age=31536000" always;
  client_max_body_size 40M;
}
```
Apache: the `public/uploads/.htaccess` already blocks script execution; enable `AllowOverride All` for that folder.

## Cron
```
*/10 * * * * php /var/www/car-etailer/bin/release_expired.php   # frees unpaid reservations
* * * * *    php /var/www/car-etailer/bin/send_outbox.php       # sends queued emails
15 2 * * *   mysqldump --single-transaction car_etailer | gzip > /backups/car_etailer_$(date +\%F).sql.gz
```
Copy backups off the server and test a restore. Back up `public/uploads/` too.
Delivery tries the configured SMTP server first, then falls back to PHP `mail()` if SMTP fails. The fallback depends on the web host's local mail setup; a successful `mail()` result means the host accepted the message, not that it reached the inbox. Run `php bin/test_mail.php you@example.com` on the deployed host and check its PHP error log for the exact SMTP or fallback error. Some shared hosts block outbound SMTP and disable `mail()`; in that case, use a mail provider and a transport the host permits.

## Before going live
1. Delete the 12 sample vehicles. Add real stock and photos.
2. Set business name, phone, WhatsApp, bank details in Admin > Settings.
3. Create real staff accounts; remove or change any test accounts.
4. Run every test in README.md (1 to 23) on the live server, including two browsers racing for one car.
5. Place a real small order end to end, verify the payment, refund it, and read the audit trail.
6. Write your terms of sale, refund and privacy policies and link them in the checkout. Check Uganda's Data Protection and Privacy Act requirements for the personal data you hold.

## Not built
Mobile money and card payments (need a chosen provider, credentials, signed webhooks and sandbox testing), SMS, automated unit tests.

## Email
Set `MAIL_HOST`, `MAIL_PORT`, `MAIL_ENCRYPTION`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM` and `STAFF_NOTIFY_EMAIL` in `.env`, then test with:

    php bin/test_mail.php you@example.com

Customers get: welcome, order confirmation and every status change, payment receipt, refund notice, password reset, and replies to their questions. Staff get an alert for each new order, vehicle inquiry or support message. Emails are HTML with a plain-text fallback. Keep the `send_outbox.php` cron job: it retries anything that failed to send.

## Accounts: verification and password reset
Run `database/005_verification.sql`. New customers must click the emailed link before placing an order (browsing and wishlists work without it). Existing customers are treated as verified. Password reset links last 1 hour, work once, and also verify the email. A security email is sent whenever a password changes.

## Returns
Run `database/006_returns.sql`. Customers can request a return from a completed order within the number of days set in Admin > Settings (default 7; 0 turns returns off). Staff handle it in Admin > Returns: approve or reject, mark the vehicle received (it becomes a Draft for inspection), then record the refund and close the case. Refunds on completed sales can only be recorded through this page.
