USE car_etailer;

INSERT INTO roles (code,label) VALUES
('admin','Administrator'),('inventory','Inventory Manager'),('sales','Sales and Order Manager'),('finance','Finance Officer');

INSERT INTO categories (name,slug,sort_order) VALUES
('Sedans','sedans',1),('Hatchbacks','hatchbacks',2),('SUVs','suvs',3),('4x4 Vehicles','4x4',4),
('Mini-vans','mini-vans',5),('7-Seaters','7-seaters',6),('Luxury','luxury',7),('Pickups','pickups',8),
('Commercial','commercial',9),('Taxis','taxis',10),('Buses','buses',11),('Trucks','trucks',12);

-- Online methods stay disabled until a real provider is configured and integrated.
INSERT INTO payment_methods (code,label,instructions,requires_provider,enabled,sort_order) VALUES
('bank_transfer','Bank transfer','Pay into the business account and quote your order reference. Staff verify the deposit against the bank statement before your payment is marked as verified.',0,1,1),
('cash','Cash at the showroom','Pay at the showroom. Your vehicle stays reserved until finance staff record the receipt.',0,1,2),
('mobile_money','MTN / Airtel Mobile Money','Requires a configured payment provider.',1,0,3),
('card','Debit / credit card','Requires a configured payment provider.',1,0,4);

INSERT INTO settings (k,v) VALUES
('business_name','Your Motors'),
('whatsapp','256700000000'),
('phone','+256 700 000000'),
('email','sales@example.com'),
('address','Kampala, Uganda'),
('reservation_hours','48'),
('deposit_percent','30'),
('delivery_fee','0'),
('cart_limit','3'),
('bank_details','Bank: (set in business settings)\nAccount name: (set in business settings)\nAccount number: (set in business settings)');

-- SAMPLE DATA ONLY. Replace with the business's real stock. No images are seeded.
INSERT INTO vehicles (stock_ref,category_id,make,model,grade,year,price,original_price,mileage_km,engine_cc,fuel_type,transmission,drivetrain,seats,colour,vehicle_condition,description,status,is_featured) VALUES
('UG-0001',3,'Toyota','Land Cruiser Prado','TX-L',2017,168000000,175000000,64000,2800,'Diesel','Automatic','4WD',7,'Pearl White','Foreign Used','Sample listing. Replace with real vehicle details.','Available',1),
('UG-0002',2,'Toyota','Vitz','F',2015,24500000,NULL,71000,1000,'Petrol','Automatic','FWD',5,'Silver','Foreign Used','Sample listing.','Available',0),
('UG-0003',1,'Toyota','Premio','G',2014,41000000,NULL,88000,1500,'Petrol','Automatic','2WD',5,'Black','Foreign Used','Sample listing.','Available',1),
('UG-0004',3,'Subaru','Forester','XT',2016,56000000,59000000,69000,2000,'Petrol','Automatic','AWD',5,'Blue','Foreign Used','Sample listing.','Available',1),
('UG-0005',5,'Toyota','Noah','Si',2015,38500000,NULL,76000,2000,'Petrol','Automatic','2WD',8,'Silver','Foreign Used','Sample listing.','Available',0),
('UG-0006',8,'Toyota','Hilux','Double Cab',2018,128000000,NULL,52000,2400,'Diesel','Manual','4WD',5,'White','Foreign Used','Sample listing.','Available',1),
('UG-0007',7,'Mercedes-Benz','C200','AMG Line',2019,142000000,NULL,38000,1500,'Petrol','Automatic','RWD',5,'Grey','Foreign Used','Sample listing.','Available',0),
('UG-0008',3,'Honda','Vezel','Hybrid Z',2016,46000000,NULL,60000,1500,'Hybrid','Automatic','FWD',5,'Red','Foreign Used','Sample listing.','Available',0),
('UG-0009',9,'Toyota','Probox','GL',2016,29000000,NULL,95000,1500,'Petrol','Automatic','2WD',5,'White','Foreign Used','Sample listing.','Available',0),
('UG-0010',3,'Nissan','X-Trail','20X',2015,39000000,NULL,82000,2000,'Petrol','Automatic','4WD',5,'Black','Foreign Used','Sample listing.','Reserved',0),
('UG-0011',1,'Mazda','Axela','15C',2016,33000000,NULL,58000,1500,'Petrol','Automatic','FWD',5,'Red','Foreign Used','Sample listing.','Available',0),
('UG-0012',6,'Toyota','Harrier','Elegance',2014,52000000,NULL,90000,2000,'Petrol','Automatic','2WD',7,'Pearl White','Foreign Used','Sample listing.','Available',0);

INSERT INTO vehicle_features (vehicle_id,feature) SELECT id,'Air conditioning' FROM vehicles;
INSERT INTO vehicle_features (vehicle_id,feature) SELECT id,'Power windows' FROM vehicles;
INSERT INTO vehicle_features (vehicle_id,feature) SELECT id,'Reverse camera' FROM vehicles WHERE price > 40000000;
