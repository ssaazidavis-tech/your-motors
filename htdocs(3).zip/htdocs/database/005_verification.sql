-- Email verification for customer accounts.
ALTER TABLE customers ADD COLUMN email_verified_at DATETIME NULL;
-- Accounts that existed before this feature are treated as verified.
UPDATE customers SET email_verified_at = created_at WHERE email_verified_at IS NULL;
CREATE TABLE email_verifications (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
) ENGINE=InnoDB;
