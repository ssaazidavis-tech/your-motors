-- Staff replies to customer inquiries, shown to the customer on /contact.php.
ALTER TABLE inquiries ADD COLUMN reply TEXT NULL, ADD COLUMN replied_at DATETIME NULL;
