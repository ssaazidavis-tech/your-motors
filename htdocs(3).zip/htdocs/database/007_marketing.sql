-- Marketing email consent, kept separate from required account email verification.
ALTER TABLE customers ADD COLUMN marketing_opt_in TINYINT(1) NOT NULL DEFAULT 0 AFTER email_verified_at;

