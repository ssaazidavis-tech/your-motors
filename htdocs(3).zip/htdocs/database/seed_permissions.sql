USE car_etailer;
INSERT INTO permissions (code) VALUES
('dashboard.view'),('inventory.manage'),('orders.view'),('orders.manage'),('payments.verify'),
('inquiries.manage'),('customers.view'),('reports.view'),('staff.manage'),('settings.manage');
-- admin: everything
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p WHERE r.code='admin';
-- inventory manager
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('dashboard.view','inventory.manage','inquiries.manage') WHERE r.code='inventory';
-- sales and order manager
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('dashboard.view','orders.view','orders.manage','inquiries.manage','customers.view') WHERE r.code='sales';
-- finance officer
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('dashboard.view','orders.view','payments.verify','reports.view') WHERE r.code='finance';
