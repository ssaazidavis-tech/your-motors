-- Test-mode (sandbox) payment methods. No real money moves; see public/pay_test.php.
INSERT IGNORE INTO payment_methods (code,label,instructions,requires_provider,enabled,sort_order) VALUES
('card_test','Debit / credit card (test mode)','Sandbox payment. Use test card 4242 4242 4242 4242, any future expiry, any 3-digit CVC. Pay after we confirm your vehicle.',0,1,3),
('momo_test','Mobile Money (test mode)','Sandbox payment. Use test number 0770000000 and PIN 1234. Pay after we confirm your vehicle.',0,1,4);
