-- Car E-Tailer schema (MySQL 8 / MariaDB 10.4+). Run: mysql -u root -p < database/schema.sql
CREATE DATABASE IF NOT EXISTS car_etailer CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE car_etailer;

CREATE TABLE roles (
  id TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL UNIQUE,
  label VARCHAR(60) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE permissions (
  id SMALLINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE role_permissions (
  role_id TINYINT UNSIGNED NOT NULL,
  permission_id SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES roles(id),
  FOREIGN KEY (permission_id) REFERENCES permissions(id)
) ENGINE=InnoDB;

CREATE TABLE users ( -- staff accounts only
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  role_id TINYINT UNSIGNED NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB;

CREATE TABLE customers (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  phone VARCHAR(25) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  address VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id SMALLINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL UNIQUE,
  slug VARCHAR(70) NOT NULL UNIQUE,
  sort_order SMALLINT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE vehicles (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  stock_ref VARCHAR(30) NOT NULL UNIQUE,
  category_id SMALLINT UNSIGNED NOT NULL,
  make VARCHAR(50) NOT NULL,
  model VARCHAR(60) NOT NULL,
  grade VARCHAR(80) NULL,
  year SMALLINT UNSIGNED NOT NULL,
  price DECIMAL(15,2) NOT NULL DEFAULT 0,
  original_price DECIMAL(15,2) NULL,
  price_on_request TINYINT(1) NOT NULL DEFAULT 0,
  mileage_km INT UNSIGNED NULL,
  engine_cc MEDIUMINT UNSIGNED NULL,
  fuel_type ENUM('Petrol','Diesel','Hybrid','Electric','LPG') NOT NULL,
  transmission ENUM('Automatic','Manual') NOT NULL,
  drivetrain ENUM('2WD','4WD','AWD','FWD','RWD') NULL,
  seats TINYINT UNSIGNED NULL,
  colour VARCHAR(40) NULL,
  vehicle_condition ENUM('New','Foreign Used','Locally Used') NOT NULL DEFAULT 'Foreign Used',
  vin VARCHAR(30) NULL,
  description TEXT NULL,
  inspection_notes TEXT NULL,
  acquisition_cost DECIMAL(15,2) NULL,
  acquired_on DATE NULL,
  status ENUM('Draft','Available','Reserved','Sold','Archived') NOT NULL DEFAULT 'Draft',
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  INDEX idx_status_created (status, created_at),
  INDEX idx_make_model (make, model),
  INDEX idx_price (price),
  INDEX idx_year (year)
) ENGINE=InnoDB;

CREATE TABLE vehicle_images (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  vehicle_id INT UNSIGNED NOT NULL,
  path VARCHAR(255) NOT NULL,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  sort_order SMALLINT NOT NULL DEFAULT 0,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE vehicle_features (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  vehicle_id INT UNSIGNED NOT NULL,
  feature VARCHAR(80) NOT NULL,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE carts (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL UNIQUE,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
) ENGINE=InnoDB;

CREATE TABLE cart_items (
  cart_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  added_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (cart_id, vehicle_id),
  FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB;

CREATE TABLE wishlists (
  customer_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id, vehicle_id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB;

CREATE TABLE orders (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  reference VARCHAR(30) NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  status ENUM('Order Submitted','Awaiting Confirmation','Awaiting Payment','Payment Verified',
              'Order Processing','Ready for Handover','Completed','Cancelled')
         NOT NULL DEFAULT 'Awaiting Confirmation',
  payment_status ENUM('Unpaid','Pending Verification','Partially Paid','Paid','Refunded') NOT NULL DEFAULT 'Unpaid',
  payment_method VARCHAR(30) NOT NULL,
  payment_plan ENUM('Full','Deposit') NOT NULL DEFAULT 'Full',
  contact_name VARCHAR(120) NOT NULL,
  contact_phone VARCHAR(25) NOT NULL,
  contact_email VARCHAR(160) NOT NULL,
  handover_type ENUM('Pickup','Delivery') NOT NULL,
  handover_location VARCHAR(255) NOT NULL,
  instructions TEXT NULL,
  subtotal DECIMAL(15,2) NOT NULL,
  delivery_fee DECIMAL(15,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(15,2) NOT NULL,
  amount_due_now DECIMAL(15,2) NOT NULL,
  amount_paid DECIMAL(15,2) NOT NULL DEFAULT 0,
  cancel_reason VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  INDEX idx_status (status), INDEX idx_pay (payment_status), INDEX idx_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE order_items ( -- snapshot columns keep history after listings change
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  stock_ref VARCHAR(30) NOT NULL,
  title VARCHAR(200) NOT NULL,
  price DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB;

CREATE TABLE order_status_history (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  from_status VARCHAR(30) NULL,
  to_status VARCHAR(30) NOT NULL,
  note VARCHAR(255) NULL,
  actor_type ENUM('customer','staff','system') NOT NULL,
  actor_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id)
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  method VARCHAR(30) NOT NULL,
  provider VARCHAR(30) NULL,
  provider_txn_id VARCHAR(80) NULL UNIQUE,
  reference VARCHAR(60) NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'UGX',
  status ENUM('Pending','Pending Verification','Verified','Failed') NOT NULL DEFAULT 'Pending',
  proof_file VARCHAR(255) NULL,
  verified_by INT UNSIGNED NULL,
  verified_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (verified_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE refunds (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  payment_id INT UNSIGNED NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  reason VARCHAR(255) NOT NULL,
  approved_by INT UNSIGNED NOT NULL,
  processed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (payment_id) REFERENCES payments(id),
  FOREIGN KEY (approved_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE payment_methods (
  code VARCHAR(30) PRIMARY KEY,
  label VARCHAR(60) NOT NULL,
  instructions VARCHAR(500) NULL,
  requires_provider TINYINT(1) NOT NULL DEFAULT 0,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  sort_order SMALLINT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE reservations (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  vehicle_id INT UNSIGNED NOT NULL,
  order_id INT UNSIGNED NOT NULL,
  expires_at DATETIME NOT NULL,
  status ENUM('Active','Released','Converted') NOT NULL DEFAULT 'Active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  FOREIGN KEY (order_id) REFERENCES orders(id),
  INDEX idx_active (status, expires_at)
) ENGINE=InnoDB;

CREATE TABLE inquiries (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  vehicle_id INT UNSIGNED NULL,
  customer_id INT UNSIGNED NULL,
  type ENUM('Inquiry','Test Drive','Price Request') NOT NULL DEFAULT 'Inquiry',
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(25) NOT NULL,
  email VARCHAR(160) NULL,
  message TEXT NULL,
  preferred_date DATE NULL,
  status ENUM('New','Contacted','Closed') NOT NULL DEFAULT 'New',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id)
) ENGINE=InnoDB;

CREATE TABLE messages (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NULL,
  inquiry_id INT UNSIGNED NULL,
  sender_type ENUM('customer','staff') NOT NULL,
  sender_id INT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (inquiry_id) REFERENCES inquiries(id)
) ENGINE=InnoDB;

CREATE TABLE audit_log (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  actor_type ENUM('customer','staff','system') NOT NULL,
  actor_id INT UNSIGNED NULL,
  action VARCHAR(60) NOT NULL,
  entity VARCHAR(40) NOT NULL,
  entity_id INT UNSIGNED NULL,
  detail VARCHAR(500) NULL,
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_entity (entity, entity_id)
) ENGINE=InnoDB;

CREATE TABLE settings (
  k VARCHAR(60) PRIMARY KEY,
  v TEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE rate_limits (
  k VARCHAR(120) PRIMARY KEY,
  hits INT UNSIGNED NOT NULL,
  window_start DATETIME NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS outbox (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  to_email VARCHAR(160) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  status ENUM('Pending','Sent','Failed') NOT NULL DEFAULT 'Pending',
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at DATETIME NULL,
  INDEX idx_status (status)
) ENGINE=InnoDB;
