-- Stage 6: features ported from the Mumie D Boutique site.
-- Run once:  mysql -u root -p car_etailer < database/008_boutique_features.sql
USE car_etailer;

-- Offers ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coupons (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL UNIQUE,
  type ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
  value DECIMAL(15,2) NOT NULL,
  min_subtotal DECIMAL(15,2) NOT NULL DEFAULT 0,
  max_uses INT UNSIGNED NULL,
  used_count INT UNSIGNED NOT NULL DEFAULT 0,
  expires_at DATE NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS welcome_offers (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(160) NOT NULL UNIQUE,
  coupon_code VARCHAR(40) NULL,
  source VARCHAR(30) NOT NULL DEFAULT 'signup',
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip (ip, created_at)
) ENGINE=InnoDB;

ALTER TABLE orders ADD COLUMN discount_amount DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER delivery_fee,
                   ADD COLUMN coupon_code VARCHAR(40) NULL AFTER discount_amount;

-- Staff two-factor sign-in ---------------------------------------------
ALTER TABLE users ADD COLUMN totp_secret_enc VARCHAR(255) NULL,
                  ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0,
                  ADD COLUMN totp_last_step INT UNSIGNED NOT NULL DEFAULT 0;
CREATE TABLE IF NOT EXISTS staff_backup_codes (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  code_hash CHAR(64) NOT NULL,
  used_at DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id)
) ENGINE=InnoDB;

-- Reviews (one per completed order) ------------------------------------
CREATE TABLE IF NOT EXISTS reviews (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  title VARCHAR(100) NULL,
  body TEXT NULL,
  status ENUM('Pending','Approved','Hidden') NOT NULL DEFAULT 'Pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  INDEX idx_status (status, created_at)
) ENGINE=InnoDB;

-- "Tell me" alerts: price drops and back-in-stock ----------------------
CREATE TABLE IF NOT EXISTS vehicle_alerts (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  kind ENUM('price_drop','available') NOT NULL,
  price_at_signup DECIMAL(15,2) NOT NULL,
  notified_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_alert (customer_id, vehicle_id, kind),
  FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Abandoned-cart reminder log -------------------------------------------
CREATE TABLE IF NOT EXISTS cart_reminders (
  cart_id INT UNSIGNED PRIMARY KEY,
  sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Permissions and defaults ----------------------------------------------
INSERT IGNORE INTO permissions (code) VALUES ('offers.manage'),('reviews.manage'),('backup.run');
INSERT IGNORE INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p WHERE r.code='admin' AND p.code IN ('offers.manage','reviews.manage','backup.run');
INSERT IGNORE INTO role_permissions SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('offers.manage','reviews.manage') WHERE r.code='sales';
INSERT IGNORE INTO settings (k, v) VALUES ('welcome_enabled','1'),('welcome_percent','2'),('welcome_days','14'),('cart_reminder_hours','24');
