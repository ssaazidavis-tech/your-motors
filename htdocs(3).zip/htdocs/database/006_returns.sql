-- Returns after handover: customer request -> staff decision -> vehicle received -> refund and close.
CREATE TABLE order_returns (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  order_id INT UNSIGNED NOT NULL,
  vehicle_id INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  reason VARCHAR(60) NOT NULL,
  details TEXT NULL,
  status ENUM('Requested','Approved','Rejected','Received','Completed') NOT NULL DEFAULT 'Requested',
  decision_note VARCHAR(255) NULL,
  decided_by INT UNSIGNED NULL,
  decided_at DATETIME NULL,
  received_at DATETIME NULL,
  refund_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
  outcome_note VARCHAR(255) NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_return_item (order_id, vehicle_id),
  INDEX idx_return_status (status),
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (decided_by) REFERENCES users(id)
) ENGINE=InnoDB;
-- Days after handover in which a customer may ask for a return (0 turns returns off). Change it in Admin > Settings.
INSERT IGNORE INTO settings (k, v) VALUES ('return_days', '7');
